/// Cristobal Valdes Diaz ///
/// NRC : 8513           ///

#include <iostream>
#include <string.h>
#include <fstream>
#include <iomanip>

using namespace std;

int main(){
  string archivo1="archivo1.txt";
  string linea,nomb,n1,n2,n3,n4;
  string nombreE; //Nombre Estudiante
  string notaE1,notaE2,notaE3,notaE4; //Nota Estudiante
  float arr1,arr2,arr3,arr4,promedio,suma;
  string almN[100]; //Almacena Nombre
  string almN1[100], almN2[100], almN3[100], almN4[100];//Almacena Notas
  int res,lon,ini,jo;
  int opcion=0;
  int i=0;
  int j;
  char b,l;
  ifstream archivo(archivo1.c_str());

  while(opcion != 4){
    cout<<"__________________________"<<endl;
    cout<<"INGRESE UNA DE LAS OPCIONES"<<endl;
    cout<<"__________________________"<<endl;
    cout<<"1) Ingrese Nombre y Notas del Alumno"<<endl;
    cout<<"2) Mostrar Nombre y Notas"<<endl;
    cout<<"3) Leer Txt"<<endl;
    cout<<"4) Salir"<<endl;
    cout<<"Ingrese Opcion: ";
    cin>>opcion;

    switch(opcion){
      case 1:
        cout<<"Ingrese nombre del alumno: ";
        cin>>nombreE;
        almN[i]=nombreE;

        cout<<"__________________________"<<endl;
        
        cout<<"Ingrese nota 1: ";
        cin>>notaE1;
        almN1[i]=notaE1;
        arr1 = std::stof(notaE1);//Arreglo a Float

        cout<<"Ingrese nota 2: ";
        cin>>notaE2;
        almN2[i]=notaE2;
        arr2 = std::stof(notaE2);//Arreglo a Float

        cout<<"Ingrese nota 3: ";
        cin>>notaE3;
        almN3[i]=notaE3;
        arr3 = std::stof(notaE3);//Arreglo a Float

        cout<<"Ingrese nota 4: ";
        cin>>notaE4;
        almN4[i]=notaE4;
        arr4 = std::stof(notaE4);//Arreglo a Float
        i++;
      break;

      
      case 2:
        cout<<"\n";
        for(int j=0;j<i;j++){
          cout<<"-> "<<almN[j]<<"  "<<almN1[j]<<"- "<<almN2[j]<<"- "<<almN3[j]<<"- "<<almN4[j]<<endl;
          cout<<"\n"<<endl;

        }
      break;

      case 3:
        cout<<"\n";
      while (getline(archivo,linea)) {
        cout<<linea<<endl;
        lon = linea.length();
        for (ini=0;ini<lon;ini++){
            l=linea[ini];
            b=' ';
            if (l!=b){
                if (jo==0){
                    nomb=nomb+linea[ini];
                  }
                if (jo==1){
                    n1=n1+linea[ini];
                    arr1 = std::stof(n1);
                }
                if (jo==2){
                    n2=n2+linea[ini];
                    arr2 = std::stof(n2);
                }
                if (jo==3){
                    n3=n3+linea[ini];
                    arr3 = std::stof(n3);
                }
                if (jo==4){
                    n4=n4+linea[ini];
                    arr4 = std::stof(n4);
                }
            }
            else
                jo++;
          }
      
        suma = ((arr1+arr2+arr3+arr4)/4);
        cout<<"Promedio: "<<fixed<<setprecision(1)<<suma<<endl; // Nos aproxima el promedio
        cout<<"\n";
      
        jo=0;
        nomb=" ";
        n1=" ";
        n2=" ";
        n3=" ";
        n4=" "; 
        }
      break; 
        
    }
  }
}







