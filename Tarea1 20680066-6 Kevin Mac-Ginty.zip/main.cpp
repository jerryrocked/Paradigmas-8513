#include <iostream>
#include <fstream>
#include <cstring>
#include <stdio.h>
#include <algorithm>
#include <vector>
using namespace std;

class Persona
{
	public:
	struct {
		string nom,rut; //Solo se necesita esto para solicitar los datos de unas notas, lo demas es redundante
	}reg;	
	Persona(){ };
	~Persona(){ };
	void datosper(); //insertar datos
	void mostrarper(); //mostrar datos
};
void Persona::datosper(){
	cout << "Nombre : "; getline(cin, reg.nom);
    cout << "Rut : "; getline(cin, reg.rut);
	};
void Persona::mostrarper(){
	cout << "Nombre : "<<reg.nom<<endl;
    cout << "Rut : "<<reg.rut<<endl;
	};

class Profesor: public virtual Persona
{
	public:
	string cat; //categoria instructor, asociado titular 
	Profesor(){	};
	~Profesor(){ };
	void datosprof();
	void mostrarprof();
	void entregarnotas();
};

void Profesor::datosprof() {
		int i;
		datosper();
		cout<<"Escriba la Categoria: ";getline(cin, cat);	
	};
void Profesor::mostrarprof(){
		int i;
		mostrarper();
		cout << "Categoria : "<<cat<<endl;
	};

class Estudiante: public virtual Persona
{
	public:
	string carr; //carrera
	int can;
	Estudiante(){ };
	~Estudiante(){ };
	void datosest();
	void mostrarest();
};
void Estudiante::datosest() {
		int i;
		datosper();
		cout<<"Ingresar Carrera que Estudia: ";
		getline(cin, carr);
	};
void Estudiante::mostrarest(){
		mostrarper();
		cout<<"Carrera: "<<carr<< endl;
	};
	
class Asignatura: public Profesor, public Estudiante
{
	public:
	string s[10]; //Seccion
	string a[10],c[10]; //asignatura, codigo
	char nom[40]= "Estudiante.txt";
	int cant; //cantidad de asignaturas seleccionadas
	string mat[5]={"PROGRAMACION","BASE DE DATOS","ALGORITMO Y ESTRUCTURA DE DATOS","DESARROLLO WEB Y MOBIL","PARADIGMAS DE PROGRAMACION"};
	string cod[5]={"PR001","BD002","AE003","DM004","PP005"};
	Asignatura(){	};
	~Asignatura(){	};
	void ingresardatose(); //ingresar dato estudiante
	void mostrare(); //mostrar datos estudiante
	void ingresardatosp(); //ingresar datos profesor
	void mostrarp(); //mostrar datos profesor
	void limpiardatos();
};
void Asignatura::mostrarp(){
		mostrarprof();
		cout << "Cantidad Asignatura : "<<cant<<endl;
		cout<<"Asignaturas: \n";	
		for(int i=0;i<cant;i++){
			cout<<a[i]<<endl;
		}
};
void Asignatura::ingresardatosp(){
	int opcion,opc;
	datosprof();
	cout<<"Escriba la Cantidad de Asignaturas: ";
	cin>> cant;
	cin.ignore();
	for (int i=0;i<cant;i++){
		cout<<"Seleccione las Asignaturas: ";
		cout<<"\n 1. "<<mat[0];
		cout<<"\n 2. "<<mat[1];
		cout<<"\n 3. "<<mat[2];
		cout<<"\n 4. "<<mat[3];
		cout<<"\n 5. "<<mat[4];
		cout<<"\n Seleccione una Opcion: "; //se pregunta por la asignatura
		cin>>opcion;
		switch (opcion){
			case 1: {
			a[i]=mat[0];
			c[i]=cod[0];
			break;
			}
			case 2: {
			a[i]=mat[1];
			c[i]=cod[1];
			break;
			}
			case 3: {
			a[i]=mat[2];
			c[i]=cod[2];
			break;
			}
			case 4: {
			a[i]=mat[3];
			c[i]=cod[3];
			break;
			}
			case 5: {
			a[i]=mat[4];
			c[i]=cod[4];
			break;
			}
			}
    	cout<<"\n 1. Secci�n 1";
		cout<<"\n 2. Secci�n 2";
		cout<<"\n Seleccione la secci�n: ";			
		cin>>opc;
    	cin.ignore();
		switch (opc){
			case 1: {
				s[i]="1";
				break;
			}
			case 2: {
				s[i]="2";
				break;
				}
 			}
		
	}
}


void Asignatura::ingresardatose(){
	int opcion,opc;
	datosest();
	cout<<"Escriba la Cantidad de Asignaturas: ";
	cin >> cant;
	cin.ignore();
	for (int i=0;i<cant;i++){
		cout<<"Seleccione las Asignaturas: ";
		cout<<"\n 1. "<<mat[0];
		cout<<"\n 2. "<<mat[1];
		cout<<"\n 3. "<<mat[2];
		cout<<"\n 4. "<<mat[3];
		cout<<"\n 5. "<<mat[4];
		cout<<"\n Seleccione una Opcion: ";
		cin>>opcion;
		switch (opcion){
		case 1: {
			a[i]=mat[0];
			c[i]=cod[0];
			break;
		}
		case 2: {
			a[i]=mat[1];
			c[i]=cod[1];
			break;
		} 
		case 3: {
			a[i]=mat[2];
			c[i]=cod[2];
			break;
		} 
		case 4: {
			a[i]=mat[3];
			c[i]=cod[3];
			break;
		} 
		case 5: {
			a[i]=mat[4];
			c[i]=cod[4];
			break;
		} 
		}
		cout<<"\n 1. Secci�n 1";
		cout<<"\n 2. Secci�n 2";
		cout<<"\n Seleccione la secci�n: ";			
		cin>>opc;
    cin.ignore();
		switch (opc){
			case 1: {
				s[i]="1";
				break;
			}
			case 2: {
				s[i]="2";
				break;
			}
		}
	}

}; 
void Asignatura::mostrare(){
	mostrarest();
	
	cout<<"Asignaturas: \n";	
	for(int i=0;i<cant;i++){
		cout<<a[i]<<endl;
		cout<<c[i]<<endl;
		cout<<s[i]<<endl;
	}	
};

void Asignatura::limpiardatos(){
	for (size_t i = 0; i < sizeof(a)/sizeof(a[0]); i++)
	{
		a[i] = "";
	}
	for (size_t i = 0; i < sizeof(c)/sizeof(c[0]); i++)
	{
		c[i] = "";
	}
	for (size_t i = 0; i < sizeof(s)/sizeof(s[0]); i++)
	{
		s[i] = "";
	}
}

int diccionarioAsig(string asig){
	if (asig == "PROGRAMACION"){
		return 0;
	}
	else if(asig == "BASE DE DATOS"){
		return 1;
	}
	else if(asig == "ALGORITMO Y ESTRUCTURA DE DATOS"){
		return 2;
	}
	else if(asig == "DESARROLLO WEB Y MOBIL"){
		return 3;
	}
	else if(asig == "PARADIGMAS DE PROGRAMACION"){
		return 4;
	}
	else
	{
		return 7; //si no da un valor correcto, esto dara unerror de segmentacion por estar a fuera de el rango de el array de basegigante
	}
	
}
int diccionarioSecc(string secc){
	if (secc == "1"){
		return 0;
	}
	else if (secc == "2")
	{
		return 1;
	}
	else
	{
		return 7;//si no da un valor correcto, esto dara unerror de segmentacion por estar a fuera de el rango de el array de basegigante
	}
}


int main(int argc, char** argv) {
	Asignatura as;
  	string basegigante[5][2][3][100];
	/* Primera dimencion [5]:
	"PROGRAMACION"  [0]
	"BASE DE DATOS"  [1]
	"ALGORITMO Y ESTRUCTURA DE DATOS",  [2]
	"DESARROLLO WEB Y MOBIL"   [3]
	"PARADIGMAS DE PROGRAMACION"  [4]

	Segunda dimension [2]
	Seccion

	Tercera dimencion [2]:
	Nombre [0]
	Rut [1]
	Promedio [2]

	cuarta dimencion [100]

	Notas de cada estudiante [0,2,3...,99]

	*/
  
	int opc;
	while (true) {
		cout<<"Sistema de Notas \n";
		cout<<"1. Profesor: \n";
		cout<<"2. Estudiante: \n";
		cout<<"3. Salir \n";
		cout<<"Seleccionar Opci�n: ";
		cin>>opc;
		cin.ignore();
		if (opc == 1){
			as.ingresardatosp();
			as.mostrarp();
			for (size_t contdeasig = 0; contdeasig < as.cant; contdeasig++)//Cuenta en que itteracion de la cantidad de asiganturas seleccionadas
			{
				if (as.c[contdeasig] != "")
				{
					int tipodeimp ;
					int asignaturaActual = diccionarioAsig(as.a[contdeasig]);
					int seccionActual = diccionarioSecc(as.s[contdeasig]);
					cout<< "Asignatura Actual:" << as.a[contdeasig] << endl;
					cout<< "¿Quiere subir un archivo o ingresar manualmente? (1)(2):\n";
					cin>>tipodeimp;
					if (tipodeimp == 1)
					{
						string filename;
						cout<<"Ingrese nombre de archivo\n";
						cin>>filename; 
						string sting,nomb,rut,n1,n2,n3,n4;
						char b,l;
						int res,lon,i,j=0,k=0;
						float i1,i2,i3,i4,pr;
						fstream archivo(filename);
						while(getline(archivo,sting)){
							cout<<sting<<endl;
							lon = sting.length();
							for (i=0;i<lon;i++){
								l=sting[i];
								b=' ';
								if (l!=b){
									if (j==0)
										nomb=nomb+sting[i];
									if (j==1)
										nomb=nomb+sting[i];
									if (j==2)
									{
										rut=rut+sting[i];
									}
									
									if (j==3) {
										n1=n1+sting[i];
									}
									if (j==4){
										n2=n2+sting[i];
									}
									if (j==5){
										n3=n3+sting[i];
									}
									if (j==6){
										n4=n4+sting[i];   
									}
								}
								else {
									if (j == 0)
									{
										nomb=nomb+" ";
									}
									
									j++;
								}
							}
							cout<<nomb<<endl;
							cout<<rut<<endl;
							cout<<n1<<endl;
							cout<<n2<<endl;
							cout<<n3<<endl;
							cout<<n4<<endl;

							i1= stof(n1);
							i2= stof(n2);
							i3= stof(n3);
							i4= stof(n4);


							pr = (i1 +i2+i3+i4)/4;

							if (pr > 7 || pr < 1)
							{
								cout<<"Nota invalida en el archivo\n";
								return 1;
							}
							

							cout<<pr<<endl;

							
							
							
							//Ingresando nombre
							
							basegigante[asignaturaActual][seccionActual][0][k] = nomb;


							//Ingresando RUT

							basegigante[asignaturaActual][seccionActual][1][k] = rut;

							//Ingresando promedio

							basegigante[asignaturaActual][seccionActual][2][k] = to_string(pr);

							

							j=0;
							nomb="";
							rut="";
							n1="";
							n2="";
							n3="";
							n4="";
							k++; 
						}
						//Inicio Bubble Sort
						int n = sizeof(basegigante[asignaturaActual][seccionActual][2])/ sizeof(basegigante[asignaturaActual][seccionActual][2][0]);
						
						string tempnom,temprut,temppr;
						for (size_t i = 0; i < n - 1; i++)
						{
							for (size_t j = i + 1; j < n + 1; j++)
							{
								if (basegigante[asignaturaActual][seccionActual][2][i] != "" && basegigante[asignaturaActual][seccionActual][2][j] != "")
								{
									float transformacioni = stof(basegigante[asignaturaActual][seccionActual][2][i]);
									float transformacionj = stof(basegigante[asignaturaActual][seccionActual][2][j]);
									if (transformacionj > transformacioni)
									{
										tempnom = basegigante[asignaturaActual][seccionActual][0][i];
										temprut = basegigante[asignaturaActual][seccionActual][1][i];
										temppr = basegigante[asignaturaActual][seccionActual][2][i];
										basegigante[asignaturaActual][seccionActual][0][i] = basegigante[asignaturaActual][seccionActual][0][j];
										basegigante[asignaturaActual][seccionActual][1][i] = basegigante[asignaturaActual][seccionActual][1][j];
										basegigante[asignaturaActual][seccionActual][2][i] = basegigante[asignaturaActual][seccionActual][2][j];
										basegigante[asignaturaActual][seccionActual][0][j] = tempnom;
										basegigante[asignaturaActual][seccionActual][1][j] = temprut;
										basegigante[asignaturaActual][seccionActual][2][j] = temppr;
									}
								}
								
								
								
							}
						}
						//Print de cantidad de aprobados y Reprobados
						int cantApbrobados = 0,cantReprobados = 0;
						for (size_t i = 0; i < n; i++)
						{
							if (basegigante[asignaturaActual][seccionActual][2][i] != "") {
								
								float valortemporal = stof(basegigante[asignaturaActual][seccionActual][2][i]);
								if (valortemporal > 4.0)
								{
									cantApbrobados++;
								}
								else
								{
									cantReprobados++;
								}							
							}
						}
						cout<< "Cantidad de Aprobados: " << cantApbrobados << endl;
						cout<< "Cantidad de Reprobados: " << cantReprobados << endl;
						// Escritura Archivo, Genera un archivo con el codigo de cusro y la seccion en el nombre
						ofstream MiArchivo(as.c[contdeasig]+"SEC"+as.s[contdeasig]+".txt");
						for (size_t i = 0; i < n; i++)
						{
							if (basegigante[asignaturaActual][seccionActual][2][i] != ""){
								MiArchivo << basegigante[asignaturaActual][seccionActual][0][i] << "	" << basegigante[asignaturaActual][seccionActual][2][i] << endl;
							}
						}
						
						MiArchivo.close();
					}
					else if (tipodeimp == 2){
						int contestudiante = 0;
						char continuar = 's';
						while (continuar == 's')
						{
							string nomb,rut,n1,n2,n3,n4;
							float i1,i2,i3,i4,pr;
							char comprobacion = 's';
							cout << "Ingrese nombre de estudiante (primer nombre y primer apellido)" << endl;
							cin >> nomb;
							cout << "Ingrese RUT" << endl;
							cin >> rut;
							cout << "Ingrese primera nota" << endl;
							while (comprobacion == 'f'){
								cin >> i1;
								if (i1 < 7 || i1 < 1)
								{
									cout << "Nota invalida, intentar otra vez" << endl;
								}
								else
								{
									comprobacion = 's';
								}
							}
							cout << "Ingrese segunda nota" << endl;
							while (comprobacion == 'f'){
								cin >> i2;
								if (i2 < 7 || i2 < 1)
								{
									cout << "Nota invalida, intentar otra vez" << endl;
								}
								else
								{
									comprobacion = 's';
								}
							}
							cout << "Ingrese tercera nota" << endl;
							while (comprobacion == 'f'){
								cin >> i3;
								if (i3 < 7 || i3 < 1)
								{
									cout << "Nota invalida, intentar otra vez" << endl;
								}
								else
								{
									comprobacion = 's';
								}
							}
							cout << "Ingrese cuarta nota" << endl;
							while (comprobacion == 'f'){
								cin >> i4;
								if (i4 < 7 || i4 < 1)
								{
									cout << "Nota invalida, intentar otra vez" << endl;
								}
								else
								{
									comprobacion = 's';
								}
							}

							//ingreso de datos

							//calcular promedio
							pr = (i1 +i2+i3+i4)/4;

							basegigante[asignaturaActual][seccionActual][0][contestudiante] = "\"" + nomb + "\"";

							basegigante[asignaturaActual][seccionActual][0][contestudiante] = rut;

							basegigante[asignaturaActual][seccionActual][0][contestudiante] = to_string(pr);

							cout << "¿Quiere poner mas Datos? (s)(n)" << endl;
							cin >> continuar;
							if (continuar == 's'){
								contestudiante++;
							}
						}
						//Inicio Bubble Sort
						int n = sizeof(basegigante[asignaturaActual][seccionActual][2])/ sizeof(basegigante[asignaturaActual][seccionActual][2][0]); //cantidad de elementos del array para loopear
						
						string tempnom,temprut,temppr;
						for (size_t i = 0; i < n - 1; i++)
						{
							for (size_t j = i + 1; j < n + 1; j++)
							{
								if (basegigante[asignaturaActual][seccionActual][2][i] != "" && basegigante[asignaturaActual][seccionActual][2][j] != "")
								{
									float transformacioni = stof(basegigante[asignaturaActual][seccionActual][2][i]);
									float transformacionj = stof(basegigante[asignaturaActual][seccionActual][2][j]);
									if (transformacionj > transformacioni)
									{
										tempnom = basegigante[asignaturaActual][seccionActual][0][i];
										temprut = basegigante[asignaturaActual][seccionActual][1][i];
										temppr = basegigante[asignaturaActual][seccionActual][2][i];
										basegigante[asignaturaActual][seccionActual][0][i] = basegigante[asignaturaActual][seccionActual][0][j];
										basegigante[asignaturaActual][seccionActual][1][i] = basegigante[asignaturaActual][seccionActual][1][j];
										basegigante[asignaturaActual][seccionActual][2][i] = basegigante[asignaturaActual][seccionActual][2][j];
										basegigante[asignaturaActual][seccionActual][0][j] = tempnom;
										basegigante[asignaturaActual][seccionActual][1][j] = temprut;
										basegigante[asignaturaActual][seccionActual][2][j] = temppr;
									}
								}
								
								
								
							}
						}
						//Print de cantidad de aprobados y Reprobados
						int cantApbrobados = 0,cantReprobados = 0;
						for (size_t i = 0; i < n; i++)
						{
							if (basegigante[asignaturaActual][seccionActual][2][i] != "") {
								
								float valortemporal = stof(basegigante[asignaturaActual][seccionActual][2][i]);
								if (valortemporal > 4.0)
								{
									cantApbrobados++;
								}
								else
								{
									cantReprobados++;
								}							
							}
						}
						cout<< "Cantidad de Aprobados: " << cantApbrobados << endl;
						cout<< "Cantidad de Reprobados: " << cantReprobados << endl;
						// Escritura Archivo, Genera un archivo con el codigo de cusro y la seccion en el nombre
						ofstream MiArchivo(as.c[contdeasig]+"SEC"+as.s[contdeasig]+".txt");
						for (size_t i = 0; i < n; i++)
						{
							if (basegigante[asignaturaActual][seccionActual][2][i] != ""){
								MiArchivo << basegigante[asignaturaActual][seccionActual][0][i] << "	" << basegigante[asignaturaActual][seccionActual][2][i] << endl;
							}
						}
						
						MiArchivo.close();
						
					}
				}
				
			}
			as.limpiardatos();
		}
		else if (opc == 2){
			as.ingresardatose();
			as.mostrare();



			FILE *archivo = fopen("estudiantes.txt", "w"); // FILE se escribe en mayuscula
			
			
			
			for(size_t contdeasig = 0; contdeasig < as.cant; contdeasig++){
				if (as.c[contdeasig] != ""){
					char check = 'e';
					fprintf(archivo,"%s ",as.a[contdeasig].c_str());
					fprintf(archivo,"%s ",as.c[contdeasig].c_str());
					fprintf(archivo,"Seccion: %s ",as.s[contdeasig].c_str());

					//buscar el rut en la base gigante y mostrar la nota, si no se puede encontrar, decir que no esta entregada
					int asignaturaActual = diccionarioAsig(as.a[contdeasig]);
					int seccionActual = diccionarioSecc(as.s[contdeasig]);
					int n = sizeof(basegigante[asignaturaActual][seccionActual][2])/ sizeof(basegigante[asignaturaActual][seccionActual][2][0]); //cantidad de elementos del array para loopear
					for (size_t i = 0; i < n; i++)
						{
							if (basegigante[asignaturaActual][seccionActual][1][i] == as.reg.rut){
								fprintf(archivo,"%s ",basegigante[asignaturaActual][seccionActual][2][i].c_str());
								check = 's';
							}
						}
					if (check == 'e')
					{
						fprintf(archivo,"No entregado");
					}
					
					fprintf(archivo,"\n");
				}
			}

			fclose(archivo);
			as.limpiardatos();

		}
		else {
			cout<<"Saliendo del sistema";
			return 0;
		}
	}
}
