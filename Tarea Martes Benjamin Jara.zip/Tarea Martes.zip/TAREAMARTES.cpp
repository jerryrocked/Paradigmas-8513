
//Benjamín Jara 


#include<iostream>
#include<string.h>
#include<vector> 
#include<cstring>
#include<fstream> //para declarar un archivo
using namespace std;
class alumno{
  private: //atributos
     string nom;
     float not1, not2, not3, not4;
  public: //metodos
     void datosAlumn(string _nom, string _n1, string _n2, string _n3, string _n4);
};


//        CONSTRUCTOR DE LA CLASE ALUMNO


void alumno::datosAlumn(string _nom, string _n1, string _n2, string _n3, string _n4){  //indico los datos a usar 
  nom = _nom;
  float n_1=stof(_n1); // stof convierte de string a float cada nota
  float n_2=stof(_n2);
  float n_3=stof(_n3);
  float n_4=stof(_n4);
    vector <float> _notas={};  // convertir a <float>
  _notas.push_back(n_1);  //push_back agrega el elemento al final del vector
  _notas.push_back(n_2);
  _notas.push_back(n_3);
  _notas.push_back(n_4);
  cout<<"\n";
  cout<<"las notas de "<<nom<<" son: ";
  for (int i=0;i<4;i++){    // recorre el arreglo y va poniendo las notas
    cout<<_notas[i]<<" ";
  }
};


int main()
{
 alumno a; //declaramos la funcion a de tipo alumno
   string archivonotas="archivonotas.txt";
   ifstream archivo(archivonotas.c_str());   //leemos el archivo txt
   string linea,nomb,n1,n2,n3,n4;
   int res, lon, j, i=0;
   string arreglo[100];
   char b,l;

    while (getline(archivo,linea)){
        //cout<<linea<<endl; //muestra la primera linea por pantalla
        lon = linea.length(); //muestra la longitud de la fila para recorrerla
        for (j=0;j<lon;j++){
            l=linea[j];
            b = ' ';
            if (l!=b){
                if(i==0)
                    nomb = nomb+linea[j];
                if(i==1)
                    n1=n1+linea[j]; 
                if(i==2)
                    n2=n2+linea[j];
                if(i==3)
                    n3=n3+linea[j];
                if(i==4)
                    n4=n4+linea[j]; 
            }
            else
                i++;
        }
        //alumno();
      a.datosAlumn(nomb, n1, n2, n3, n4); //imprimimos los archivos nom, n1, n2, n3 y n4
        i=0;
        nomb = " ";
        n1= " ";
        n2= " ";
        n3= " ";
        n4= " ";
    }
}
