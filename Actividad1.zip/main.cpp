#include <iostream>
#include <string.h>
#include <fstream>
#include <cstdlib>
#include <iomanip>
//#include<cstream>
using namespace std;

int main(){
    //int almacen[];
    //int num1, num2, num3, num4;
    string archivo1="Actividad_1.txt";
    ifstream archivo(archivo1.c_str());
    string linea,nomb,n1,n2,n3,n4;
    int res,lon,i,j=0;
    string arreglo[100];
    float arreglo_num[100];
    char b,l;
    while (getline(archivo,linea)){
      cout<<linea<<endl;
      lon=linea.length();
      for(i=0;i<lon;i++){
        l=linea[i];
        b=' ';
        if(l!=b){
          if(j==0)
            nomb=nomb+linea[i];
          if(j==1)
            n1=n1+linea[i];
          if(j==2)
            n2=n2+linea[i];
          if(j==3)
            n3=n3+linea[i];
          if(j==4)
            n4=n4+linea[i];
        }
        else
          j++;
      }
      //cout<<nomb<<endl;
      //cout<<n1<<endl;
      
      ///se pasa los numetros de string a float
      float num_float1 = stof(n1);
      //cout<<n2<<endl;
      float num_float2 = stof(n2);
      //cout<<n3<<endl;
      float num_float3 = stof(n3);
      //cout<<n4<<endl;
      float num_float4 = stof(n4);
      //num1 = atoi(n1);
      //cout<<num1<<endl;

      ///se agregan los numeros al nuevo arreglo
      arreglo_num[0] = num_float1;
      arreglo_num[1] = num_float2;
      arreglo_num[2] = num_float3;
      arreglo_num[3] = num_float4;
      
      
      j=0;
      nomb=" ";
      n1=" ";
      n2=" ";
      n3=" ";
      n4=" ";

      ///se muestran los numeros agregados al arreglo con 3 decimales
      cout<<"areglo ["<<fixed<<setprecision(3)<<arreglo_num[0]<<" "<<arreglo_num[1]<<" "<<arreglo_num[2]<<" "<<arreglo_num[3]<<"]"<<endl;
      cout<< endl;
    }
  }