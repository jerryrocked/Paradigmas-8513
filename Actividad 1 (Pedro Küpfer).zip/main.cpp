#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

class Persona {
  public:
    string nombre;
};

class Alumno: public Persona {
  public:
    float promedio;
};

int main() {
  // Leer archivo
  string nombre_archivo = "Notas.txt";
  string linea;
  ifstream archivo(nombre_archivo.c_str());

  // Leer líneas y separar por variables
  while (getline(archivo,linea)){
    Alumno alumno;
    string n[100];
    char l, b=' ';
    int j = 0;
    int lon = linea.length();
    
    for (int i=0; i<lon; i++){
      l=linea[i];
      if (l!=b){
        if (j==0 || j==1)
          alumno.nombre += linea[i];
        if (j>=2)
          n[j-2] += linea[i];   
      }
      else{
        if (j==0)
          alumno.nombre += " ";
        j++;
      }
    }

    // Calcular promedio
    float suma=0;
    int n_notas = j-2;
    for (int i=0; i<n_notas; i++){
      suma += stof(n[i]);
    }
    alumno.promedio = ceil((suma/n_notas)*100)/100;

    // Verificar si aprobó o reprobó
    string resultado = "";
    if (alumno.promedio >= 4.0){
      resultado = "Aprobado";
    }else{
      resultado = "Reprobado";
    }
    
    // Mostrar resultados
    cout << alumno.nombre << " " << alumno.promedio << " " << resultado << endl;
  }
}