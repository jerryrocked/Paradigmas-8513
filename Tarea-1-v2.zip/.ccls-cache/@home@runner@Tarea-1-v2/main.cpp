#include <iostream>
#include <string>
#include <fstream>
#include <math.h>
using namespace std;

class Persona{
  public:
    string rut;
    string nombre;
    string apellido;
};

class Profesor: public Persona{
  public:
    string seccion;
};

class Alumno: public Persona{
  public:
    string secciones[5];
    float notas[5];
};

class Asignatura{
  public:
    string nombre;
    string seccion;
};

Asignatura asignaturas[5];
Alumno alumnos[100];

int main();

int nuevo_alumno(Alumno alumno){
  int i = 0;
  while (alumnos[i].rut != ""){
    if (alumnos[i].rut == alumno.rut){
      return i;
    }
    i++;
  }
  alumnos[i] = alumno;

  return i;
}

int casillero(Alumno alumno, string seccion){
  int i = 0;
  while (alumno.secciones[i] != ""){
    if (alumno.secciones[i] == seccion){
      return i;
    }
    i++;
  }
  return i;
}

Alumno comprobar_rut(string rut){
  int i = 0;
  while (alumnos[i].rut != ""){
    if (alumnos[i].rut == rut){
      return alumnos[i];
    }
    i++;
  }
  return alumnos[i];
}

void registrar_asignaturas(){
  string asig[5][2] = 
  {{"PROGRAMACION", "PR001"},
  {"BASE DE DATOS", "BD002"},
  {"ALGORITMO Y ESTRUCTURA DE DATOS", "AE003"},
  {"DESARROLLO WEB Y MOBIL", "DM004"},
  {"PARADIGMA DE PROGRAMACION", "PP005"}};

  for (int i=0; i<5; i++){
    Asignatura asignatura;
    asignatura.nombre = asig[i][0];
    asignatura.seccion = asig[i][1];

    asignaturas[i] = asignatura;
  }
}

bool existente(string nombre){
	ifstream archivo(nombre.c_str());
	return archivo.good();
}

float promedio(string n1, string n2, string n3, string n4){
  float suma = stof(n1)+stof(n2)+stof(n3)+stof(n4);
  float prom = suma/4;

  return prom;
};

void profesor(){
  Profesor profe;
  cout<<"\nPor favor ingrese su nombre.\n";
  cin>>profe.nombre;
  cout<<"\nBienvenido "<<profe.nombre<<", por favor ingrese su RUT.\n";
  cin>>profe.rut;

  string opcion = "";
  Asignatura asignatura;
  while(opcion == ""){
    cout<<"\nSeleccione el número de la sección.\n";
    for (int i=0; i<5; i++){
      cout<<i+1<<") "<<asignaturas[i].nombre<<endl;
    }
    cin>>opcion;

    if (stoi(opcion) >= 1 && stoi(opcion) <= 5){
      asignatura = asignaturas[stoi(opcion)-1];
    }else{
      cout<<"\n¡Oops! Opción no encontrada.\n";
      opcion = "";
    }
  }
  profe.seccion = asignatura.seccion;

  string n_archivo = "";
  int aprobados = 0;
  int reprobados = 0;
  
  while (n_archivo == ""){
    cout<<"\nIngrese el nombre del archivo de notas.\n";
    cout<<"(RUT, Nombre, Apellido, 4 notas)\n";
    cin>>n_archivo;
    cout<<"\n";

    if (!existente(n_archivo)){
      cout<<"\n¡Oops! Archivo no encontrado.\n";
      n_archivo = "";
    }
  }

  ifstream archivo(n_archivo.c_str());
  string linea;
  ofstream prom_archivo;
  string nombre_archivo = "Promedios_"+profe.seccion;
  prom_archivo.open(nombre_archivo.c_str());
  while (getline(archivo, linea)){
    string n1,n2,n3,n4;
    int j,i=0,lon;
    char b,l;
    Alumno alumno;
    lon = linea.length();
    for (j=0;j<lon;j++){
			l=linea[j];
			b=' ';
      if (l!=b){
       	if(i==0)
       		alumno.rut = alumno.rut+linea[j];
        if(i==1)
          alumno.nombre = alumno.nombre+linea[j];
        if(i==2)
          alumno.apellido = alumno.apellido+linea[j];
				if(i==3)
       		n1=n1+linea[j];
       	if(i==4)
       		n2=n2+linea[j];
       	if(i==5)
       		n3=n3+linea[j];
       	if(i==6)
       		n4=n4+linea[j];
			}
			else{
				i++;
			}
		}
    int pos = nuevo_alumno(alumno);
    float prom = promedio(n1,n2,n3,n4);
    
    // APROXIMAR PROMEDIOS
    prom=ceil(prom*100)/100;
    int posicion = casillero(alumnos[pos], profe.seccion);
    alumnos[pos].secciones[posicion] = profe.seccion;
    alumnos[pos].notas[posicion] = prom;
    
    prom_archivo << alumno.nombre << " ";
    prom_archivo << alumno.apellido << "\t";
    prom_archivo << prom << "\n";

    if (prom >= 4){
      aprobados = aprobados + 1;
    }else{
      reprobados = reprobados + 1;
    }
  }
  prom_archivo.close();
  
  // MOSTRAR APROBADOS Y REPROBADOS
  cout<<"\nNumero de alumnos aprobados: "<< aprobados<<endl;
  cout<< "Numero de alumnos reprobados: "<<reprobados<<"\n\n";

  string opcion2;
  while (opcion2 != "s" && opcion2 != "n"){
    cout<<"¿Volver al menú de opciones? (s/n)"<<endl;
    cin>>opcion2;
  }
  if (opcion2=="s"){
    main();
  }
};

void alumno(){
  Alumno alumno;

  while (alumno.rut == ""){
    string rut;
    cout<<"Estimado alumno, por favor ingrese su RUT.\n";
    cin>>rut;
  
    alumno = comprobar_rut(rut);
    if (alumno.rut == ""){
      cout << "¡Oops! Alumno no encontrado.\n";
    }
  }

  ofstream prom_alumno;
  string nombre_archivo = "Notas_"+alumno.apellido;
  prom_alumno.open(nombre_archivo.c_str());

  for (int i=0; i<5; i++){
    cout<<asignaturas[i].nombre<<" ";
    prom_alumno<<asignaturas[i].nombre<<" ";

    int j=0;
    float promedio = -1;
    while (alumno.secciones[j] != ""){
      if (alumno.secciones[j] == asignaturas[i].seccion){
        promedio = alumno.notas[j];
      }
      j++;
    }

    if (promedio != -1){
      cout<<promedio<<" ";
      prom_alumno<<promedio<<" ";
      if (promedio >= 4){
        cout<<"Aprobada\n";
        prom_alumno<<"Aprobada\n";
      }else{
        cout<<"Reprobada\n";
        prom_alumno<<"Reprobada\n";
      }
    }else{
      cout<<"(Sin nota)\n";
      prom_alumno<<"(Sin nota)\n";
    }
  }

  prom_alumno.close();
};

int main() {
  registrar_asignaturas();
  string opcion;
  while (opcion != "a" && opcion != "p"){
    cout<<"Bienvenido al programa de notas.\n";
    cout<<"¿Quieres iniciar como profesor (p) o alumno (a)?\n";
    cin >> opcion;

    if (opcion == "a"){
      alumno();
    }else if (opcion == "p"){
      profesor();
    }else{
      cout<<"\n¡Oops! Opción no encontrada.\n";
    };
  }
}
