//Buenas profesor, este trabajo lo realicé junto con Angelo Cancino, Macarena Castro, Luciano Roca, Alonso Riveros.
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <vector>

using namespace std;

class Sujeto { //Clase padre que les otorga a las demás clases los atributos nombre y rut, los cuales son de acceso publico
public:
  string nombre;
  string rut;
};

class Alumno : Sujeto { //Clase alumno, la cual recibe los atributos de sujeto. Encargada de tratar todo lo relacionado con los estudiantes; Nombres, notas, asignaturas, etc.
public:
  map<string, float[4]> nota; //Se crea un mapa para asignarle a cada estudiante0 sus notas correspondientes.
  Alumno(string _nombre) { nombre = _nombre; } //Se le asigna un valor a nombre
  void setNotas(string nomb, float n1, float n2, float n3,//Se le asigna las notas al estudiante
                float n4) {
    nota[nomb][0] = n1;
    nota[nomb][1] = n2;
    nota[nomb][2] = n3;
    nota[nomb][3] = n4;
  }
  string GetNombre() { return nombre; } //Funcion que entrega el nombre del estudiante
  float promRamo(string nombreRamo) { //Función que calcula el promedio de un ramo específico
    float sum = 0;
    for (int i = 0; i < 4; i++) {
      nota[nombreRamo][i];
      sum = nota[nombreRamo][i] + sum;
    };
    float prom = 0;
    prom = sum / 4;
    return prom;
  }
  float promArchivo() {//Función que calcula el promedio general
    float promedio = 0;
    for (auto i = nota.begin(); i != nota.end(); ++i) {
      promedio += i->second[0] + i->second[1] +
                  i->second[2] + i->second[3];
    }
    float resultado = (promedio / 4);
    return resultado;
  }
  float printPromedio() {//Función que muestra el promedio que se necesite
    float promedio = 0;
    for (auto j = nota.begin(); j != nota.end(); j++) {
      for (int i = 0; i < 4; i++) {
        promedio = nota[j->first][i] + promedio;
      }
      cout << promedio / 4;
    }
  return 0;
  }
};

class Asignatura { //La clase asignatura trabaja con toda la información de los ramos, la cual tiene como atributos publigos el codigo, el profesor, el nrc y el nombre.
public:
  string codigo;
  string profe;
  string nrc;
  string nombre;
  vector<Alumno> listAlumnos; //Vector para almacenar la información de los alumnos.
  Asignatura(string _nombre, string _código, string _sección) { //Se le asigna los valores a las asignaturas
    codigo = _código;
    nrc = _sección;
    nombre = _nombre;
  }
  string getNombre() { return this->nombre; }//Función que obtiene el nombre de la asignatura

  string getNRC() { return this->nrc; }//Función que obtiene el NRC de la asignatura

  string getCodigo() { return this->codigo; }//Función que obtiene el codigo de la asignatura

  void añadirAlumno(Alumno estudiante) { listAlumnos.push_back(estudiante); }//Función que ordena los alumnos en una lista, agregandolos al final de esta
  void calificarAlumno(Alumno &estudiante, float n1, float n2,float n3, float n4) {//Función que le asigna a un alumno las notas de una asignatura en específico
    estudiante.setNotas(estudiante.GetNombre(), n1, n2, n3, n4);
  }
  void aprobar() {//Función que calcula la cantidad de aprobados y reprobados haciendo uso de contadores
    float promedio = 0;
    int reprobados = 0;
    int aprobados = 0;
    for (auto j = listAlumnos.begin(); j != listAlumnos.end();
         ++j) {
      for (int i = 0; i < 4; i++) {
        promedio += j->nota[j->GetNombre()][i];
      }
      if (promedio < 4) {
        reprobados = reprobados + 1;
      } else {
        aprobados = aprobados + 1;
      }
    }
  }
  void ordAlumnos() {// Se ordena los alumnos haciendo uso del promedio de estos, y se hace de manera descendiente
    for (int i = 0; i < listAlumnos.size(); i++) {
      for (int j = 0; j < listAlumnos.size(); j++) {
        if (listAlumnos[i].promArchivo() >
            listAlumnos[j].promArchivo()) {
          Alumno auxiliar = listAlumnos[i];
          listAlumnos[i] = listAlumnos[j];
          listAlumnos[j] = auxiliar;
        }
      }
    }
    for (int i = 0; i < listAlumnos.size(); i++) {
      cout << listAlumnos[i].GetNombre() << ": "
           << listAlumnos[i].promArchivo() << endl;
    }
  }
};

class Profesor : Sujeto {//Es la clase del profesor, el cual hereda los atributos de sujetos
public:
  vector<Asignatura> asigImpartidas;
  Profesor(string _nombre, string id) {
    nombre = _nombre;
    rut = id;
  }
  void Agrega_Materia(Asignatura materia){
    asigImpartidas.push_back(materia);
  }
};

int main() {//Se crean todas las variables que almacenarán la información entregada por el usuario 
  int opcion1, opcion2;
  string nombprofe;
  string rutprofe;
  string archivo1;
  ifstream archivo;
  char asignatura[100];

  char texto[50];//Se ingresa la información de los profesores
  string linea, nombre, rut, nota1, nota2, nota3, nota4;
  Profesor diego("Diego", "16.023.968-5");
  Profesor matias("Matías", "18.851.372-2");
  Profesor felipe("Felipe", "17.562.437-7");
  Profesor eduardo("Eduardo", "17.431.254-6");
  Profesor erick("Erick", "15.754.458-9");

  Asignatura paradigma1("Paradigmas de Programación", "PP005", "NRC: 8422");//Se ingresa la información de las asignaturas
  Asignatura paradigma2("Paradigmas de Programación", "PP005", "NRC: 8433");
  Asignatura desarrollo1("Desarrollo Web y Mobil", "DM004", "NRC: 1735");
  Asignatura desarrollo2("Desarrollo Web y Mobil", "DM004", "NRC: 1765");
  Asignatura algoritmo1("Algoritmo y Estructura de Datos", "AE003", "NRC: 4567");
  Asignatura algoritmo2("Algoritmo y Estructura de Datos", "AE003", "NRC: 4523");
  Asignatura datos1("Base de Datos", "BD002", "NRC: 9314");
  Asignatura datos2("Base de Datos", "BD002", "NRC: 9314");
  Asignatura progra1("Programación", "PR001", "NRC: 3567");
  Asignatura progra2("Programación", "PR001", "NRC: 3583");

  diego.Agrega_Materia(paradigma1);//Se le asignan los ramos correspondientes a los estudiantes
  matias.Agrega_Materia(algoritmo2);
  felipe.Agrega_Materia(progra1);
  eduardo.Agrega_Materia(algoritmo1);
  erick.Agrega_Materia(datos2);
  diego.Agrega_Materia(datos1);
  matias.Agrega_Materia(progra2);
  felipe.Agrega_Materia(desarrollo1);
  eduardo.Agrega_Materia(desarrollo2);
  erick.Agrega_Materia(paradigma2);

  cout << "1-Profesor\n2-Estudiante" << endl;//Se crea el menu, donde se le pregunta al usuario si es profesor o estudiante
  cin >> opcion1;
  if (opcion1 == 1) {//Como la respuesta fue 1, se pregunta la información del profesor 
    cout << "Ingrese nombre: ";
    cin >> nombprofe;
    cout << "\nIngrese rut: ";
    cin >> rutprofe;
    //-----------------//

    cout << "\n1- Ingresar notas\n2- Leer un archivo de notas\n";//Se crea un menu donde se le pregunta al profesor si quiere ingresar las notas de los estudiantes o leer un archivo de notas ya creado
    cin >> opcion2;

    if (opcion2 == 1) {//Si se ingresa la opción 1 (Ingresar notas), se solicita el nombre de la asignatura a las que se le agregarán los datos
      cout << "Ingrese el nombre de la asignatura (Con la extensión): ";
      cin >> asignatura;
      ofstream fich(asignatura);
      if (!fich) {
        cout << ("Error al crear el archivo");
        exit(EXIT_FAILURE);
      }
      string est;
      string rut;
      float nota1;
      float nota2;
      float nota3;
      float nota4;
      int numalumnos;
      cout << "Ingrese la cantidad de alumnos: \n";//Se pide ingresar la cantidad de alumnos que se agregarán
      cin >> numalumnos;

      for (int i = 0; i < numalumnos; ++i) {

        cout << "Ingrese el nombre del estudiante: ";//Se pide ingresar la información de los estudiantes, junto con sus notas.
        cin >> est;
        fich << est << " ";
        cout << "Ingrese el rut del estudiante: ";
        cin >> rut;
        fich << rut << " ";
        cout << "Ingrese la primera nota: ";
        cin >> nota1;
        fich << nota1 << " ";
        cout << "Ingrese la segunda nota: ";
        cin >> nota2;
        fich << nota2 << " ";
        cout << "Ingrese la tercera nota: ";
        cin >> nota3;
        fich << nota3 << " ";
        cout << "Ingrese la cuarta nota: ";
        cin >> nota4;
        fich << nota4 << " ";
        fich << endl;
        cout << endl;
      }
      cout << "¡Se ha generado el archivo de texto!";
    }
    
    if (opcion2 == 2){//Se solicita ingresar el nombre del archivo, para despues mostrarlo en pantalla.
      string nombArchivo;
      cout<<"Ingrese el nombre del archivo (.txt)\n";
      cin>>nombArchivo;
      archivo.open(nombArchivo);
      while (getline(archivo, linea)) {
        nombre = linea.substr(0, linea.find(" "));
        linea.erase(0, linea.find(" ") + 1);
        rut = linea.substr(0, linea.find(" "));
        linea.erase(0, linea.find(" ") + 1);
        nota1 = linea.substr(0, linea.find(" "));
        linea.erase(0, linea.find(" ") + 1);
        nota2 = linea.substr(0, linea.find(" "));
        linea.erase(0, linea.find(" ") + 1);
        nota3 = linea.substr(0, linea.find(" "));
        linea.erase(0, linea.find(" ") + 1);
        nota4 = linea.substr(0, linea.find(" "));
        linea.erase(0, linea.find(" ") + 1);
        Alumno alumno(nombre);
        alumno.setNotas(nombre,stof(nota1),stof(nota2),stof(nota3),stof(nota4));
      }
      
      
      
  } else if (opcion1 == 2) {
  } else {
    cout << "opción no válida";
  }
};
}