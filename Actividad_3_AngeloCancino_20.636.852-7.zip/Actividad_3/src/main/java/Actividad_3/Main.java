package Actividad_3;

import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Seleccione el tipo de cuenta: ");
        System.out.println("1)Cuenta Ahorro.");
        System.out.println("2)Cuenta Corriente.");
        System.out.println("3)Cuenta a plazo fijo.");
        System.out.print("Su opcion: ");
        int option = in.nextInt();
        
        if (option == 1){
            new CA();
        }
        if (option == 2){
            new CC();
        }
        if (option == 3){
            new CPF();
        }
    }
    
}