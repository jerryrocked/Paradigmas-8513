package Actividad_3;

import java.util.Scanner;
public class CPF {
  CPF(){ 
    float F_amount = 0;
    Scanner sc = new Scanner(System.in); 
    System.out.println("Seleccione el tipo de cuenta a plazo fijo: ");
    System.out.println("1)Cuenta plazo fijo de 3 meses");
    System.out.println("2)Cuenta plazo fijo de 6 meses");
    System.out.print("Su opcion: ");
    int option2 = sc.nextInt();
    System.out.print("Ingrese el monto a depositar: ");
    float amount = sc.nextFloat();
    F_amount = amount;
    if (option2 == 1){
        int x = 0;
        while (x<3){
            F_amount = (float) (F_amount * 0.012 + F_amount);
            x++;
        }
        System.out.print("En 3 meses su deposito subira a: "+F_amount);    } 
    if (option2 == 2){
        int y = 0 ;
        while (y<6){
             F_amount = (float) (F_amount * 0.012 + F_amount);
            y++;
        }
        System.out.print("En 6 meses su deposito subira a: "+F_amount);
    } 
  }
}
