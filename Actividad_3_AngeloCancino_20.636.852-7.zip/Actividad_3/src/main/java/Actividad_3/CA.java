package Actividad_3;

import java.util.Scanner;
public class CA {
  CA(){ 
    float F_amount;
    Scanner sc = new Scanner(System.in); 
    System.out.print("Ingrese el monto a depositar: ");
    float amount = sc.nextFloat();
    System.out.println("Ingrese la fecha al momento del deposito");
    System.out.print("Mes: ");
    int month = sc.nextInt();
    System.out.print("Año: ");
    int anno = sc.nextInt();
    F_amount = (float) (amount * 0.01 + amount);
    anno = anno + 1;
    System.out.print("En la fecha de "+month+"/"+anno+", su deposito subira a: "+F_amount);
  }
}