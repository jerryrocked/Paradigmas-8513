import java.util.Scanner;

public class Main {

public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
  
  System.out.println("En caso de buscar invertir en plazo fijo, la cantidad de tiempo ingresada deberá ser 3 o 6 y se tomarán como meses.");  
   
  System.out.println("\nBienvenido al banco XYZ, por favor, ingrese su rut, cantidad a invertir y el tiempo deseado para la inversión (Inserte la tecla ENTER, despues de cada dato): ");
  
    String id= sc.nextLine();
    float money=sc.nextFloat();
    int time=sc.nextInt();
   
    Calculo cuenta= new Calculo(money, id, time);
   
    System.out.println("Eliga su tipo de cuenta: \n 1) Ahorro \n 2) Corriente \n 3) Plazo fijo");
  char ele= sc.next().charAt(0);
    
    if (ele=='1'){
        cuenta.ctaAhorro();
    }
    else if(ele=='2'){
        cuenta.ctaCorriente();
    }
    else if(ele=='3'){
        cuenta.plazoFijo();
    }
   
    } 
}