public class Calculo {
   
    float money;
    String id;
    int time;
   
    public Calculo(){
   
    }
    public Calculo(float p, String r, int t){
        this.money=p;
        this.id=r;
        this.time=t;
    }
    public void ctaAhorro(){
        float cont;
        for (int i=0; i<time; i++){
            cont=money/100;
            money=money+cont;
        }
        System.out.println("Con esta cuenta generará "+money+" en "+time+" años.");
    }
    public void ctaCorriente(){
        float cont;
        for (int i=0; i<time; i++){
            cont=money/200;
            money=money+cont;
        }
        System.out.println("Con esta cuenta generará "+money+" en "+time+" años.");
    }
    public void plazoFijo(){
        if(time==3){
            float cont;
            for (int i=0; i<time; i++){
                cont=(money/100);
                cont=(float) (cont*1.2);
                money=money+cont;
        }
            System.out.println("Con esta cuenta generará "+money+" en "+time+" meses.");
        }
        else if(time==6){
            for (int i=0; i<time; i++){
                money=(float) (money*1.2);
        }
            System.out.println("Con esta cuenta generará "+money+" en "+time+" meses.");
        }
        else{
            System.out.println("El plazo de tiempo ingresado es invalido.");
        }
    }
}