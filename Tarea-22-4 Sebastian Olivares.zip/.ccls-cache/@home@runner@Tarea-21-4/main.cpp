
#include <algorithm>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <vector>

using namespace std;

class Persona
{
public:
    string nombre;
    string rut;
};

class Alumno : Persona
{
public:
    map<string, float[5]> calificaciones;

    Alumno(string nomb) { nombre = nomb; }
    void asigNotas(string name, float n1, float n2, float n3, float n4,
        float n5)
    {
        calificaciones[name][0] = n1;
        calificaciones[name][1] = n2;
        calificaciones[name][2] = n3;
        calificaciones[name][3] = n4;
        calificaciones[name][4] = n5;
    }

    float promRamo(string name)
    {
        float suma = 0;
        for (int i = 0; i < 5; i++)
        {
            suma += calificaciones[name][i];
        }
        cout << name << "\n";
        return suma / 5;
    }
    void totalProm()
    {
        for (auto it = calificaciones.begin(); it != calificaciones.end(); ++it)
        {
            cout << "Promedio final de: " << it->first << " " << promRamo(it->first)
                << endl;
        }
    }
    float obtProm()
    {
        float prom = 0;
        for (auto it = calificaciones.begin(); it != calificaciones.end(); ++it)
        {
            prom += it->second[0] + it->second[1] + it->second[2] + it->second[3] +
                it->second[4];
        }
        float resultado = (prom / 5);
        return resultado;
    }
    void promTotal()
    {
        float prom = 0;
        int aprueba = 0;
        int reprueba = 0;
        for (auto it = calificaciones.begin(); it != calificaciones.end(); ++it)
        {
            for (int i = 0; i < 5; i++)
            {
                prom += calificaciones[it->first][i];
            }
        }
        cout << (prom / 5);
    }
    string obtNom() { return this->nombre; }
};
// Clase asignatura, no hereda de nadie
class Ramo
{
public:
    string secc;
    string cod;
    string nomb;
    string prof;
    vector<Alumno> Asist;
    Ramo(string nombre, string codigo, string seccion)
    {
        cod = codigo;
        nomb = nombre;
        secc = seccion;
    }
    string obtNombre() { return this->nomb; }
    string obtSecc() { return this->secc; }
    void estCod(string cod) { this->cod = cod; }
    string obtCod() { return this->cod; }

    void agregAlum(Alumno alumno) { Asist.push_back(alumno); }
    void calAlum(Alumno& A, float n1, float n2, float n3, float n4, float n5)
    {
        A.asigNotas(A.obtNom(), n1, n2, n3, n4, n5);
    }
    void aprobReprob()
    {
        float prom;
        int aprob = 0;
        int reprob = 0;
        for (auto it = Asist.begin(); it != Asist.end(); it++)
        {
            prom = 0;
            for (int i = 0; i < 5; i++)
            {
                prom += it->calificaciones[it->obtNom()][i];
            }
            if ((prom / 5) >= 4)
            {
                aprob = aprob + 1;
            }
            else
            {
                reprob = reprob + 1;
            }
        }
        cout << aprob << "Aprobados / " << reprob << "Reprobados" << endl;
    }

    void ordAlumn()
    {
        for (int i = 0; i < Asist.size(); i++)
        {
            for (int j = 0; j < Asist.size(); j++)
            {
                if (Asist[i].obtProm() > Asist[j].obtProm())
                {
                    Alumno aux = Asist[i];
                    Asist[i] = Asist[j];
                    Asist[j] = aux;
                }
            }
        }
        for (int i = 0; i < Asist.size(); i++)
        {
            cout << Asist[i].obtNom() << ": " << Asist[i].obtProm() << endl;
        }
    }
};
// Clase profesor que hereda de persona
class Profesor : Persona
{
public:
    vector<Ramo> Pega;
    Profesor(string nomb) { nombre = nomb; }
    string obtNom() { return this->nombre; }
};

int main()
{

    // Declaraciión de variables e inicializacion de objetos
    fstream archivo;
    string rut;
    string nombre;
    string line;
    string nombProf;
    string nombAsig;
    string nombEst;
    string nombArch;
    vector<Profesor> profes;
    Profesor prof1("Jose");
    Ramo Pega("Programacion", "13001", "A");
    Ramo Pega2("Base de datos", "10003", "A");
    prof1.Pega.push_back(Pega);
    prof1.Pega.push_back(Pega2);
    profes.push_back(prof1);
    Profesor prof2("Javiera");
    Ramo Pega3("Programacion", "13002", "B");
    Ramo Pega4("Desarrollo web y movil", "89981", "B");
    prof2.Pega.push_back(Pega3);
    prof2.Pega.push_back(Pega4);
    profes.push_back(prof2);
    Profesor prof3("Tomás");
    Ramo Pega5("Algoritmo y estructura de datos", "10069", "A");
    Ramo Pega6("Paradigmas de la programacion", "10005", "B");
    prof3.Pega.push_back(Pega5);
    prof3.Pega.push_back(Pega6);
    profes.push_back(prof3);
    Profesor prof4("Sebastian");

    Ramo Pega7("Paradigmas de la programacion", "10003", "A");
    Ramo Pega8("Algoritmo y estructura de datos", "10068", "B");
    prof4.Pega.push_back(Pega7);
    prof4.Pega.push_back(Pega8);
    profes.push_back(prof4);
    Profesor prof5("Angela");
    Ramo Pega9("Desarrollo web y movil", "89980", "A");
    Ramo Pega0("Base de datos", "10005", "B");
    prof5.Pega.push_back(Pega9);
    prof5.Pega.push_back(Pega0);
    profes.push_back(prof5);

HUD:
    int opcion;
    int exstProf = 0;
    int exstAsig = 0;
    cout << "\n\nPortal de calificaciones" << endl;
    cout << "1.Profesor" << endl;
    cout << "2.Alumno" << endl;
    cout << "Seleccione la opcion que le corresponda: " << endl;
    cin >> opcion;
    // Switch para ambas opciones, tanto profesor como alumno
    switch (opcion)
    {
    case 1:
        // Solicita el nombre al profesor
        cout << "Ingrese su nombre(Ej: Cristian): " << endl;
        cin >> nombProf;
        for (int i = 0; profes.size(); i++)
        {
            if (profes[i].obtNom() == nombProf)
            {
                exstProf = 1;
                Profesor& profesor = profes[i];
                // Informa de las asignaturas que posee a disposicion el profesor para
                // calificar
                cout << "La(s) asignaturas de este profesor es(son): " << endl;
                for (int i = 0; i < profesor.Pega.size(); i++)
                {
                    cout << profesor.Pega[i].obtNombre() << " "
                        << profesor.Pega[i].obtSecc() << endl;
                }
                // Ingresa la asignatura que imparta el profesor especificado
                cout << "\nIngrese la asignatura a calificar(Ejemplo: Mecanica): "
                    << endl;
                cin.ignore(900, '\n');
                getline(cin, nombAsig, '\n');
                for (int i = 0; i < profesor.Pega.size(); i++)
                {
                    if (nombAsig == profesor.Pega[i].obtNombre())
                    {
                        exstAsig = 1;
                        // Se solicita el archivo con las notas con la extension, como
                        // bloc.txt o notas.cvs
                        cout << "\nIngrese nombre del archivo de notas(con la extension "
                            "correspondiente): "
                            << endl;
                        cin >> nombArch;
                        archivo.open(nombArch);
                        if (archivo.is_open())
                        {
                            // Lee el archivo y separa cada variable de forma individual
                            while (getline(archivo, line))
                            {
                                string nombEst = line.substr(0, line.find("/"));
                                line.erase(0, line.find("/") + 1);
                                string rut = line.substr(0, line.find("/"));
                                line.erase(0, line.find("/") + 1);
                                string n1 = line.substr(0, line.find("/"));
                                line.erase(0, line.find("/") + 1);
                                string n2 = line.substr(0, line.find("/"));
                                line.erase(0, line.find("/") + 1);
                                string n3 = line.substr(0, line.find("/"));
                                line.erase(0, line.find("/") + 1);
                                string n4 = line.substr(0, line.find("/"));
                                line.erase(0, line.find("/") + 1);
                                string n5 = line.substr(0, line.find("/"));
                                line.erase(0, line.find("/") + 1);
                                Alumno alumno(nombEst);
                                // Verificador de notas
                                if (stof(n1) < 1 || stof(n1) > 7 || stof(n2) < 1 ||
                                    stof(n2) > 7 || stof(n3) < 1 || stof(n3) > 7 ||
                                    stof(n4) < 1 || stof(n4) > 7 || stof(n5) < 1 ||
                                    stof(n5) > 7)
                                {
                                    cout
                                        << "\nWarning: Alguna(s) notas ingresadas son invalidas\n"
                                        << endl;

                                    goto HUD;
                                }
                                // Se acoplan las notas a la entidad alumno y se calcula el
                                // promedio
                                profesor.Pega[i].calAlum(alumno, stof(n1), stof(n2), stof(n3),
                                    stof(n4), stof(n5));
                                profesor.Pega[i].agregAlum(alumno);
                            }
                            archivo.close();
                            cout << "\nLectura exitosa!.\n"
                                << endl;
                            profesor.Pega[i].ordAlumn();
                            cout << "Total: ";
                            for (int i = 0; i < profesor.Pega.size(); i++)
                            {
                                if (profesor.Pega[i].Asist.size() != 0)
                                    profesor.Pega[i].aprobReprob();
                            }
                            // Da la opcion al docente de generar un archivo con los promedios
                            // de los estudiantes
                            int op;
                            cout << "\nGuardar resultados en archivo?\n"
                                << endl;
                            cout << "3.Si" << endl;
                            cout << "4.No" << endl;
                            cout << "Ingrese la opcion que desee: " << endl;
                            cin >> op;
                            // Switch case para la generacion de archivo.
                            try
                            {
                                switch (op)
                                {
                                case 3:
                                {
                                    // genera un archivo txt con los nombres de los estudiantes  que rinden la asignatura cuyo nombre es igual a nombAsig y sus promedios para ella
                                    ofstream archivo;
                                    cout << "Ingrese el nombre del archivo a generar: " << endl;
                                    cin >> nombArch;
                                    archivo.open(nombArch);
                                    if (archivo.is_open())
                                    {
                                        for (int i = 0; i < profesor.Pega.size(); i++) {
                                            if (profesor.Pega[i].obtNombre() == nombAsig) {
                                                for (int j = 0; j < profesor.Pega[i].Asist.size(); j++) {
                                                    archivo << profesor.Pega[i].Asist[j].obtNom() << " " << profesor.Pega[i].Asist[j].obtProm() << endl;
                                                }
                                            }
                                        }
                                    }
                                }
                                // Devuelve al profesor al portal de calificaciones
                                case 4:
                                {
                                    cout << " " << endl;
                                    cout << "\nVolviendo al menu....\n"
                                        << endl;
                                    cin.get();
                                    goto HUD;

                                    break;
                                }
                                }
                            }
                            catch (exception& Ex)
                            {
                                cout << "Volviendo al menu...";
                                goto HUD;
                            }
                            // Valida existencia del profesor y/o del ramo ingresado
                            if (i == profesor.Pega.size() - 1 && exstAsig == 0)
                            {
                                cout << "Esta asignatura es inexistente o no es impartida por "
                                    "el profesor, por favor intente de nuevo"
                                    << endl;
                                goto HUD;
                            }
                            else if (i == profesor.Pega.size() - 1 && exstProf == 0)
                            {
                                cout << "Este profesor no se encuentra en nuestro sistema, "
                                    "disculpe las molestias"
                                    << endl;
                                cout << "Volviendo al menu...";
                                goto HUD;
                            }
                        }
                    }
                }
            }
        }
    case 2:
    {
    menuAlumno:
        int i;
        int j;
        int k;
        // Se pide el nombre al estudiante
        cout << "Ingrese su nombre: " << endl;
        cin.ignore(900, '\n');
        getline(cin, nombEst);
        bool exst = false;
        // muestra en pantalla el promedio de las asignaturas que el alumno con el nombre ingresado ha cursado
        for (i = 0; i < profes.size(); i++)
        {
            for (j = 0; j < profes[i].Pega.size(); j++)
            {
                for (k = 0; k < profes[i].Pega[j].Asist.size(); k++)
                {
                    if (nombEst == profes[i].Pega[j].Asist[k].obtNom())
                    {
                        exst = true;
                        cout << "El promedio de " << nombEst << " en "
                            << profes[i].Pega[j].obtNombre() << " es: "
                            << profes[i].Pega[j].Asist[k].obtProm() << endl;
                    }
                }
            }
        }
        // Validar si el estudiante existe en el ramo y/o las notas han sido
        // liberadas y dar alternativas
        if (exst == false)
        {
            cout << "El estudiante no existe en el ramo o las notas aun no han sido "
                "subidas. Si desea intentarlo de nuevo, escriba retry, si desea "
                "volver al portal, escriba portal, si desea finalizar, escriba "
                "salir";
            string respuesta;
            cin >> respuesta;
            if (respuesta == "retry")
            {
                goto menuAlumno;
            }
            else if (respuesta == "portal")
            {
                goto HUD;
            }
            else if (respuesta == "salir")
            {
                return 0;
            }
        }
        int imp;
        cout << "\nGenerar archivo?\n";
        cout << "1.Si"<<endl;
        cout << "2.No"<<endl;
        cout << "Ingrese su repsuesta: ";
        cin >> imp;
        // Switch case para la escritura en el archivo
        switch (imp)
        {
        case 1:
        {
            cout << "Ingrese nombre deseado para el archivo: " << endl;
            cin >> nombArch;
            // crea un archivo txt con el nombre de las asignaturas del alumno cuyo nombre sea igual a nombEst y los promedios de dichas asignaturas
            ofstream archivo;
            archivo.open(nombArch);
            if (archivo.is_open())
            {
                for (int i = 0; i < profes.size(); i++)
                {
                    for (int j = 0; j < profes[i].Pega.size(); j++)
                    {
                        for (int k = 0; k < profes[i].Pega[j].Asist.size(); k++)
                        {
                            if (nombEst == profes[i].Pega[j].Asist[k].obtNom())
                            {
                                archivo << profes[i].Pega[j].obtNombre() << " "
                                    << profes[i].Pega[j].Asist[k].obtProm() << endl;
                            }
                        }
                    }
                }
                archivo.close();
            }
            else
            {
                cout << "No se puede abrir el archivo" << endl;
            }
        }
        case 2:
        {
            cout << "Regresando al portal";
            goto HUD;
        }
        }
    }
    }
}