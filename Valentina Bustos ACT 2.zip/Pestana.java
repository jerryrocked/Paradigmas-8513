import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
 //Valentina Bustos Astorga

public class Pestana extends JFrame{
  private JPanel fondo;
  private JButton b1, b2, b3;
  private JLabel t1, t2, t3, t4, t5, t6, t7, t8, e1;
  private JTextField itexto;
  private JCheckBox c1, c2;
  private float interes;
  private boolean mensual;
  private int meses;
  private double monto=0, ganancia=0, total=0;

  //Lo que se vera en la pestaña
  Pestana(){
    this.setSize(500, 300);//tamaño
    this.setTitle("Banco XYZ");//titulo
    setLocationRelativeTo(null);
    setResizable(false);//ver si se puede extender
    setDefaultCloseOperation(EXIT_ON_CLOSE);//que se cerre al cerrar la pestaña

    //Objetos que se veran en la pantalla
    panel();
    botones();
    texto();
    campotexto();
    ticket();
    errores();
  }

  private void panel(){//fondo
    fondo = new JPanel();
    fondo.setBackground(Color.pink);//collor
    fondo.setLayout(null);
    this.getContentPane().add(fondo);
  }

  private void botones(){//botones
    b1 = new JButton();
    b1.setText("Cuenta Ahorro");//texto boton
    b1.setBounds(10, 150, 150, 30);//tamaño
    b1.setEnabled(true);//para que sea funcional
    //b1.setForeground(Color.black);
    b1.setFont(new Font("Arial", Font.BOLD,10));//el tamaño y tipo de letra
    fondo.add(b1);//para que aparezca en el fondo

    b2 = new JButton();
    b2.setText("Cuenta Corriente");//texto boton
    b2.setBounds(175, 150, 150, 30);//tamaño
    b2.setEnabled(true);//para que sea funcional
    b2.setFont(new Font("Arial", Font.BOLD,10));//el tamaño y tipo de letra
    fondo.add(b2);//para que aparezca en el fondo

    b3 = new JButton();
    b3.setText("Cuenta a Plazo Fijo");//texto boton
    b3.setBounds(340, 150, 150, 30);//tamaño
    b3.setEnabled(true);//para que sea funcional
    //b1.setForeground(Color.black);
    b3.setFont(new Font("Arial", Font.BOLD,10));//el tamaño y tipo de letra
    fondo.add(b3);//para que aparezca en el fondo

    // AÑADE MAS BOTONES
  }

  private void texto(){
    t1 = new JLabel();
    t1.setText("Bienvenido a tu nuevo Banco.");//queria ponerlo en negritaa
    t1.setBounds(10, 10, 500, 20);
    t1.setForeground(Color.black);
    t1.setFont(new Font("Arial", Font.BOLD,16));
    fondo.add(t1);

    t2 = new JLabel();
    t2.setText("Interes anual: 1%");
    t2.setBounds(10, 175, 150, 30);
    t2.setForeground(Color.black);
    t2.setFont(new Font("Arial", Font.PLAIN,10));
    fondo.add(t2);

    t3 = new JLabel();
    t3.setText("Interes anual: 0,5%");
    t3.setBounds(175, 175, 150, 30);
    t3.setForeground(Color.black);
    t3.setFont(new Font("Arial", Font.PLAIN,10));
    fondo.add(t3);

    t4 = new JLabel();
    t4.setText("Interes mensual: 1,2%");
    t4.setBounds(340, 175, 150, 30);
    t4.setForeground(Color.black);
    t4.setFont(new Font("Arial", Font.PLAIN,10));
    fondo.add(t4);

    t5 = new JLabel();
    t5.setText("Ingresa el monto;");
    t5.setBounds(10, 70, 150, 30);
    t5.setForeground(Color.black);
    t5.setFont(new Font("Arial", Font.PLAIN,10));
    fondo.add(t5);
  
    t6 = new JLabel();
    t6.setText("Elige el plan que mas te acomode:");
    t6.setBounds(10, 115, 200, 30);
    t6.setForeground(Color.black);
    t6.setFont(new Font("Arial", Font.BOLD,10));
    fondo.add(t6);

    t7 = new JLabel();
    t7.setBounds(10, 230, 480, 30);
    t7.setForeground(Color.black);
    t7.setFont(new Font("Arial", Font.BOLD,10));
    fondo.add(t7);

    t8 = new JLabel();
    t8.setBounds(10, 250, 480, 30);
    t8.setForeground(Color.black);
    t8.setFont(new Font("Arial", Font.BOLD,10));
    fondo.add(t8);

    e1 = new JLabel();
    e1.setBounds(10, 250, 230, 30);
    e1.setForeground(Color.red);
    e1.setFont(new Font("Arial", Font.PLAIN,10));
    fondo.add(e1);
    //e1: Por favor seleccione uno de los planes
    //e2: El monto ingresado no es valido

    

    // AÑADE MAS TEXTO
  }

  private void campotexto(){
    itexto = new JTextField();
    itexto.setBounds(100, 75, 200, 20);
    fondo.add(itexto);
  }

  private void ticket(){
    c1 = new JCheckBox();
    c1.setText("3 meses");
    c1.setBounds(340, 120, 75, 30);
    c1.setFont(new Font("Arial", Font.PLAIN,10));
    c1.setBackground(Color.pink);
    fondo.add(c1);

    c2 = new JCheckBox();
    c2.setText("6 meses");
    c2.setBounds(415, 120, 75, 30);
    c2.setFont(new Font("Arial", Font.PLAIN,10));
    c2.setBackground(Color.pink);
    fondo.add(c2);
  }

  private void errores(){
    // funcion del boton para calcular
    ActionListener verErrores = new ActionListener(){
      @Override
      public void actionPerformed(ActionEvent e){
        e1.setText("");
        t7.setText("");
        t8.setText("");
        // verifica si lo del campo es numerico
        try{
          Double.parseDouble(itexto.getText());
        }catch(NumberFormatException test){
          e1.setText("Error: El monto ingresado no es valido");
        }

        // verificar si ya existe un error
        if (e1.getText() == ""){
          monto = Double.parseDouble(itexto.getText());
          // verificar que no sea negativo
          if (monto < 0){
            e1.setText("Error: El monto ingresado no es valido");
          }else if(e.getActionCommand() == "Cuenta a Plazo Fijo"){
            if (c1.isSelected() == c2.isSelected()){
              e1.setText("Error: Seleccione un periodo");
            }else{
              calcular(e.getActionCommand());
            }
          }else{
            calcular(e.getActionCommand());
          }
        }
      }
    };

    b1.addActionListener(verErrores);
    b2.addActionListener(verErrores);
    b3.addActionListener(verErrores);
  }

  private void calcular(String tipoCuenta){
    // 1
    if (tipoCuenta == "Cuenta Ahorro"){
      interes = 0.01f;
      mensual = false;
    }else if (tipoCuenta == "Cuenta Corriente"){
      interes = 0.005f;
      mensual = false;
    }else{
      interes = 0.012f;
      mensual = true;
    }

    // 2
    ganancia = 0;
    if (mensual == true){
      if (c1.isSelected() == true){
        meses = 3;
      }else{
        meses = 6;
      }
      for (int i=0; i<meses; i++){
        ganancia += (monto+ganancia)*interes;
      }
    }else{
      ganancia = (monto+ganancia)*interes;
    }
    ganancia = Math.round(ganancia*100.0)/100.0;
    total = Math.round((monto+ganancia)*100.0)/100.0;

    // 3
    t7.setText("Monto estimado ganado: "+ganancia);
    t8.setText("Monto final con intereses: "+total);

    if (mensual == true){
      t7.setText(t7.getText()+" (mensual)");
      t8.setText(t8.getText()+" (mensual)");
    }else{
      t7.setText(t7.getText()+" (anual)");
      t8.setText(t8.getText()+" (anual)");
    }
  }
}