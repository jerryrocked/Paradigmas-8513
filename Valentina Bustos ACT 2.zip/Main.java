class Main {
  public static void main(String[] args) {
    Pestana ventana = new Pestana();
    ventana.setVisible(true);
  }
}