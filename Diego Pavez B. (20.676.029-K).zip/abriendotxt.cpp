#include <fstream>
#include <string.h>
#include <conio.h>
#include <iostream>
#include <cstring>
#include <vector>
using namespace std;

int main() {
    string nombreArchivo = "tex.txt";
    ifstream archivo(nombreArchivo.c_str());
    string linea,nomb,n1,n2,n3,n4;
	double N1,N2,N3,N4;
    int res,j,i=0,x=0,p=0,lon;
    string arreglo[100];
	vector<double> lista1,lista2,lista3;
	vector<string> nombres;
    char b,l;
    
    while (getline(archivo, linea)) {
        lon = linea.length();
       	for (j=0;j<lon;j++){
			l=linea[j];
			b=' ';
       		if (l!=b){
       			if(i==0)
       				nomb=nomb+linea[j];
				if(i==1)
       				n1=n1+linea[j];
       			if(i==2)
       				n2=n2+linea[j];
       			if(i==3)
       				n3=n3+linea[j];
       			if(i==4)
       				n4=n4+linea[j];
			}
			else{
				i++;
			}
		}
		N1=stod(n1);
		N2=stod(n2);
		N3=stod(n3);
		N4=stod(n4);
		if (x==0){
			lista1.push_back(N1);
			lista1.push_back(N2);
			lista1.push_back(N3);
			lista1.push_back(N4);
			nombres.push_back(nomb);
		}
		if (x==1){
			lista2.push_back(N1);
			lista2.push_back(N2);
			lista2.push_back(N3);
			lista2.push_back(N4);
			nombres.push_back(nomb);

		}
		if (x==2){
			lista3.push_back(N1);
			lista3.push_back(N2);
			lista3.push_back(N3);
			lista3.push_back(N4);
			nombres.push_back(nomb);
		}
		x=x+1;
		i=0;
		nomb=" ";
		n1=" ";
		n2=" ";
		n3=" ";
		n4=" ";
	}
	for (int z=0;z<3;z++){
		cout<<"Las notas del estudiante "<<nombres[z]<<" son: ";
		if (z==0){
			for(int l=0;l<4;l++){
			cout<<lista1[l]<<" ";
		}
		cout<<"\n";
		}
		if (z==1){
			for(int l=0;l<4;l++){
			cout<<lista2[l]<<" ";
		}
		cout<<"\n";
		}
		if (z==2){
			for(int l=0;l<4;l++){
			cout<<lista3[l]<<" ";
		}
		cout<<"\n";
		}
	}
}

