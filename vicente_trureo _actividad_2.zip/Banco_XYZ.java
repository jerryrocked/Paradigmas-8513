import java.lang.Math;
import java.util.Scanner;
class Banco_XYZ {
  public static void main(String[] args) {    
    char res = 's';
    while (res=='s'){
        Scanner Scnnr = new Scanner(System.in);
        System.out.println("\n\nBienvenido al banco XYZ, que cuenta desea aperturar: ");
        System.out.println("1) Cuenta Ahorro");       // Para el calculo del dinero se
        System.out.println("2) Cuenta Corriente");    // utilizo la formula de interes compuesto
        System.out.println("3) Cuenta Plazo Fijo");
        System.out.print("\nElija opcion: ");
        int opcion = Scnnr.nextInt();
        switch(opcion){
          case 1:{                                     //cuenta ahorro
            System.out.print("\nIngrese el monto de dinero que desea ingresar: ");
            int cantidad1 = Scnnr.nextInt();
            System.out.print("\nCuantos años desea mantener el dinero: ");
            int año1 = Scnnr.nextInt();
            double monto1 = cantidad1*(Math.pow((1+(0.01)),año1));
            System.out.println("\nTendra un total de " + monto1 + " pesos.");
            break;
          }
          case 2:{                                  // cuenta corriente
            System.out.print("\nIngrese el monto de dinero que desea ingresar: ");
            int cantidad2 = Scnnr.nextInt();
            System.out.print("\nCuantos años desea mantener el dinero: ");
            int año2 = Scnnr.nextInt();
            double monto2 = cantidad2*(Math.pow((1+(0.005)),año2));
            System.out.println("\nTendra un total de " + monto2 + " pesos.");
            break;
          }
          case 3:{                                //plazo fijo
            System.out.print("\nIngrese el monto de dinero que desea ingresar: ");
            int cantidad3 = Scnnr.nextInt();
            System.out.println("\nPor cuantos meses desea dejar el dinero: ");
            System.out.println("1) 3 meses");
            System.out.println("2) 6 meses");
            System.out.print("\nElija opcion: ");
            int opcion2 = Scnnr.nextInt();
            switch(opcion2){
              case 1:{
                double monto3 = cantidad3*(Math.pow((1+(0.012)),3));
                System.out.println("\nTendra un total de " + monto3 + " pesos.");
                break;
              }
              case 2:{
                double monto4 = cantidad3*(Math.pow((1+(0.012)),6));
                System.out.println("\nTendra un total de " + monto4 + " pesos.");
                break;
              }
            }
            break;
          }
        }
    }
    }
  }