#include <iostream>
#include <string.h>
#include <fstream>
#include <string>
using namespace std;
//hacer un arreglo que guarde los valores numericos en float
float arreglo1[4];
float arreglo2[4];
float arreglo3[4];
float arreglo4[4];
float arreglo5[4];
float arreglo6[4];
float arreglo7[4];
int main() {
  string archivo1="archivo1.txt";
  ifstream archivo(archivo1.c_str());
  string linea,nomb,n1,n2,n3,n4,estudiante1,estudiante2,estudiante3,estudiante4,estudiante5,estudiante6,estudiante7;
  int res,lon,i,j,rep=0;
  string arreglo[100];
  char b,l;
  while(getline(archivo,linea)){
    //cout<<linea<<endl;
    lon=linea.length();
    for (i=0;i<lon;i++){
      l=linea[i];
      b=' ';
      if(l!=b){
        if(j==0)
          nomb=nomb+linea[i];
        if(j==1)
          n1=n1+linea[i];
        if(j==2)
          n2=n2+linea[i];
        if(j==3)
          n3=n3+linea[i];
        if(j==4)
          n4=n4+linea[i];
      }
      else
        j++;
    }
    float n1f = stof(n1);
    float n2f = stof(n2);
    float n3f = stof(n3);
    float n4f = stof(n4);
    if(rep==0){
      estudiante1 = nomb;
      arreglo1[0]=n1f;
      arreglo1[1]=n2f;
      arreglo1[2]=n3f;
      arreglo1[3]=n4f;
    }
    if(rep==1){
      estudiante2 = nomb;
      arreglo2[0]=n1f;
      arreglo2[1]=n2f;
      arreglo2[2]=n3f;
      arreglo2[3]=n4f;
    }
    if(rep==2){
      estudiante3 = nomb;
      arreglo3[0]=n1f;
      arreglo3[1]=n2f;
      arreglo3[2]=n3f;
      arreglo3[3]=n4f;
    }
    if(rep==3){
      estudiante4 = nomb;
      arreglo4[0]=n1f;
      arreglo4[1]=n2f;
      arreglo4[2]=n3f;
      arreglo4[3]=n4f;
    }
    if(rep==4){
      estudiante5 = nomb;
      arreglo5[0]=n1f;
      arreglo5[1]=n2f;
      arreglo5[2]=n3f;
      arreglo5[3]=n4f;
    }
    if(rep==5){
      estudiante6 = nomb;
      arreglo6[0]=n1f;
      arreglo6[1]=n2f;
      arreglo6[2]=n3f;
      arreglo6[3]=n4f;
      }
    if(rep==6){
      estudiante7 = nomb;
      arreglo7[0]=n1f;
      arreglo7[1]=n2f;
      arreglo7[2]=n3f;
      arreglo7[3]=n4f;
      }
    rep=rep+1;
    /*cout<<nomb<<endl;
    cout<<n1<<endl;
    cout<<n2<<endl;
    cout<<n3<<endl;
    cout<<n4<<endl;
    */
    j=0;
    nomb=' ';
    n1=' ';
    n2=' ';
    n3=' ';
    n4=' ';
  }
  cout<<estudiante1<<'='<<arreglo1[0]<<','<<arreglo1[1]<<','<<arreglo1[2]<<','<<arreglo1[3]<<endl;
  cout<<estudiante2<<'='<<arreglo2[0]<<','<<arreglo2[1]<<','<<arreglo2[2]<<','<<arreglo2[3]<<endl;
  cout<<estudiante3<<'='<<arreglo3[0]<<','<<arreglo3[1]<<','<<arreglo3[2]<<','<<arreglo3[3]<<endl;
  cout<<estudiante4<<'='<<arreglo4[0]<<','<<arreglo4[1]<<','<<arreglo4[2]<<','<<arreglo4[3]<<endl;
  cout<<estudiante5<<'='<<arreglo5[0]<<','<<arreglo5[1]<<','<<arreglo5[2]<<','<<arreglo5[3]<<endl;
  cout<<estudiante6<<'='<<arreglo6[0]<<','<<arreglo6[1]<<','<<arreglo6[2]<<','<<arreglo6[3]<<endl;
  cout<<estudiante7<<'='<<arreglo7[0]<<','<<arreglo7[1]<<','<<arreglo7[2]<<','<<arreglo7[3]<<endl;
}