
import java.util.InputMismatchException;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Actv3 {
    
    public static void main(String[] args){
        Scanner an = new Scanner (System.in);
        
        boolean salir = false;
        int Opcion;
        char Res = 's';
        while(Res == 's'){

            System.out.println("-------- Banco XYZ -------- ");
            System.out.println("1. Cuenta de Ahorro");
            System.out.println("2. Cuenta corriente");
            System.out.println("3. Cuenta a plazo fijo");
            System.out.println("4. Salir");
            System.out.println("\n");

            try{
                System.out.println("-----------------------");
                System.out.println("Seleccione una opción: ");
                System.out.println("-----------------------");
                Opcion = an.nextInt();
                
                switch(Opcion){
                    case 1:{
                        Scanner entrada = new Scanner(System.in);
                        int inversion;
                        int comision;
                        int ganancia;
                        System.out.println("\n----- Cuenta de Ahorro -----\n");
                        System.out.println("Las ganancias con la cuenta de ahorro son de un 1% anuales\n");
                        System.out.println("Ingrese el monto a invertir: ");
                        inversion=entrada.nextInt();
                        comision = (int) (inversion * 0.01);
                        ganancia = comision * 12;
                        System.out.println("La comision anual es de: "+ganancia);
    
                        break;
                    }
                
                    case 2:{
                        int inversion;
                        int comision;
                        int ganancia;
                        Scanner entrada = new Scanner(System.in);
                        System.out.println("----- Cuenta corriente -----\n");
                        System.out.println("Las ganancias con la cuenta corriente son de un 0,5% anuales\n");
                        System.out.println("Ingrese el monto a invertir: ");
                        inversion=entrada.nextInt();
                        comision = (int) (inversion * 0.005);
                        ganancia = comision * 12;
                        System.out.println("La comision anual es de: "+ganancia);
                    
                        break;
                    }
                
                    case 3:{
                        int tc = 0;
                        int inversion;
                        int comision;
                        int ganancia;
                        Scanner entrada = new Scanner(System.in);

                        System.out.println("--------------------------------");
                        System.out.println("1. Cuenta plazo fijo a 3 meses.");
                        System.out.println("2. Cuenta plazo fijo a 6 meses.");
                        System.out.println("Ingrese el plazo de su cuenta");
                        tc=entrada.nextInt();
                        if (tc== 1){
                            System.out.println("--- Cuenta plazo fijo a 3 meses");
                            System.out.println("Ingrese el monto a invertir: ");
                            inversion=entrada.nextInt();
                            comision = (int) (inversion * 0.012);
                            ganancia = comision * 3;
                            System.out.println("La comision a tres meses es de: "+ganancia);
                            
                            
                        }
                        else if (tc==2){
                            System.out.println("--- Cuenta plazo fijo a 6 meses");
                            System.out.println("Ingrese el monto a invertir: ");
                            inversion=entrada.nextInt();
                            comision = (int) (inversion * 0.012);
                            ganancia = comision * 6;
                            System.out.println("La comision a tres meses es de: "+ganancia);
                     
                        }
                   
                        break;
                    }
                
                    case 4:{
                        salir=true;
                        break;
                    }
                    
                    default:{
                        System.out.println("Seleccione una opción válida.");
                        //si ingresa un número que no está en el menu
                    }
                }
            }catch(InputMismatchException e){
                System.out.println("\n");
                System.out.println("Ingrese una opcion válida");
                an.next();
                //Si ingresa una palabra o carácteres 
            }
        }
            System.out.println("Saliendo del programa.");
            
        
        }
    
}



