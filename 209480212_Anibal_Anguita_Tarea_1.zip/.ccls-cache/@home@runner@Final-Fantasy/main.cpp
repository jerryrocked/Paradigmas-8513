#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>

using namespace std;

int opcion;

//LA CLASE PROFESOR ES LA CLASE DONDE SE MOSTRARAN DONDE ESTRARAN LOS VOID EN LOS CUALES SE INGRESAN LOS DATOS DEL PROFESOR Y TAMBIEN DONDE SE MOSTRARAN LOS DATOS DEL PROFESOR
class profesor{
public:
struct{
  string nombre_profesor, rut_profesor;
}prof; //NOMBRE DEL STRUC
profesor(){ };
~profesor(){ };
void datos_profesor();
void mostrar_datos_profesor();
};

//ESTE VOID LO QUE HACE ES INGRESAR LOS DATOS DEL PROFESOR, LOS CUALES SON SU NOMBRE Y SU RUT
void profesor::datos_profesor(){
  cout<<"Ingrese el nombre del profesor: "; cin>> prof.nombre_profesor;
  cout<<"Ingrese el Rut del profesor: "; cin>>prof.rut_profesor;
  cout<<endl;
};

//ESTE VOID PROFESOR LO QUE HACE ES QUE MUESTRA EN PANTALLA EL NOMBRE DEL PROFESOR Y EL RUT DEL PROFESOR
void profesor::mostrar_datos_profesor(){
  cout<<"Nombre: "<<prof.nombre_profesor<<endl;
  cout<<"Rut: "<<prof.rut_profesor<<endl;
};

//SE CREARA LA CLASE ASIGNATURA CON 1 VOID EN EL CUAL SE DESARROLLARA UNOS DATOS DE PROFESOR Y DE ASIGNATURA
class asignatura: public profesor{
public:
asignatura(){};
~asignatura(){};
void ingresar_notas();
};

//EL VOID ASIGNATURA ES PRATICAMENTE LA PARTE PRINCIPAL DEL CODIGO YA QUE EN ESTE VOID ESTA LA GRAN PARTE DEL MENU INTERACTIVO 
void asignatura::ingresar_notas(){
  //DEFINIREMOS LAS VARIABLES CON LAS CUALES TRABAJAREMOS 
  int cont=0, j=0, k;
  float promedio;
  string asignatura_profe, nomb_alumno, nota1, nota2, nota3, nota4, apellido_alumno,txt= ".txt";
  string arreglo[50];
  cout<<"Ingrese la asignatura: "; cin>>asignatura_profe;
  //AQUI SE CREA EL .TXT CON EL NOMBRE DE LA ASIGNATURA
  string nombreArchivo = asignatura_profe+txt;
  //ESTE COMANDO NOS PERMITE ESCRIBIR EN EL ARCHIVO .TXT CREADO 
  ofstream archivo;
  //ESTE COMANDO NOS PERMITE ABRIR EL ACHIVO .TXT
  archivo.open(nombreArchivo.c_str(), fstream::out);
  //GENERAMOS UN WHILE PARA PODER INGRESAR LAS NOTAS DE LOS ESTUDIANTES, EN ESTE PROGRAMA SERAN 4 ESTUDAINTES POR RAMO CON CUATRO NOTAS
  while (j<4){
    //EN ESTA PARTE SE INGRESA EL NOMBRE Y EL APELLIDO DEL ESTUDIANTE
    cout<<"Ingrese el nombre del alumno: "; cin>>nomb_alumno;
    cout<<"Ingrese el apellido del alumno: "; cin>>apellido_alumno;
    //SE INGREAN LAS NOTAS DEL ALUMNO DE CIERTA ASIGNATURA
    cout<<"Ingrese las notas del alumno "<<endl<<endl;
    cout<<"Ingrese nota 1: "; cin>>nota1;
    cout<<"Ingrese nota 2: "; cin>>nota2; 
    cout<<"Ingrese nota 3: "; cin>>nota3; 
    cout<<"Ingrese nota 4: "; cin>>nota4;
    float n1 = stof(nota1);
    float n2 = stof(nota2);
    float n3 = stof(nota3);
    float n4 = stof(nota4);
    /*promedio = (nota1+nota2+nota3+nota4)/4;
    cout<<"El alumno "<<n_alumno<<" tiene un promedio del ramo "<<asignatura_profe<<": "<<promedio;
    cout<<endl;*/
    //se ingresan los promedios de los estudiantes
    //string p(to_string(promedio));
    
    //ingresar las notas a un txt
  arreglo[0] = nomb_alumno; arreglo[1] = " ";
  arreglo[2] = apellido_alumno; arreglo[3] = " ";
  arreglo[4] = n1; arreglo[5] = " ";
  arreglo[6] = n2; arreglo[7] = " ";
  arreglo[8] = n3; arreglo[9] = " ";
  arreglo[10] = n4;

  
    cout<<"arreglo:";
    int i;
  //abro el archivo txt
  
  for (i=0;i<11;i++){
    //se va agregando las notas a un txt 
    cout<<arreglo[i];
    archivo<<arreglo[i];
  }
  archivo<<"\n";
  //se cierra el archivo
  cout<<endl;
  j++;
  }
  //se cierra el txt 
  archivo.close();
}

//ESTA ES LA CLASE ALUMNO EN LA CUAL ESTA CONFORMADA POR UN STRUC Y DOS VOID EN EL CUAL EL PRIMERO SE INGRESARAN LOS DATOS DEL ALUMNO Y EL SEGUNDO SE MOSTRARAN LOS DATOS DEL ALUMNO
class alumno{
public:
struct{
  string nombre_alumno, rut_alumno;
}alum;
alumno(){ };
~alumno(){ };
void datos_alumno();
void mostrar_datos_alumno();
};

//SE INGRESAN LOS DATOS DEL ALUMNO
void alumno:: datos_alumno(){
  cout<<"Ingrese el nombre del alumno: "; cin>> alum.nombre_alumno;
  cout<<"Ingrese el Rut del alumno: "; cin>>alum.rut_alumno;
  cout<<endl;
}

//SE MOSTRARAN LOS DATOS DEL ALUMNO
void alumno:: mostrar_datos_alumno(){
  cout<<"Nombre: "<<alum.nombre_alumno<<endl;
  cout<<"Rut: "<<alum.rut_alumno<<endl;
}

// ESTE ES EL VOID MENU, EN ESTE SE MOSTRARA EL MENU DE LA "INTRANER UNAB" DEL PROGRAMA
void menu()
{
  cout<<"¿Usted es alumno o profesor?"<<endl;
  cout<<"1) Profesor\n";
  cout<<"2) Alumno\n";
  cout<<"3) Salir\n";
  cout<<"Ingrese la opcion: "; cin>>opcion;

  switch(opcion)
  {
    case 1:{
      profesor profesor_case_1;
      asignatura asignatura_profesor_case_1;
      
      profesor_case_1.datos_profesor();
      profesor_case_1.mostrar_datos_profesor();
      asignatura_profesor_case_1.ingresar_notas();
      }
    
    case 2:{
      alumno alumno_case_2;
      alumno_case_2.datos_alumno();
      alumno_case_2.mostrar_datos_alumno();
      }

    case 3:{
      cout<<"Saliendo de Intranet Unab"<<endl;
    }
  }
}

int main() {
  menu();
}