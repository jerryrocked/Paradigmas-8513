#include <fstream>
#include <string.h>
#include <iostream>
#include <cstring>
#include<vector>
using namespace std;

int main() {
    string nombreArchivo = "tex.txt";
    ifstream archivo(nombreArchivo.c_str());
    string linea,nomb,n1,n2,n3,n4;
    int res,j,i=0,lon;
    string arreglo[100];
    char b,l;
    int y=0;
    int z=0;
    vector <float> notas,notas1,notas2;
    vector <string> estudiantes={};
    
    while (getline(archivo, linea)) {
        lon = linea.length();

       	for (j=0;j<lon;j++){
			l=linea[j];
			b=' ';
       		if (l!=b){
       			if(i==0)
       				nomb=nomb+linea[j];
				if(i==1)
       				n1=n1+linea[j];
       			if(i==2)
       				n2=n2+linea[j];
       			if(i==3)
       				n3=n3+linea[j];
       			if(i==4)
       				n4=n4+linea[j];
			}
			else{
				i++;
			}
		}
    if (y==0){
      float n5=stof(n1);
      float n6=stof(n2);
      float n7=stof(n3);
      float n8=stof(n4);
      notas.push_back(n5);
      notas.push_back(n6);
      notas.push_back(n7);
      notas.push_back(n8);
      estudiantes.push_back(nomb);
    } 
    if (y==1){
      float n5=stof(n1);
      float n6=stof(n2);
      float n7=stof(n3);
      float n8=stof(n4);
      notas1.push_back(n5);
      notas1.push_back(n6);
      notas1.push_back(n7);
      notas1.push_back(n8);
      estudiantes.push_back(nomb);
    }
    if (y==2){
      float n5=stof(n1);
      float n6=stof(n2);
      float n7=stof(n3);
      float n8=stof(n4);
      notas2.push_back(n5);
      notas2.push_back(n6);
      notas2.push_back(n7);
      notas2.push_back(n8);
      estudiantes.push_back(nomb);
    }
    y++;
		i=0;
		nomb=" ";
		n1=" ";
		n2=" ";
		n3=" ";
		n4=" ";
	}

  cout<<"\nNOMBRES ESTUDIANTES: ";
  for (z=0;z<3;z++){
    cout<<estudiantes[z];
  }

  cout<<"\nNOTAS DE "<<estudiantes[0]<<" : ";
  for (z=0;z<4;z++){
    cout<<notas[z]<<" ";
  }

  cout<<"\nNOTAS DE "<<estudiantes[1]<<" : ";
  for (z=0;z<4;z++){
    cout<<notas1[z]<<" ";
  }

  cout<<"\nNOTAS DE "<<estudiantes[2]<<" : ";
  for (z=0;z<4;z++){
    cout<<notas2[z]<<" ";
  }
}
