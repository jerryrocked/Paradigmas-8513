#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <vector>
using namespace std;

int main() {
    string archivo1="archivo1.txt";
    ifstream archivo(archivo1.c_str());   
    string linea,nombre,nO1,nO2,nO3,nO4;
    int res,lon,i,j=0;
    string arreglo[100];
    char b,l;
    

    while (getline(archivo,linea)) {
        vector<float> vector = {};
        cout<<endl;
        lon = linea.length();
        for (i=0;i<lon;i++){
            l=linea[i];
            b=' ';
            if (l!=b){
                if (j==0)
                    nombre=nombre+(linea)[i];
                if (j==1)
                    nO1=nO1+(linea[i]);
                if (j==2)
                   nO2=nO2+(linea[i]);
                if (j==3)
                   nO3=nO3+(linea[i]);
                if (j==4)
                   nO4=nO4+(linea[i]);  
                } 
            
            else
                j++;  
        }
        float nO1_float = stof(nO1); // stof TRANSFORMA DE STRING A FLOAT 
        float nO2_float = stof(nO2);
        float nO3_float = stof(nO3);
        float nO4_float = stof(nO4); 
      
        vector.push_back(nO1_float);
        vector.push_back(nO2_float);
        vector.push_back(nO3_float);
        vector.push_back(nO4_float);
      //cout<<"tamaño n1__" << sizeof(n1_float)<<endl; // comprueba que se
      //cout<<"tamaño n2__" << sizeof(n2_float)<<endl;    trasnformo en float//
      //cout<<"tamaño n3__" << sizeof(n3_float)<<endl;   
      //cout<<"tamaño n4__" << sizeof(n4_float)<<endl; 
      
        cout << nombre<<" ";
        for (int i=0; i<vector.size(); i++){
                cout<<vector[i]<< " | ";
        }
        cout<<endl;
     

        j=0;
        nombre="";
        nO1 = "";
        nO2 = "";
        nO3 = "";
        nO4 = "";
      
        nO1_float=0;
        nO2_float=0;
        nO3_float=0;
        nO4_float=0;
      
      
    }
}

 