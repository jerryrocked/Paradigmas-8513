import java.lang.Math;
import java.util.Scanner;
class actividad3 {
  public static void main(String[] args) {      //Se ha utilizado interes compuesto
        
    boolean Flag = true;
    while (Flag){
        Scanner sn = new Scanner(System.in);
        System.out.println("\n\nBienvenido al banco XYZ, que cuenta desea aperturar: ");
        System.out.println("1) Cuenta Ahorro");
        System.out.println("2) Cuenta Corriente");
        System.out.println("3) Cuenta Plazo Fijo");
        System.out.print("\nElija opcion: ");
        int opcion = sn.nextInt();
        switch(opcion){
          case 1:{
            System.out.print("\nIngrese el monto de dinero que desea ingresar: ");
            int cantidad1 = sn.nextInt();
            System.out.print("\nCuantos años desea mantener el dinero: ");
            int año1 = sn.nextInt();
            double monto1 = cantidad1*(Math.pow((1+(0.01)),año1));
            System.out.println("\nTendra un total de " + monto1 + " pesos.");
            break;
          }
          case 2:{
            System.out.print("\nIngrese el monto de dinero que desea ingresar: ");
            int cantidad2 = sn.nextInt();
            System.out.print("\nCuantos años desea mantener el dinero: ");
            int año2 = sn.nextInt();
            double monto2 = cantidad2*(Math.pow((1+(0.005)),año2));
            System.out.println("\nTendra un total de " + monto2 + " pesos.");
            break;
          }
          case 3:{
            System.out.print("\nIngrese el monto de dinero que desea ingresar: ");
            int cantidad3 = sn.nextInt();
            System.out.println("\nPor cuantos meses desea dejar el dinero: ");
            System.out.println("1) 3 meses");
            System.out.println("2) 6 meses");
            System.out.print("\nElija opcion: ");
            int opcion2 = sn.nextInt();
            switch(opcion2){
              case 1:{
                double monto3 = cantidad3*(Math.pow((1+(0.012)),3));
                System.out.println("\nTendra un total de " + monto3 + " pesos.");
                break;
              }
              case 2:{
                double monto4 = cantidad3*(Math.pow((1+(0.012)),6));
                System.out.println("\nTendra un total de " + monto4 + " pesos.");
                break;
              }
            }
            break;
          }
        }
    }
    }
  }
