import java.util.Scanner;
public class Main {
  public static void main(String[] args) {  
    Scanner myObj = new Scanner(System.in);
    System.out.println("Seleccionar tipo de cuenta");
    System.out.println("(1) CUENTA AHORRO");
    System.out.println("(2) CUENTA CORRIENTE");
    System.out.println("(3) CUENTA A PLAZO FIJO");
    System.out.println("Ingrese (1) o (2) o (3)");
    int tipocuenta = myObj.nextInt();
    if(tipocuenta==1){
      
      System.out.println("Ingrese monto inicial");
      double monto1 = myObj.nextDouble();
      System.out.println("Ingrese cantidad de años a calcular");
      int a1 = myObj.nextInt();
      double g1=(0.01);
      double ganancia1;
      int i=1;
      while(i<=a1){
        ganancia1 = g1 *monto1;
        monto1 = monto1 + ganancia1;
        i++;
      }
      System.out.println("Su monto final despues de "+a1+ " años es: ");
      System.out.println(monto1);
      
    }
    else if(tipocuenta==2){
      
      System.out.println("Ingrese monto inicial");
      double monto2 = myObj.nextDouble();
      System.out.println("Ingrese cantidad de años a calcular");
      int a2 = myObj.nextInt();
      double g2=(0.005);
      double ganancia2;
      int j=1;
      while(j<=a2){
        ganancia2 = g2 *monto2;
        monto2 = monto2 + ganancia2;
        j++;
      }
      System.out.println("Su monto final despues de "+a2+ " años es: ");
      System.out.println(monto2);
      
    }
    else if(tipocuenta==3){
      System.out.println("Ingrese monto");
      double monto3 = myObj.nextDouble();
      System.out.println("Ingrese cantidad de meses a calcular(3 o 6 meses)");
      int a3 = myObj.nextInt();
      double g3=(0.012);
      double ganancia3;
      int r=1;
      while(r<=a3){
        ganancia3 = g3 *monto3;
        monto3 = monto3 + ganancia3;
        r++;
      }
      System.out.println("Su monto final despues de "+a3+ " meses es: ");
      System.out.println(monto3);
    }
      
  }
}
