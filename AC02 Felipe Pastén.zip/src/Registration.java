import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class MyFrame
	extends JFrame
	implements ActionListener {

	private Container c;
	private JLabel title;
	private JLabel name;
	private JTextField tname;
	private JLabel capital;
	private JTextField tcapital;
	private JLabel account;
	private JComboBox s_account;
	private JRadioButton quarter;
	private JRadioButton semester;
	private JRadioButton hiddenbutton;
	private ButtonGroup buttons;
	private JLabel duration;
	private JComboBox month;
	private JLabel month_l;
	private JComboBox year;
	private JLabel year_l;
	private JButton sim;
	private JButton reset;
	private JTextArea response;
	
	private String accounts[]
		= { "CUENTA AHORRO 1% ANUAL",
			"CUENTA CORRIENTE 0.5% ANUAL",
			"CUENTA A PLAZO FIJO 1.2%"
		};


	private String months[]
        = {"0", "1", "2", "3", "4", "5",
            "6", "7", "8", "9", "10",
            "11"
		 };

	private String years[]
			= {"0", "1", "2", "3", "4", "5",
				"6", "7", "8", "9", "10"
			 };


	public MyFrame()
	{
		setTitle("SIMULADOR DE INVERSIÓN");
		setBounds(150, 90, 450, 600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);

		c = getContentPane();
		c.setLayout(null);

		title = new JLabel("BANCO XYZ");
		title.setFont(new Font("Arial", Font.PLAIN, 30));
		title.setSize(300, 30);
		title.setLocation(120, 30);
		c.add(title);

		name = new JLabel("Nombre");
		name.setFont(new Font("Arial", Font.PLAIN, 20));
		name.setSize(100, 20);
		name.setLocation(50, 100);
		c.add(name);

		tname = new JTextField();
		tname.setFont(new Font("Arial", Font.PLAIN, 15));
		tname.setSize(200, 20);
		tname.setLocation(150, 100);
		c.add(tname);

		capital = new JLabel("Capital");
		capital.setFont(new Font("Arial", Font.PLAIN, 20));
		capital.setSize(100, 20);
		capital.setLocation(50, 150);
		c.add(capital);

		tcapital = new JTextField();
		tcapital.setFont(new Font("Arial", Font.PLAIN, 15));
		tcapital.setSize(200, 20);
		tcapital.setLocation(150, 150);
		c.add(tcapital);

		account = new JLabel("<html>"+ "Tipo de cuenta" +"</html>");
		account.setFont(new Font("Arial", Font.PLAIN, 20));
		account.setSize(100, 40);
		account.setLocation(50, 200);
		c.add(account);

		s_account = new JComboBox(accounts);
		s_account.setFont(new Font("Arial", Font.PLAIN, 15));
		s_account.setSize(250, 20);
		s_account.setLocation(150, 210);
		c.add(s_account);

		quarter = new JRadioButton("3 Meses");
		quarter.setFont(new Font("Arial", Font.PLAIN, 15));
		quarter.setSelected(false);
		quarter.setSize(100, 20);
		quarter.setLocation(150, 250);
		c.add(quarter);

		semester = new JRadioButton("6 Meses");
		semester.setFont(new Font("Arial", Font.PLAIN, 15));
		semester.setSelected(false);
		semester.setSize(100, 20);
		semester.setLocation(250, 250);
		c.add(semester);

		hiddenbutton = new JRadioButton("6 Meses");
		hiddenbutton.setFont(new Font("Arial", Font.PLAIN, 15));
		hiddenbutton.setSelected(false);
		hiddenbutton.setSize(100, 20);
		hiddenbutton.setLocation(250, 250);
		hiddenbutton.setVisible(false);
		c.add(hiddenbutton);

		buttons = new ButtonGroup();
		buttons.add(quarter);
		buttons.add(semester);
		buttons.add(hiddenbutton);

		duration = new JLabel("<html>"+ "Plazo inversión" +"</html>");
		duration.setFont(new Font("Arial", Font.PLAIN, 20));
		duration.setSize(100, 40);
		duration.setLocation(50, 285);
		c.add(duration);

        year = new JComboBox(years);
        year.setFont(new Font("Arial", Font.PLAIN, 15));
        year.setSize(45, 20);
        year.setLocation(150, 300);
        c.add(year);

		year_l = new JLabel("año(s)");
		year_l.setFont(new Font("Arial", Font.PLAIN, 15));
        year_l.setSize(50, 20);
        year_l.setLocation(200, 300);
        c.add(year_l);

        month = new JComboBox(months);
        month.setFont(new Font("Arial", Font.PLAIN, 15));
        month.setSize(45, 20);
        month.setLocation(250, 300);
        c.add(month);

		month_l = new JLabel("mes(es)");
		month_l.setFont(new Font("Arial", Font.PLAIN, 15));
        month_l.setSize(70, 20);
        month_l.setLocation(300, 300);
        c.add(month_l);

		sim = new JButton("SIMULAR");
		sim.setFont(new Font("Arial", Font.PLAIN, 15));
		sim.setSize(150, 20);
		sim.setLocation(50, 350);
		sim.addActionListener(this);
		c.add(sim);

		reset = new JButton("REINICIAR");
		reset.setFont(new Font("Arial", Font.PLAIN, 15));
		reset.setSize(150, 20);
		reset.setLocation(220, 350);
		reset.addActionListener(this);
		c.add(reset);

		response = new JTextArea();
		response.setFont(new Font("Arial", Font.PLAIN, 15));
		response.setSize(300, 150);
		response.setLocation(50, 380);
		response.setLineWrap(true);
		c.add(response);

		setVisible(true);
	}

	// method actionPerformed()
	// to get the action performed
	// by the user and act accordingly
	public void actionPerformed(ActionEvent e)
	{	
		String output = "";

		if (e.getSource() == sim) {
			int selection = s_account.getSelectedIndex();
			float outcome;
			int total_months;
			// System.out.println(selection);
			switch (selection) {
				case 0:
					total_months = (year.getSelectedIndex())*12 + month.getSelectedIndex();
					outcome = Float.valueOf(tcapital.getText());
					for (int i = 0; i < total_months /12; i++) {
						outcome += outcome * 1.01;
					}
					output += tname.getText() + " tu ahorro con la inversión de cuenta:\n";
					output += s_account.getSelectedItem() + "\n";
					output += "En un tiempo de inversión de " + year.getSelectedItem() + " año(s) y " + month.getSelectedItem() + " mes(es)\n";
					output += "Renta un total de: " + (int)outcome;
					response.setText(output);
					break;
				case 1:
					total_months = (year.getSelectedIndex())*12 + month.getSelectedIndex();
					outcome = Float.valueOf(tcapital.getText());
					for (int i = 0; i < total_months /12; i++) {
						outcome += outcome * 1.005;
					}
					output += tname.getText() + " tu ahorro con la inversión de cuenta:\n";
					output += s_account.getSelectedItem() + "\n";
					output += "En un tiempo de inversión de " + year.getSelectedItem() + " año(s) y " + month.getSelectedItem() + " mes(es)\n";
					output += "Renta un total de: " + (int)outcome;
					response.setText(output);
					break;
				case 2:
					total_months = (year.getSelectedIndex())*12 + month.getSelectedIndex();
					if (quarter.isSelected()) {
						total_months = total_months - (total_months % 3);

					}
					else if (semester.isSelected()) {
						total_months = total_months - (total_months % 6);
					}
					outcome = Float.valueOf(tcapital.getText());
					for (int i = 0; i < total_months; i++) {
						outcome += outcome * 0.012;
					}
					output += tname.getText() + " tu ahorro con la inversión de cuenta:\n";
					output += s_account.getSelectedItem() + "\n";
					output += "En un tiempo de inversión de " + year.getSelectedItem() + " año(s) y " + month.getSelectedItem() + " mes(es)\n";
					output += "Renta un total de: " + (int)outcome;
					response.setText(output);
					break;
				default:
					break;
			}
		}

		else if (e.getSource() == reset) {
			String def = "";
			tname.setText(def);
			s_account.setSelectedIndex(0);
			month.setSelectedIndex(0);
			year.setSelectedIndex(0);
			hiddenbutton.setSelected(true);
			tcapital.setText(def);
			response.setText(def);
		}
	}
}

class Registration {

	public static void main(String[] args) throws Exception
	{
		MyFrame f = new MyFrame();
	}
}
