#include <iostream>
using namespace std; 
class persona{
    public:
    char nombre[40],rut[12],direccion[100],telf[10];
    int edad, opcion;
    void datos_per();
    void calculoarea();
};
  void persona::datos_per() {
    cout<<"Escriba su Nombre";
    cin.getline(nombre,40);
    cout<<"Escriba su RUT";
    cin.getline(rut,12);
    cout<<"Escriba su Dirección";
    cin.getline(direccion,100);
    cout<<"Escriba su telefono";
    cin.getline(telf,40);
    cout<<"Escriba su Edad";
    cin>>edad;    
  };  
  void persona:: calculoarea() {
  	float base,alt,area,radio,lado;
  	cout<<"Calcula el Area de:"<<endl;
  	cout<<"1. Triangulo"<<endl;
	cout<<"2. Circulo"<<endl;
	cout<<"3. Cuadrado"<<endl;
	cout<<"Seleccione una opcion: ";
	cin>>opcion;
	while (opcion){
		caso1: {
			cout<<"\n Escriba la base: ";
			cin>>base;
			cout<<"\n Escriba la Altura: ";
			cin>>alt;
			area=base*alt/2;
			cout<<"\n El Area del Triangulo es: "<<area;
			break;
		}
		caso2: {
			cout<<"\n Escriba el Radio: ";
			cin>>radio;
			area= 3.1415*radio*radio;
			cout<<"\n El Area del Circulo es: "<<area;
			break;
		}
		caso3: {
			cout<<"\n Escriba el lado: ";
			cin>>lado;
			area= lado*lado;
			cout<<"\n El Area del Circulo es: "<<area;
			break;
		}
	}
  };
int principal() {
	  char res;
  	persona p;
  	res='s';
  	if (res=='s'){
	  
  		cout<<"Ejemplo de Clases:"<<endl;
  		cout<<"1. Datos Personales"<<endl;
		  cout<<"2. Calculo de area"<<endl;
		  cout<<"Seleccione una opcion: ";
		  cin>>p.opcion;
		  switch (p.opcion){
			caso1: {
				p.datos_per();
				break;
			}
			caso2: {
				p.calculoarea();
			}
		}
		cout<<"\n Desea continuar escriba(s) o (n)";
		cin>>res;
	}
}
  
