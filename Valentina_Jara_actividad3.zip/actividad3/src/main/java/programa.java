import java.util.Scanner;
public class programa {

    public static void main(String[] args) {
        //declaracion de las variables
        boolean salir = false;
        int opc,tiempo;
        float ganancia,monto,total;
      
        Scanner sc = new Scanner(System.in);
        //bucle paa repetir el menu
        while (!salir){
            System.out.print("\n");
            System.out.print("\nBIENVENIDOS AL BANCO XYZ\n");
            System.out.print("Opcion 1: Cuenta de Ahorro\n");
            System.out.print("Opcion 2: Cuenta Corriente\n");
            System.out.print("Opcion 3: Cuenta a Plazo Fijo\n");
            System.out.print("Opcion 4: SALIR\n");
            System.out.print("Seleccione una opcion: ");
            opc = sc.nextInt();
            //switch para cada uno de los casos
            switch(opc){
                case 1:
                    System.out.print("\n");
                    System.out.print("Bienvenido al Sistema de Cuenta de Ahorro del Banco\n");
                    System.out.print("Ingrese el monto que desea depositar: ");
                    monto = sc.nextFloat();
                    ganancia = (float) ((0.01)*monto);
                    System.out.print("La ganancia es de un monto de: "+ganancia);
                    break;
                case 2:{
                    System.out.print("\n");
                    System.out.print("Bienvenido al Sistema de Cuenta Corriente del Banco\n");
                    System.out.print("Ingrese el monto que desea depositar: ");
                    monto = sc.nextFloat();
                    ganancia = (float) ((0.5/100)*monto);
                    System.out.print("La ganancia es de un monto de: "+ganancia);
                    break;
                }
                case 3:{
                    System.out.print("\n");
                    System.out.print("Bienvenido al Sistema de Cuenta a Plazo Fijo del Banco\n");
                    System.out.print("Opcion 1: 3 meses\n");
                    System.out.print("Opcion 2: 6 meses\n");
                    System.out.print("Seleccione una opcion: ");
                    tiempo = sc.nextInt();
                    //plazo fijo 3 meses
                    if (tiempo==1){
                        System.out.print("\n");
                        System.out.print("Bienvenido al Sistema de Cuenta de Plazo Fijo del Banco\n");
                        System.out.print("Ingrese el monto que desea depositar: ");
                        monto = sc.nextFloat();
                        ganancia = (float) ((0.015)*monto);
                        total = ganancia*3;
                        System.out.print("La ganancia es de un monto de: "+total);
                    }
                    //plazo fijo 6 meses
                    else if (tiempo ==2){
                        System.out.print("\n");
                        System.out.print("Bienvenido al Sistema de Cuenta de Plazo Fijo del Banco\n");
                        System.out.print("Ingrese el monto que desea depositar: ");
                        monto = sc.nextFloat();
                        ganancia = (float) ((0.015)*monto);
                        total = ganancia*6;
                        System.out.print("La ganancia es de un monto de: "+total);
                    }
                    break;
                    
                }//cierre opcion 3   
                case 4:{
                    System.out.print("\nHasta Luego");
                    salir = true;//variable verdadera para salir
                    break;
                }
            }//cierre switch
        }
    }   
}
