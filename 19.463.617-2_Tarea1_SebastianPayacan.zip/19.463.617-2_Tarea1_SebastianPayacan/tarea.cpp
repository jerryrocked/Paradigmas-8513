#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

class Persona {
public:
  string rut;
  Persona(){};
  ~Persona(){};
  void pedirRut();
};

class Estudiante : public Persona {
public:
  string NotaFinal;
  Estudiante(){};
  ~Estudiante(){};
  void datosEst();
};

class Profesor : public Persona {
public:
  char Nom_prof[40];
  Profesor(){};
  ~Profesor(){};
  void datosProf();
};
class Asignatura : public Profesor, public Estudiante {
public:
  int cantEst = 0, cantNot = 4;
  string asig_final = "";
  string secc_final = "";
  string secciones[2] = {"1", "2"};
  string asig[5] = {"PROGRAMACION", "BASE DE DATOS",
                    "ALGORITMO Y ESTRUCTURA DE DATOS", "DESARROLLO WEB Y MOVIL",
                    "PARADIGMAS DE PROGRAMACION"};
  string cod[5] = {"PR001", "BD002", "AE003", "DM004", "PP005"};
  void ingresarNot();
  void ingresarArch();
  void ArchivoNf();
};
void separador() { cout << "\n----------------------------------------------------------------\n"; }
void Persona::pedirRut() {
  cout << "\nIngrese su rut: ";
  getline(cin, rut);
  cout << endl;
};
void Profesor::datosProf() { // Consulta los nombres la cantidad de personas que
                             // se ingresen para ello.
  pedirRut();
  cout << "\nIngrese su nombre: ";
  cin.getline(Nom_prof, 40);
};

void Estudiante::datosEst() {  //Se solicitará ingresar el rut del estudiante para almacenarlo
  pedirRut();
}

void Asignatura::ArchivoNf() {
  string Nombres[cantEst];
  string Apellidos[cantEst];
  string Ruts[cantEst];
  float Notas_prom[cantEst];
  int cn;
  float aux;
  int q = 0;
  bool ord = false;
  string aux1 = "", aux2 = "", aux3 = "";
  string archexistente = asig_final + "-" + secc_final +
                         ".txt"; // Se abre archivo que se crea al momento de
                                 // introduce la opción 1.
  string archivo1 = archexistente;
  ifstream Archivo_prom(archivo1.c_str()); 
  string Linea, Nombre, Apellido, Rut, Nota_1, Nota_2, Nota_3, Nota_4;
  int Longitud, tr, Contador = 0;
  char Espacio, Caracter;
  int contador_alumn = 0;
  while (getline(Archivo_prom, Linea)) {
    vector<float> Vector_notas = {};
    cout << endl;
    Longitud = Linea.length();
    for (tr = 0; tr < Longitud; tr++) {
      Caracter = Linea[tr];
      Espacio = ' ';
      if (Caracter != Espacio) {
        if (Contador == 0)
          Nombre = Nombre + (Linea[tr]);
        if (Contador == 1)
          Apellido = Apellido + (Linea[tr]);
        if (Contador == 2)
          Rut = Rut + (Linea[tr]);
        if (Contador == 3)
          Nota_1 = Nota_1 + (Linea[tr]);
        if (Contador == 4)
          Nota_2 = Nota_2 + (Linea[tr]);
        if (Contador == 5)
          Nota_3 = Nota_3 + (Linea[tr]);
        if (Contador == 6)
          Nota_4 = Nota_4 + (Linea[tr]);
      } else
        Contador++;
    }
    float Nota1_float = stof(Nota_1);
    float Nota2_float = stof(Nota_2);
    float Nota3_float = stof(Nota_3);
    float Nota4_float = stof(Nota_4);
    float Nota_FINAL =
        (Nota1_float + Nota2_float + Nota3_float + Nota4_float) / 4;
    Vector_notas.push_back(Nota1_float);
    Vector_notas.push_back(Nota2_float);
    Vector_notas.push_back(Nota3_float);
    Vector_notas.push_back(Nota4_float);
    Nombres[contador_alumn] = Nombre;
    Apellidos[contador_alumn] = Apellido;
    Ruts[contador_alumn] = Rut;
    Notas_prom[contador_alumn] = Nota_FINAL;
    Contador = 0;
    Nombre = "";
    Apellido = "";
    Rut = "";
    Nota_1 = "";    //se creará notas vacías para ser añadidas en unas líneas más adelante.
    Nota_2 = "";
    Nota_3 = "";
    Nota_4 = "";
    Nota1_float = 0;
    Nota2_float = 0;
    Nota3_float = 0;
    Nota4_float = 0;
    contador_alumn++;
  }
  Archivo_prom.close();
  while (!ord) {
    ord = true;
    for (cn = 0; cn < cantEst - q; cn++) {
      if (Notas_prom[cn] < Notas_prom[cn + 1]) {
        aux = Notas_prom[cn];
        aux1 = Nombres[cn];
        aux2 = Apellidos[cn];
        aux3 = Ruts[cn];
        Notas_prom[cn] = Notas_prom[cn + 1];
        Nombres[cn] = Nombres[cn + 1];
        Apellidos[cn] = Apellidos[cn + 1];
        Ruts[cn] = Ruts[cn + 1];
        Notas_prom[cn + 1] = aux;
        Nombres[cn + 1] = aux1;
        Apellidos[cn + 1] = aux2;
        Ruts[cn + 1] = aux3;
        ord = false;
      }
    }
    q++;
  }
  int contadorNf = 0;
  int contApr = 0;
  int contRep = 0;
  cout << "\n--------------------------------------------\n" << endl;
  ofstream archivo_NF(asig_final + "-" + secc_final + "-NF.txt");
  for (int t = 0; t < cantEst; t++) {
    cout << Nombres[t] << " ";
    cout << Apellidos[t] << " ";
    cout << Ruts[t] << " ";
    cout << Notas_prom[t] << " " << endl; // CÁLCULO1 PROMEDIO DE NOTAS
    if (Notas_prom[t] >= 4.0) {
      contApr++;
    } else {
      contRep++;
    }
    if (contadorNf > 0) {
      archivo_NF << "\n" << Nombres[t] << " ";
    } else {
      archivo_NF << Nombres[t] << " ";
    }
    archivo_NF << Apellidos[t] << " ";
    archivo_NF << Ruts[t] << " ";
    archivo_NF << Notas_prom[t];
    contadorNf++;
  }
  cout << "\nHay un total de " << contApr << " alumnos aprobados y " << contRep
       << " alumnos reprobados.\n"
       << endl;
  cout << "\n--------------------------------------------\n" << endl;
  archivo_NF.close();
}

void Asignatura::ingresarArch() {
  cout << "\nIngrese cantidad de estudiantes en el archivo de texto: ";
  cin >> cantEst;
  cin.ignore();
  string oldname = "";
  cout << "\nEscriba el nombre del archivo de texto incluyendo al final de este '.txt': ";
  cin >> oldname;
  string linea;
  int contador_arch = 0;
  ifstream archivo_entrada(oldname);
  ofstream archivo_salida(asig_final + "-" + secc_final + ".txt");
  while (getline(archivo_entrada, linea)) {
    if (contador_arch > 0) {
      archivo_salida << "\n" << linea;
    } else {
      archivo_salida << linea;
    }
    contador_arch++;
  }
  archivo_entrada.close();
  archivo_salida.close();
}

void Asignatura::ingresarNot() {      //Con este Void se agregará a la asignatura los estudiantes y sus notas

  cout << "\nIngrese cantidad de estudiantes: ";
  cin >> cantEst;
  cin.ignore();
  ofstream archivo(asig_final + "-" + secc_final + ".txt");
  for (int i = 0; i < cantEst; i++) {
    char nombEst[40] = "";
    char rutEst[40] = "";
    cout << "\nIngrese nombre del estudiante: ";
    cin.getline(nombEst, 40);
    archivo << (string)nombEst;
    cout << "\nIngrese rut del estudiante: ";
    cin.getline(rutEst, 40);
    archivo << " " + (string)rutEst;
    for (int j = 1; j <= cantNot; j++) {
      string notaEst = "";
      cout << "\nIngrese nota " << j << ": ";
      cin >> notaEst;
      cin.ignore();
      archivo << " " + notaEst;
    }
    if (i < (cantEst - 1)) {
      archivo << "\n";
    }
  }
  archivo.close();
}

int main() {
  Profesor profe;
  Asignatura asignat;
  Persona pers;
  Estudiante estu;


  bool Flag = true;
  while (Flag) {
    string newname = "";
    separador();
    int opcion, opcion2, opcion3, opcion4, opcion5, opcion6, opcion7,
        opcion8 = 0;

    cout << "Menu de notas:\n" << endl;
    cout << "1.- Profesor" << endl;
    cout << "2.- Estudiante" << endl;
    cout << "3.- Salir del menu\n" << endl;
    cout << "Escriba la opcion: ";
    cin >> opcion;
    separador();
    cin.ignore();
    switch (opcion) {
      {
      case 1:
        separador();
        cout << "Menu de notas profesor\n" << endl;
        cout << "1.- Crear un archivo de texto con notas." << endl;
        cout << "2.- Utilizar un archivo de texto con notas preexistente."
             << endl;
        cout << "3.- Volver al menu anterior." << endl;
        cout << "Escriba la opcion: ";
        cin >> opcion2;
        cin.ignore();
        switch (opcion2) {
          {
          case 1:
            profe.datosProf();    // A partir de aquí es el proceso de la opción del Profesor.
            cout << "\nElija asignatura: \n" << endl;
            cout << "1.-" << asignat.asig[0] << endl;
            cout << "2.-" << asignat.asig[1] << endl;
            cout << "3.-" << asignat.asig[2] << endl;
            cout << "4.-" << asignat.asig[3] << endl;
            cout << "5.-" << asignat.asig[4] << endl;
            cout << "Escriba la opcion: ";
            cin >> opcion3;
            cin.ignore();
            switch (opcion3) {
              {
              case 1:
                cout << "\nElija seccion: \n" << endl;
                cout << "1.- Seccion 1" << endl;
                cout << "2.- Seccion 2" << endl;
                cout << "Escriba la opcion: ";
                cin >> opcion4;
                cin.ignore();
                switch (opcion4) {
                  {
                  case 1:
                    asignat.asig_final = asignat.cod[0];
                    asignat.secc_final = "1";
                    asignat.ingresarNot();
                    asignat.ArchivoNf();
                    break;
                  }
                  {
                  case 2:
                    asignat.asig_final = asignat.cod[0];
                    asignat.secc_final = "2";
                    asignat.ingresarNot();  
                    asignat.ArchivoNf();
                    break;
                  }
                }
                break;
              }
              {
              case 2:
                cout << "\nElija seccion: \n" << endl;
                cout << "1.- Seccion 1" << endl;
                cout << "2.- Seccion 2" << endl;
                cout << "Escriba la opcion: ";
                cin >> opcion4;
                cin.ignore();
                switch (opcion4) {
                  {
                  case 1:
                    asignat.asig_final = asignat.cod[1];
                    asignat.secc_final = "1";
                    asignat.ingresarNot();
                    asignat.ArchivoNf();
                    break;
                  }
                  {
                  case 2:
                    asignat.asig_final = asignat.cod[1];
                    asignat.secc_final = "2";
                    asignat.ingresarNot();
                    asignat.ArchivoNf();
                    break;
                  }
                }
                break;
              }
              {
              case 3:
                cout << "\nElija seccion: \n" << endl;
                cout << "1.- Seccion 1" << endl;
                cout << "2.- Seccion 2" << endl;
                cout << "Escriba la opcion: ";
                cin >> opcion4;
                cin.ignore();
                switch (opcion4) {
                  {
                  case 1:
                    asignat.asig_final = asignat.cod[2];
                    asignat.secc_final = "1";
                    asignat.ingresarNot();
                    asignat.ArchivoNf();
                    break;
                  }
                  {
                  case 2:
                    asignat.asig_final = asignat.cod[2];
                    asignat.secc_final = "2";
                    asignat.ingresarNot();
                    asignat.ArchivoNf();
                    break;
                  }
                }
                break;
              }
              {
              case 4:
                cout << "\nElija seccion: \n" << endl;
                cout << "1.- Seccion 1" << endl;
                cout << "2.- Seccion 2" << endl;
                cout << "Escriba la opcion: ";
                cin >> opcion4;
                cin.ignore();
                switch (opcion4) {
                  {
                  case 1:
                    asignat.asig_final = asignat.cod[3];
                    asignat.secc_final = "1";
                    asignat.ingresarNot();
                    asignat.ArchivoNf();
                    break;
                  }
                  {
                  case 2:
                    asignat.asig_final = asignat.cod[3];
                    asignat.secc_final = "2";
                    asignat.ingresarNot();
                    asignat.ArchivoNf();
                    break;
                  }
                }
                break;
              }
              {
              case 5:
                cout << "\nElija seccion: \n" << endl;
                cout << "1.- Seccion 1" << endl;
                cout << "2.- Seccion 2" << endl;
                cout << "Escriba la opcion: ";
                cin >> opcion4;
                cin.ignore();
                switch (opcion4) {
                  {
                  case 1:
                    asignat.asig_final = asignat.cod[4];
                    asignat.secc_final = "1";
                    asignat.ingresarNot();
                    asignat.ArchivoNf();
                    break;
                  }
                  {
                  case 2:
                    asignat.asig_final = asignat.cod[4];
                    asignat.secc_final = "2";
                    asignat.ingresarNot();
                    asignat.ArchivoNf();
                    break;
                  }
                }
                break;
              }
            }
            break;
          }
          {
          case 2:
            profe.datosProf();
            cout << "\nElija asignatura: \n" << endl;
            cout << "1.-" << asignat.asig[0] << endl;
            cout << "2.-" << asignat.asig[1] << endl;
            cout << "3.-" << asignat.asig[2] << endl;
            cout << "4.-" << asignat.asig[3] << endl;
            cout << "5.-" << asignat.asig[4] << endl;
            cout << "Escriba la opcion: ";
            cin >> opcion3;
            cin.ignore();
            switch (opcion3) {
              {
              case 1:
                cout << "\nElija seccion: \n" << endl;
                cout << "1.- Seccion 1" << endl;
                cout << "2.- Seccion 2" << endl;
                cout << "Escriba la opcion: ";
                cin >> opcion4;
                cin.ignore();
                switch (opcion4) {
                  {
                  case 1:
                    asignat.asig_final = asignat.cod[0];  
                    asignat.secc_final = "1";
                    asignat.ingresarArch();
                     
                    asignat.ArchivoNf();
                    break;
                  }
                  {
                  case 2:
                    asignat.asig_final = asignat.cod[0];
                    asignat.secc_final = "2";
                    asignat.ingresarArch();
                    asignat.ArchivoNf();
                    break;
                  }
                }
                break;
              }
              {
              case 2:
                cout << "\nElija seccion: \n" << endl;
                cout << "1.- Seccion 1" << endl;
                cout << "2.- Seccion 2" << endl;
                cout << "Escriba la opcion: ";
                cin >> opcion4;
                cin.ignore();
                switch (opcion4) {
                  {
                  case 1:
                    asignat.asig_final = asignat.cod[1];
                    asignat.secc_final = "1";
                    asignat.ingresarArch();
                    asignat.ArchivoNf();
                    break;
                  }
                  {
                  case 2:
                    asignat.asig_final = asignat.cod[1];
                    asignat.secc_final = "2";
                    asignat.ingresarArch();
                    asignat.ArchivoNf();
                    break;
                  }
                }
                break;
              }
              {
              case 3:
                cout << "\nElija seccion: \n" << endl;
                cout << "1.- Seccion 1" << endl;
                cout << "2.- Seccion 2" << endl;
                cout << "Escriba la opcion: ";
                cin >> opcion4;
                cin.ignore();
                switch (opcion4) {
                  {
                  case 1:
                    asignat.asig_final = asignat.cod[2];
                    asignat.secc_final = "1";
                    asignat.ingresarArch();
                    asignat.ArchivoNf();
                    break;
                  }
                  {
                  case 2:
                    asignat.asig_final = asignat.cod[2];
                    asignat.secc_final = "2";
                    asignat.ingresarArch();
                    asignat.ArchivoNf();
                    break;
                  }
                }
                break;
              }
              {
              case 4:
                cout << "\nElija seccion: \n" << endl;
                cout << "1.- Seccion 1" << endl;
                cout << "2.- Seccion 2" << endl;
                cout << "Escriba la opcion: ";
                cin >> opcion4;
                cin.ignore();
                switch (opcion4) {
                  {
                  case 1:
                    asignat.asig_final = asignat.cod[3];
                    asignat.secc_final = "1";
                    asignat.ingresarArch();
                    asignat.ArchivoNf();
                    break;
                  }
                  {
                  case 2:
                    asignat.asig_final = asignat.cod[3];
                    asignat.secc_final = "2";
                    asignat.ingresarArch();
                    asignat.ArchivoNf();
                    break;
                  }
                }
                break;
              }
              {
              case 5:
                cout << "\nElija seccion: \n" << endl;
                cout << "1.- Seccion 1" << endl;
                cout << "2.- Seccion 2" << endl;
                cout << "Escriba la opcion: ";
                cin >> opcion4;
                cin.ignore();
                switch (opcion4) {
                  {
                  case 1:
                    asignat.asig_final = asignat.cod[4];
                    asignat.secc_final = "1";
                    asignat.ingresarArch();
                    asignat.ArchivoNf();
                    break;
                  }
                  {
                  case 2:
                    asignat.asig_final = asignat.cod[4];
                    asignat.secc_final = "2";
                    asignat.ingresarArch();
                    asignat.ArchivoNf();
                    break;
                  }
                }
                break;
              }
            }

            break;
          }
        case 3:
          cout << "Regresando al menú anterior..." << endl;
          break;
        default:
          cout << "Introduzca una opcion valida" << endl;
        }
        break;
      }
    case 2: // A partir de aquí es el proceso de la opción Alumno.
    {
      estu.datosEst();
      int Longitud_vistest, Contador_vistest;
      string Linea_vistest, Nombre_vistest, Apellido_vistest, Rut_vistest,
          Nota_vistest;
      char Espacio_vistest, Caracter_vistest;
      int contador_pr = 0;
      int contador_bd = 0;
      int contador_ae = 0;
      int contador_dm = 0;
      int contador_pp = 0;
      for (int qw = 0; qw < 5; qw++) {
        for (int as = 0; as < 2; as++) {
          ifstream vistaest(
              (asignat.cod[qw] + "-" + asignat.secciones[as] + "-NF.txt")
                  .c_str());
          if (vistaest.is_open()) {
            int supercontador = 0;
            while (getline(vistaest, Linea_vistest)) {
               
              Contador_vistest = 0;
              Nota_vistest = ""; //Se deben reiniciar los valores para que los ruts no se junten y empiecen desde el vacío.
              Rut_vistest = ""; // "  " " " " "
              Longitud_vistest = Linea_vistest.length();
              for (int zx = 0; zx < Longitud_vistest; zx++) {

                Caracter_vistest = Linea_vistest[zx];
                Espacio_vistest = ' ';
                if (Caracter_vistest != Espacio_vistest) {
                  if (Contador_vistest == 0)
                    Nombre_vistest = Nombre_vistest + (Linea_vistest[zx]);
                  if (Contador_vistest == 1)
                    Apellido_vistest = Apellido_vistest + (Linea_vistest[zx]);
                  if (Contador_vistest == 2)
                    Rut_vistest = Rut_vistest + (Linea_vistest[zx]);
                  if (Contador_vistest == 3)
                    Nota_vistest = Nota_vistest + (Linea_vistest[zx]);

                } else {
                  Contador_vistest++;
                }
              }
              if (Rut_vistest == estu.rut) {
                float Nota_float_vistest = stof(Nota_vistest);
                ofstream archestudiante((estu.rut+".txt"),ios::app);
                archestudiante << asignat.asig[qw];                
                archestudiante << " " << Nota_float_vistest;
                if (Nota_float_vistest >= 4.0){
                  archestudiante << " " << "Aprobada\n";
                }
                else{
                  archestudiante << " " << "Reprobada\n";           
                }
                archestudiante.close();
                supercontador++;
              }
            }
            if (supercontador == 0){
              if (asignat.cod[qw] == "PR001"){
                contador_pr++;
              }
              if (asignat.cod[qw] == "BD002"){
                contador_bd++;
              }
              if (asignat.cod[qw] == "AE003"){
                contador_ae++;
              }
              if (asignat.cod[qw] == "DM004"){
                contador_dm++;
              }
              if (asignat.cod[qw] == "PP005"){
                contador_pp++;
              }
            }
            supercontador = 0;           
          }              
          else {
            ofstream archestudiante((estu.rut+".txt"),ios::app);
            if (asignat.cod[qw] == "PR001"){
              contador_pr++;
              if (contador_pr == 2){
                archestudiante << asignat.asig[qw];
                archestudiante << " El profesor no ha subido las notas.\n";
                contador_pr = 0;
              }
            }
            if (asignat.cod[qw] == "BD002"){
              contador_bd++;
              if (contador_bd == 2){
                archestudiante << asignat.asig[qw];
                archestudiante << " El profesor no ha subido las notas.\n";
                contador_bd = 0;
              }
            }
            if (asignat.cod[qw] == "AE003"){
              contador_ae++;
              if (contador_ae == 2){
                archestudiante << asignat.asig[qw];
                archestudiante << " El profesor no ha subido las notas.\n";
                contador_ae = 0;
              }
            }
            if (asignat.cod[qw] == "DM004"){
              contador_dm++;
              if (contador_dm == 2){
                archestudiante << asignat.asig[qw];
                archestudiante << " El profesor no ha subido las notas.\n";
                contador_dm = 0;
              }
            }
            if (asignat.cod[qw] == "PP005"){
              contador_pp++;
              if (contador_pp == 2){
                archestudiante << asignat.asig[qw];
                archestudiante << " El profesor no ha subido las notas.\n";
                contador_pp = 0;
              }
            }
            archestudiante.close();          
          }
        }
      }
      string LineaFinal;
      ifstream ArchivoFinal(estu.rut+".txt");
      while(getline(ArchivoFinal,LineaFinal)){
        cout << LineaFinal << "\n";
      }
      ArchivoFinal.close();
      break;
    }
  
    case 3:
      cout << "Finalizando Progama" << endl;
      Flag = false;
    default:
      cout << "Introduzca una opcion valida." << endl;
    }
  }
  return 0;
} 
