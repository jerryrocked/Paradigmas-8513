import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Matias Mora 20.787.606-2
        //Profesor Jerry Peña
       Scanner sn = new Scanner(System.in);
       int opcion = 0;//Permite seleccionar opción
       float dinero = 0;
       float total;
       
       System.out.println(" Seleccione una opción");
       System.out.println("1. Cuenta de ahorro");
       System.out.println("2. Cuenta Corriente");
       System.out.println("3. Cuenta a plazo fijo");
       System.out.println("4. Salir");
       System.out.println("Escriba una de las opciones");
       
       opcion = sn.nextInt();
       switch(opcion){
               case 1:
                   System.out.println("Ingrese monto a invertir");
                   dinero = sn.nextInt();
                   System.out.println("El total obtenido será: "+(dinero+(dinero*0.01)));                   
                   break;
               case 2:           
                   System.out.println("Ingrese monto a invertir");
                   dinero = sn.nextInt();
                   System.out.println("El total obtenido será: "+(dinero+(dinero*0.005)));
                   break;
               case 3:
                   System.out.println("Ingrese monto a invertir");
                   dinero = sn.nextInt();
                   int plan;
                   System.out.println("Seleccione una opción:");
                   System.out.println("1. Plan de 3 meses");
                   System.out.println("2. Plan de 6 meses");
                   plan = sn.nextInt();
                   if(plan == 1){
                      System.out.println("Se generará "+(((dinero*0.036))));
                      System.out.println("El total obtenido para 3 meses será: "+(dinero+((dinero*0.036)))); 
                   }if(plan == 2){
                      System.out.println("Se generará "+(((dinero*0.072))));
                      System.out.println("El saldo obtenido para 6 meses será: "+(dinero+((dinero*0.072))));
                   }
                   else{
                     System.out.println("Opción seleccionada no válida.");  
                   }             
                   break;
           }
            
             
    }
}