#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <vector>

using namespace std;

int main() {
    string archivo1 = "archivo1.txt";
    ifstream Archivo(archivo1.c_str());   
    string Linea, Nombre, Nota_1, Nota_2, Nota_3, Nota_4;
    int Longitud, i, Contador=0;
    char Espacio, Caracter;

    while (getline(Archivo,Linea)) {
        vector<float> Vector_notas = {};
        cout << endl;
        Longitud = Linea.length();
        for (i=0;i < Longitud;i++){
            Caracter = Linea[i];
            Espacio = ' ';
            if (Caracter != Espacio){
                if (Contador == 0)
                   Nombre = Nombre + (Linea[i]);
                if (Contador == 1)
                   Nota_1 = Nota_1 + (Linea[i]);
                if (Contador == 2)
                   Nota_2 = Nota_2 + (Linea[i]);
                if (Contador == 3)
                   Nota_3 = Nota_3 + (Linea[i]);
                if (Contador == 4)
                   Nota_4 = Nota_4 + (Linea[i]);  
                } 
            
            else
                Contador++;  
        }

	//Transforma nota string a float

        float Nota1_float = stof(Nota_1);
        float Nota2_float = stof(Nota_2);
        float Nota3_float = stof(Nota_3);
        float Nota4_float = stof(Nota_4); 
      
        Vector_notas.push_back(Nota1_float);
        Vector_notas.push_back(Nota2_float);
        Vector_notas.push_back(Nota3_float);
        Vector_notas.push_back(Nota4_float);
       
	//Comprueba transformacion a float, ya que float son 4 bytes.

       	//cout << "Tamaño nota1 float: " << sizeof(Nota1_float) << endl;
	//cout << "Tamaño nota2 float: " << sizeof(Nota2_float) << endl; 
        //cout << "Tamaño nota3 float: " << sizeof(Nota3_float) << endl;   
        //cout << "Tamaño nota4 float: " << sizeof(Nota4_float) << endl; 
      
        cout << Nombre <<" " ;
        for (int i=0; i < Vector_notas.size(); i++){
                cout << Vector_notas[i] << " | ";
        }
        cout << endl;
        

        Contador = 0;
        Nombre = "";
        Nota_1 = "";
        Nota_2 = "";
        Nota_3 = "";
        Nota_4 = "";
        Nota1_float = 0;
        Nota2_float = 0;
        Nota3_float = 0;
        Nota4_float = 0;        
    }
    
}