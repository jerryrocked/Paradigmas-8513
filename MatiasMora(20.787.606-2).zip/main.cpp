//Matías Mora Forcelledo
//20.787.606-2   NRC 8513
//nombre del archivo de texto debe ser notas.txt
//Formato de archivo de texto, nombre, apellido y 4 notasu
#include <iostream> 
#include <string.h>
#include <fstream>
#include <bits/stdc++.h>
#include <cmath>
#include <iomanip>
#include <cstdlib>
using namespace std;

int main()
{
  int Ingreso = 0;//coeficiente de bucle while para menu
  string archivo1 = "notas.txt";//almacena nombre de archivo
  string NOMBRE,APELLIDO;//variables ingresadas a mano
  string N[100]; //almacena nombres
  string A[100]; //almacena apellidos
  string linea, nombre,apellido,n1,n2,n3,n4;
  float nota1[200],nota2[200],nota3[200],nota4[200];
  float NOTA1,NOTA2,NOTA3,NOTA4;
  float FINALPROMEDIO[200];
  float a1,a2,a3,a4;//almacenan notas
  int res,lon,i=0,k,j=0,R = 0;
  char b,l;
  float promedio,total_promedio,total_promedio2;//almacenan el promedio de notas
  
  ifstream archivo(archivo1.c_str()); 
  
    do{//menu el cual se ingresa
    cout << "-----------------------------"<<endl;
    cout << "Seleccione una opción"<<endl;
    cout << "1 - Leer archivo de notas"<<endl;
    cout << "2 - Ingreso de alumno"<<endl;
    cout << "3 - Mostrar lista de alumnos"<<endl;
    cout << "4 - Salir"<<endl;
    cout << "-----------------------------"<<endl;
    cin >> Ingreso;
         switch(Ingreso) {
           case 1:
            cout << "-----------------------------"<<endl;
            while (getline(archivo,linea)){
              cout<<linea<< endl; 
              lon = linea.length();
              for(i = 0; i<lon;i++){
                l = linea[i];
                b = ' ';
                if(l != b){
                  if(j==0){
                    nombre = nombre+linea[i]; 
                  }
                  if(j==1){
                    apellido = apellido+linea[i];   
                  }
                  if(j==2){
                    n1 = n1+linea[i];
                    a1 = (std::stof(n1));
          
                  }
                  if (j==3){
                    n2 = n2+linea[i];
                    a2 = (std::stof(n2));
          
                  }
                  if (j==4){
                    n3 = n3+linea[i]; 
                    a3 = (std::stof(n3));         
                  }
                  if (j==5){
                    n4 = n4+linea[i];
                    a4 = (std::stof(n4));    
                  }
                }
                else
                  j++;    
              }
              
             promedio = ((a1 + a2 + a3 + a4)/4); 
             total_promedio = roundf(promedio * 10.0f)/10.0f;
             cout<<"El promedio de "<<nombre<<" "<<apellido<<" es "<<setprecision(3)<<total_promedio<<"\n";                     
             cout<<"\n";
             nombre = " ";
             apellido = " ";
             n1 =  " ";
             n2 = " ";
             n3 = " ";
             n4 = " ";
             j=0;
            }            
             break;
           case 2:
             cout << "-----------------------------"<<endl;
             cout<<"Ingrese nombre de alumno: ";
             cin>>NOMBRE;
             N[R] = NOMBRE;//se almacena el nombre en string
             cout<<"Ingrese apellido: ";
             cin>>APELLIDO;//se almacena el apellido en string
             A[R] = APELLIDO;//se apellido el nombre en string
             cout<<"Ingrese primera nota: ";
             cin>>NOTA1;
             nota1[R] = NOTA1;
             a1 = nota1[R];

             cout<<"Ingrese segunda nota: ";
             cin>>NOTA2;
             nota2[R] = NOTA2;
             a2 = nota2[R];
             
             cout<<"Ingrese tercera nota: ";
             cin>>NOTA3;
             nota3[R] = NOTA3;
             a3= nota3[R];       
             
             cout<<"Ingrese cuarta nota: ";
             cin>>NOTA4;
             nota4[R] = NOTA4;
             a4 = nota4[R];      
             
             promedio = (a1+a2+a3+a4)/4;
             total_promedio2 = roundf(promedio * 10.0f)/10.0f;
             FINALPROMEDIO[R] = total_promedio2;
             
             R++;
             break;
           case 3:
             //se muestran los nombre, apellido, notas y promedio final de los alumnos
             cout << "-----------------------------"<<endl;
             cout << "Lista de alumnos"<<endl; 
             for(j=0;j<R;j++){
               cout<<N[j]<<" "<<A[j]<<" "<<nota1[j]<<" "<<nota2[j]<<" "<<nota3[j]<<" "<<nota4[j]<<" promedio final es de: "<<FINALPROMEDIO[j]<<endl;
             }
             cout<<"\n";
             break;

           
           case 4:
             //se termina el programa y envia mensaje de despedida.
             cout << "-----------------------------"<<endl;
             cout << "🔥Hasta la próxima crack🔥👌";
             cout<<"\n";
             break;
           default:
             cout << "Seleccione una opción"<<endl;
             cout << "1 - Leer archivo de notas"<<endl;
             cout << "2 - Ingreso de alumno"<<endl;
             cout << "3 - Mostrar lista de alumnos"<<endl;
             cout << "4 - Salir"<<endl;
             cout<<"\n"<<endl;
             cin >> Ingreso;    
         }
      } while(Ingreso !=4);                            
    return EXIT_SUCCESS;
}