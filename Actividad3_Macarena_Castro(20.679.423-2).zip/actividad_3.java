//Actividad 3 Macarena Castro, 20.679.423-2
//trabajé con Milenko Krstulovic
package com.mycompany.actividad3;
import java.util.Scanner;
public class actividad_3 {

    public static void main(String[] args) {
        System.out.println("-------¡Bienvenido al Banco XYZ!-------"+"\n"+"    Tipos de cuenta que se ofrecen");
        System.out.println("       1. Cuenta de Ahorro"+"\n"+"       2. Cuenta Corriente"+"\n"+"       3. Cuenta a Plazo Fijo"+"\n"+"---------------------------------------");
        System.out.print("Escoja una opción: ");
        Scanner sc= new Scanner(System.in);
        int opcion=sc.nextInt();
        switch (opcion) {
            case 1:{
                System.out.print("\n"+"---Seleccionó la Cuenta de Ahorro---"+"\n"+"Ingrese el monto que desea depositar: ");
                float monto=sc.nextFloat();
                System.out.print("Ingrese el año del depósito: ");
                int año=sc.nextInt();
                float ganancia= monto/100;
                System.out.print("Para el año "+(año+1)+" la ganancia será de "+ganancia+" pesos");
                break;
                }
            case 2:{
                System.out.println("\n"+"---Seleccionó la Cuenta Corriente---"+"\n"+"Ingrese el monto que desea depositar: ");
                float monto=sc.nextFloat();
                System.out.print("Ingrese el año del depósito: ");
                int año=sc.nextInt();
                float ganancia= (monto*0.5f)/100;
                System.out.print("Para el año "+(año+1)+" la ganancia será de "+ganancia+" pesos");
                break;
                }
            case 3:
                System.out.print("---Seleccionó la Cuenta a Plazo Fijo---"+"\n"+"Por cuánto tiempo desea la cuenta"+"\n"+"1. Tres Meses"+"\n"+"2. Seis Meses");
                int tiempo=sc.nextInt();
            switch (tiempo) {
                case 1:{
                    System.out.print("\n"+"---Seleccionó la Cuenta a Plazo Fijo de 3 Meses---"+"\n"+"Ingrese el monto que desea depositar: ");
                    float monto=sc.nextFloat();
                    float ganancia=(monto*1.2f)/100;
                    float gananciacompl=ganancia*3;
                    System.out.print("Dentro de un mes la ganancia será de "+ganancia+" y de "+gananciacompl+" pesos en 3 meses");
                    break;
                    }
                case 2:{
                    System.out.print("\n"+"---Seleccionó la Cuenta a Plazo Fijo de 6 Meses---"+"\n"+"Ingrese el monto que desea depositar: ");
                    float monto=sc.nextFloat();
                    float ganancia= (float)((monto*1.2)/100);
                    float gananciacompl=ganancia*6;
                    System.out.println("Dentro de un mes la ganancia será de "+ganancia+" y de "+gananciacompl+" pesos en 6 meses");
                    break;
                    }
                default:
                    System.out.println("Opción no válida, cerrando programa");
                    break;
            }
break;
            default:
                System.out.println("Opción no válida, cerrando programa");
                break;
        }
    }
}