#include <iostream>
#include <string.h>
#include <fstream>
#include <vector>

using namespace std;

int main() {
    string archivo1="archivo1.txt";
    ifstream archivo(archivo1.c_str());
    string linea,nomb,n1,n2,n3,n4;
    int res,lon,i,a,j=0;
    string arreglo[100];
    char b,l;

    while (getline(archivo,linea)) {
        cout<<linea<<endl;
        lon = linea.length();
        for (i=0;i<lon;i++){
            l=linea[i];
            b=' ';
            if (l!=b){
                if (j==0)
                    nomb=nomb+linea[i];
                if (j==1)
                    n1=n1+linea[i];
                if (j==2)
                    n2=n2+linea[i];
                if (j==3)
                    n3=n3+linea[i];
                if (j==4)
                    n4=n4+linea[i];    
            }
            else
                j++;
        }
        //PASA LAS NOTAS A FLOAT
        
        float n11= std::stof(n1);
        float n22= std::stof(n2);
        float n33= std::stof(n3);
        float n44= std::stof(n4);
        //ALMACENA LAS NOTAS EN UN VECTOR
        if (a==0){
           vector<float> vector1={};
           vector<string> nombre={};
           nombre.push_back(nomb);
           vector1.push_back(n11);
           vector1.push_back(n22);
           vector1.push_back(n33);
           vector1.push_back(n44);
          //for (int i=0;vector1.size()>i;i++)
            //cout<<vector1[i]<<" ";
          //cout<<endl;
          }
        if (a==1){
           vector<float> vector2={};
           vector<string> nombre2={};
           nombre2.push_back(nomb);
           vector2.push_back(n11);
           vector2.push_back(n22);
           vector2.push_back(n33);
           vector2.push_back(n44);           
          }
        if (a==2){
           vector<float> vector3={};
           vector<string> nombre3={};
           nombre3.push_back(nomb);
           vector3.push_back(n11);
           vector3.push_back(n22);
           vector3.push_back(n33);
           vector3.push_back(n44);           
          }
        
        j=0;
        nomb=" ";
        n1=" ";
        n2=" ";
        n3=" ";
        n4=" ";
        a++;
        }
  }