// Nombre: Pedro Küpfer

/*

¡ESTE PROGRAMA FUNCIONA CONTINUAMENTE!
Si se detiene el código, el progreso de las bases de datos no se guardan.

La opción de profesor puede ingresar cualquier RUT, pero el RUT del alumno no funcionará a menos de que el profesor haya ingresado una nota con el RUT de ese alumno.

Las asignaturas se seleccionan en un listado enumerado, por lo tanto no pedirá el código de la sección ni el nombre de la asignatura.

Cuando el programa pregunta por el nombre del archivo de notas que tiene el profesor, debe ingresarse sin el ".txt".

Eso es todo :)

*/

#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
using namespace std;

// CLASES
class Persona {
  public:
    string nombre, rut;
};

class Profesor: public Persona {
  public:
    string seccion;
};

class Alumno: public Persona {
  public:
    string secciones[100];
    string promedios[100];
};

class Asignatura {
  public:
    string nombre;
    string codigo;
};

// BASES DE DATOS
Alumno alumnos[1000];
Asignatura asignaturas[5];

string asig[5]  ={"Programación", "Base de Datos", "Algoritmo y E.", "Desarrollo Web", "Paradigmas de P."};
string cod[5]   ={"PR001", "BD002", "AE003", "DM004", "PP005"};

// Busca la posición del alumno en la base de datos dependiendo de su rut (si no existe le asigna la última posición)
int pos_alumno(string rut){
  int i=0;
  while (alumnos[i].rut != "" && alumnos[i].rut != rut){
    i++;
  }
  return i;
}

// Comprueba si el alumno existe dependiendo de su rut
bool alumno_existe(string rut){
  int i=0;
  while (alumnos[i].rut != ""){
    if (alumnos[i].rut == rut){
      return true;
    }
    i++;
  }
  return false;
}

// Agrega un alumno y/o sus datos a la base de datos
void agregar_alumno(string nombre, string rut, string seccion, float promedio){
  int pos = pos_alumno(rut);
  Alumno alumno = alumnos[pos];

  if (!alumno_existe(rut)){
    alumno.nombre = nombre;
    alumno.rut = rut;
  }

  int i = 0;
  while (alumno.secciones[i] != ""){
    i++;
  }
  alumno.secciones[i] = seccion;
  alumno.promedios[i] = to_string(promedio);

  alumnos[pos] = alumno;
};

// Comprueba si existe un archivo a partir del nombre
bool archivo_existe(string nombre){
	ifstream archivo(nombre.c_str());
	return archivo.good();
}

// Busca el nombre de la asignatura con el código de la sección
string nombre_seccion(string codigo){
  for (int i=0; i<5; i++){
    Asignatura a = asignaturas[i];
    if (a.codigo == codigo){
      return a.nombre;
    }
  }
  return "";
}

// Comprueba si el alumno tiene promedio en cierta asignatura
bool tiene_promedio(string codigo, Alumno alumno){
  int i=0;
  while (alumno.secciones[i] != ""){
    if (alumno.secciones[i] == codigo){
      return true;
    }
    i++;
  }
  return false;
}

// Está definida más abajo del código
void preguntar_persona();

// Código del profesor para subir las notas del alumno y recibir los promedios
void opcion_profesor(){
  Profesor profesor;
  Asignatura asignatura;
  string nombre_profe, apellido_profe, nombre_txt;

  // Muestra las opciones de asignaturas
  int n_asig=0;
  string temp;
  while (!(n_asig >= 1 && n_asig <= 5)){
    for (int i=0; i<5; i++){
      cout << "\n" << i+1 << ". " << asig[i];
    };
    cout << "\n\nIntroduzca el número de la asignatura: ";
    cin >> temp;
    // Forma rara de transformar string a int
    if (isdigit(temp[0])){
      n_asig = temp[0]-'0';
    }
  }
  profesor.seccion = cod[n_asig-1];

  // Pide los datos del profesor
  /*cout << "\nIntroduzca su nombre y apellido: ";
  cin >> nombre_profe >> apellido_profe;
  profesor.nombre = nombre_profe + " " + apellido_profe;*/
  cout << "\nIntroduzca su RUT: ";
  cin >> profesor.rut;

  // Pide el archivo de las notas
  do{
    cout << "\nIntroduzca el nombre del archivo de notas (sin el .txt): ";
    cin >> nombre_txt;
    nombre_txt += ".txt";
  }while (!archivo_existe(nombre_txt));

  ifstream archivo(nombre_txt.c_str());
  string linea, lista_alumno[100];
  float lista_promedio[100];
  int fila = 0;

  // Lee el archivo de las notas
  while (getline(archivo,linea)){
    Alumno alumno;
    string n[100];
    char l, b=' ';
    int lon, j=0;
    lon = linea.length();
    
    for (int i=0; i<lon; i++){
      l=linea[i];
      if (l!=b){
        if (j==0 || j==1)
          alumno.nombre += linea[i];
        if (j==2)
          alumno.rut += linea[i];
        if (j>=3)
          n[j-3] += linea[i];   
      }
      else{
        if (j==0)
          alumno.nombre += " ";
        j++;
      }
    }
    
    // Calcula el promedio de las notas
    float promedio, suma=0;
    int n_notas = j-2;
    for (int i=0; i<n_notas; i++){
      suma += stof(n[i]);
    }
    promedio = ceil((suma/n_notas)*100)/100;

    // Almacena datos en la matriz alumno_promedio
    lista_alumno[fila] = alumno.nombre;
    lista_promedio[fila] = promedio;

    // Registra el alumno, su asignatura y promedio
    agregar_alumno(alumno.nombre, alumno.rut, profesor.seccion, promedio);
    
    fila++;
  }
  
  // Crea un nuevo archivo de promedios
  ofstream file_promedios;
  string nombre_archivo = "Promedios_"+profesor.seccion;
  file_promedios.open(nombre_archivo.c_str());

  // Ordena los promedios
  int i=0, pos=0, j=0, aprobados=0, reprobados=0;
  do{
    float mayor = 0;
    i = 0;
    while (lista_alumno[i] != ""){
      if (lista_promedio[i] > mayor){
        mayor = lista_promedio[i];
        pos = i;
      }
      i++;
    }
    file_promedios << lista_alumno[pos] << "\t";
    file_promedios << lista_promedio[pos] << "\n";
    lista_promedio[pos] = -1;
    j++;

    // Cuenta los aprobados/reprobados
    if (mayor >= 4.0){
      aprobados += 1;
    }else{
      reprobados += 1;
    }
  }while (lista_alumno[pos+1] != "");

  // Muestra la cantidad de aprobados/reprobados
  cout << "\nAlumnos que aprobaron: " << aprobados;
  cout << "\nAlumnos que reprobaron: " << reprobados << endl;

  // Cerramos el archivo para guardar
  file_promedios.close();

  // Pregunta si quiere continuar o cerrar el programa
  string opcion;
  while (opcion != "y" && opcion != "x"){
    cout << "\n¿Desea continuar (y) o cerrar el programa (x)?: ";
    cin >> opcion;

    if (opcion == "y"){
      preguntar_persona();
    }
  }
};

// Código del alumno para solicitar las notas y recibirlas
void opcion_alumno(){
  // Pide el rut y comprueba si existe en la base de datos
  string rut;
  while (!alumno_existe(rut)){
    cout << "\nIntroduzca su RUT: ";
    cin >> rut;
  }

  // Define la variable de alumno con sus datos
  int pos = pos_alumno(rut);
  Alumno alumno = alumnos[pos];

  // Crea el archivo de notas
  ofstream file_notas;
  string nombre_archivo = "Notas_"+alumno.rut;
  file_notas.open(nombre_archivo.c_str());

  // Rellena el archivo con las asignaturas, sus promedios y resultados
  for (int i=0; i<5; i++){
    Asignatura asig = asignaturas[i];
    file_notas << asig.nombre << "\t";

    if (tiene_promedio(asig.codigo, alumno)){
      float promedio=0;
      int j=0;
      while (j<5 && promedio == 0){
        if (alumno.secciones[j] == asig.codigo){
          promedio = stof(alumno.promedios[j]);
        }
        j++;
      }
      file_notas << promedio << "\t";

      if (promedio >= 4){
        file_notas << "Aprobada" << "\n";
      }else{
        file_notas << "Reprobada" << "\n";
      }
    }else{
      file_notas << "[Pendiente]" << "\n";
    }
  }

  // Cerramos el archivo para guardar
  file_notas.close();

  // Pregunta si quiere continuar o cerrar el programa
  string opcion;
  while (opcion != "y" && opcion != "x"){
    cout << "\n¿Desea continuar (y) o cerrar el programa (x)?: ";
    cin >> opcion;

    if (opcion == "y"){
      preguntar_persona();
    }
  }
};

// Comprueba si el usuario es un profesor o un alumno
void preguntar_persona(){
  string opcion;

  while (opcion != "p" && opcion != "a"){
    cout << "\n¡Bienvenido a la entrega de notas!\n¿Eres Profesor (p) o Alumno (a)?: ";
    cin >> opcion;

    // Divide las opciones en diferentes funciones
    if (opcion == "p"){
      opcion_profesor();
    }else if (opcion == "a"){
      opcion_alumno();
    }
  }
}

// Crea las clases de asignaturas y los almacena en la base de datos
void crear_asignaturas(){
  for (int i=0; i<5; i++){
    Asignatura asignatura;
    asignatura.nombre = asig[i];
    asignatura.codigo = cod[i];
    asignaturas[i] = asignatura;
  }
};

// Inicializa las funciones
int main() {
  crear_asignaturas();
  preguntar_persona();
}