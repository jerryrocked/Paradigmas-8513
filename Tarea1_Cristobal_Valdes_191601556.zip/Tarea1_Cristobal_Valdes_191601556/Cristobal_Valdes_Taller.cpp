#include<iostream>
#include<string>
#include<string.h>
#include<fstream>
#include<iomanip>
using namespace std;


class Asignatura{ //CLASE ASIGNATURAS
    public:
    string asig[5]={"PROGRAMACION","BASE DE DATOS","ALGORTIMO Y ESTRUCTURA DE DATOS","DESARROLLO WEB Y MOVIL","PARADICMAS DE PROGRAMACION"};
    string cod[5]={"PR001","BD002","AE003","DM004","PP005"};
    int i;
    int z;
    int Code;
    int opc=0;

    //ALMACENAMIENTO NOTAS //
    
    //ASIGNATURAS //
    //string notaPro, notaB, notaA, notaD, notaPar;
    string LeerAsig;

        //Programacion
    string notaPro1, notaPro2, notaPro3, notaPro4, nombreP;
    string notaProA1[500], notaProA2[500], notaProA3[500], notaProA4[500], nombrePA[500];
    float arrP1,arrP2,arrP3,arrP4;

        //Base de datos
    string notaB1, notaB2, notaB3, notaB4, nombreB;
    string notaBA1[500], notaBA2[500], notaBA3[500], notaBA4[500], nombreBA[500];
    float arrB1,arrB2,arrB3,arrB4;

        //Algoritmos
    string notaA1, notaA2, notaA3, notaA4, nombreA;   
    string notaAA1[500], notaAA2[500], notaAA3[500], notaAA4[500], nombreAA[500];
    float arrA1,arrA2,arrA3,arrA4; 

        //Desarrollo Web
    string notaD1, notaD2, notaD3, notaD4, nombreD;
    string notaDA1[500], notaDA2[500], notaDA3[500], notaDA4[500], nombreDA[500];
    float arrD1,arrD2,arrD3,arrD4;

        //Paradicmas
    string notaPar1, notaPar2, notaPar3, notaPar4, nombrePar;
    string notaParA1[500], notaParA2[500], notaParA3[500], notaParA4[500], nombreParA[500];
    float arrPA1,arrPA2,arrPA3,arrPA4; 


    //CREAR TXT


    void Mostrar_Asig();
};


void Asignatura::Mostrar_Asig(){  //MENU ASIGNATURA - PARTE ALUMNOS 

    cout<<"INGRESA EL NUMERO CORRESPONDIENTE: "<<endl;
    cout<<"1) PROGRAMACION"<<endl;
    cout<<"2) BASE DE DATOS"<<endl;
    cout<<"3) ALGORTIMO Y ESTRUCTURA DE DATOS"<<endl;
    cout<<"4) DESARROLLO WEB Y MOVIL"<<endl;
    cout<<"5) PARADICMAS DE PROGRAMACION"<<endl;
    cout<<" "<<endl;
    cout<<"Ingrese Opcion: ";
    cin>>Code;
    cout<<"\n";

    if(Code == 1){
        cout<<"Asignatura : "<<asig[0]<<" --> "<<"Su codigo es: "<<cod[0]<<endl;
        cout<<"\n";
    }
    if(Code == 2){
        cout<<"Asignatura : "<<asig[1]<<" --> "<<"Su codigo es: "<<cod[1]<<endl;
        cout<<"\n";
    }
    if(Code == 3){
        cout<<"Asignatura : "<<asig[2]<<" --> "<<"Su codigo es: "<<cod[2]<<endl;
        cout<<"\n";
    }
    if(Code == 4){
        cout<<"Asignatura : "<<asig[3]<<" --> "<<"Su codigo es: "<<cod[3]<<endl;
        cout<<"\n";
    }
    if(Code == 5){
        cout<<"Asignatura : "<<asig[4]<<" --> "<<"Su codigo es: "<<cod[4]<<endl;
        cout<<"\n";
    }

    if(Code > 5){
        cout<<"No existe esta opcion..."<<endl;
        cout<<"\n";
    }
};

class Persona{ //CLASE PERSONA
    public:
    string nombre,rut,direccion,telefono;
    string n[200];
    int edad;
    int iniciador;
    void Ingresar_Datos();
    void Mostrar_Datos();
};

void Persona::Ingresar_Datos(){ //PEDIR DATOS PROFE O ALUMNO
    cout<<"Escriba su Nombre: "<<endl;
    getline(cin,nombre);
    n[iniciador]=nombre;
    cout<<"Escriba su RUT: "<<endl;
    getline(cin,rut);
    cout<<"Escriba su Direccion: "<<endl;
    getline(cin,direccion);
    cout<<"Escriba su Telefono: "<<endl;
    getline(cin,telefono);
    cout<<"Escriba su Edad: "<<endl;
    cin>>edad;
    cout<<"______________________";
};

void Persona::Mostrar_Datos(){  //MOSTRAR LOS DATOS PROFE O ALUMNO
    cout<<"Nombre: "<<nombre<<endl;
    cout<<"RUT: "<<rut<<endl;
    cout<<"Direccion: "<<direccion<<endl;
    cout<<"Telefono: "<<telefono<<endl;
    cout<<"Edad: "<<edad<<endl;
};

class Menus : virtual public Asignatura{  //CLASE MENUS (PROFE Y ALUMNO)
    public:
    string linea,nomb,n1,n2,n3,n4;
    string nombreE, notaE1, notaE2, notaE3, notaE4; // Nombre Alumno
    string almNom[100], almN1[100], almN2[100], almN3[100], almN4[100]; // Arreglos
    float arr1,arr2,arr3,arr4,promedio,suma;
    float ProE,ProTotal[1000];

    int res,lon,ini,jo;
    int i=0;
    int j;
    int opcion = 0;
    int opc=0;
    int opcE=0;
    char b,l;

    //ESTUDIANTE //

    string Alumno, Asignatura, SeccionA, SeccionB, Codigo, Nombres;
    string AsignaturaA[100], SeccionAA[100], SeccionBB[100], CodigoA[100];


    // VOID MENU // 

    void menu_principal(); // No ocupar por ahora // 
    void menu_profesor();
    void menu_profesor_1();
    void menu_profesor_2();
    void menu_profesor_3();

    void menu_estudiante();
    void menu_estudiante_1();
    void menu_estudiante_2();
    void menu_estudiante_3();
    
};

void Menus::menu_profesor(){    ///MENU PROFESOR
    cout<<"\n";
    cout<<"(INGRESE UNA DE LAS OPCIONES)"<<endl;
    cout<<"1) Ingreso de Notas"<<endl;
    cout<<"2) Mostrar Notas de los Alumnos"<<endl;
    cout<<"3) Leer TxT"<<endl;
    cout<<"4) --- OPCION EN ARREGLO ---"<<endl;
    cout<<"5) Volver"<<endl;
    cout<<"Ingrese Opcion: ";
    cin>>opc;
};

void Menus::menu_profesor_1(){ //MENU PROFE OPC 1
            cout<<"Ingrese Codigo de la asignatura que desea ingresar notas: ";
            cin>>Codigo;
            CodigoA[i]=Codigo;

            if(CodigoA[i]==cod[0]){     //Ingrese N° Programacion
                cout<<"\n";
                cout<<"PROGRAMACION"<<endl;
                cout<<"\n";
                cout<<"Ingrese nombre del alumno: ";
                cin>>nombreP;
                nombrePA[i]=nombreP;
                cout<<"___________________________"<<endl;

                cout<<"Ingrese nota 1: ";
                cin>>notaPro1;
                notaProA1[i]=notaPro1;
                arrP1 = std::stof(notaPro1); // Arreglo Fload

                cout<<"Ingrese nota 2: ";
                cin>>notaPro2;
                notaProA2[i]=notaPro2;
                arrP2 = std::stof(notaPro2); // Arreglo Fload

                cout<<"Ingrese nota 3: ";
                cin>>notaPro3;
                notaProA3[i]=notaPro3;
                arrP3 = std::stof(notaPro3);

                cout<<"Ingrese nota 4: ";
                cin>>notaPro4;
                notaProA4[i]=notaPro4;
                arrP4 = std::stof(notaPro4);

                ProE = ((arrP1 + arrP2 + arrP3 + arrP4)/4);
                ProTotal[i] = ProE;
                i++;
            }

            else if(CodigoA[i]==cod[1]){    //Ingreso N° Bases
                cout<<"\n";
                cout<<"BASE DE DATOS"<<endl;
                cout<<"\n";
                cout<<"Ingrese nombre del alumno: ";
                cin>>nombreB;
                nombreBA[i]=nombreB;
                cout<<"___________________________"<<endl;

                cout<<"Ingrese nota 1: ";
                cin>>notaB1;
                notaBA1[i]=notaB1;
                arrB1 = std::stof(notaB1); // Arreglo Fload

                cout<<"Ingrese nota 2: ";
                cin>>notaB2;
                notaBA2[i]=notaB2;
                arrB2 = std::stof(notaB2); // Arreglo Fload

                cout<<"Ingrese nota 3: ";
                cin>>notaB3;
                notaBA3[i]=notaB3;
                arrB3 = std::stof(notaB3);

                cout<<"Ingrese nota 4: ";
                cin>>notaB4;
                notaBA4[i]=notaB4;
                arrB4 = std::stof(notaB4);

                ProE = ((arrB1 + arrB2 + arrB3 + arrB4)/4);
                ProTotal[i] = ProE;
                i++;
            }

            else if(CodigoA[i]==cod[2]){    //Ingreso N° Algoritmos
                cout<<"\n";
                cout<<"ALGORTIMO Y ESTRUCTURA DE DATOS"<<endl;
                cout<<"\n";
                cout<<"Ingrese nombre del alumno: ";
                cin>>nombreE;
                almNom[i]=nombreE;
                cout<<"___________________________"<<endl;

                cout<<"Ingrese nota 1: ";
                cin>>notaA1;
                notaAA1[i]=notaA1;
                arrA1 = std::stof(notaA1); // Arreglo Fload

                cout<<"Ingrese nota 2: ";
                cin>>notaA2;
                notaAA2[i]=notaA2;
                arrA2 = std::stof(notaA2); // Arreglo Fload

                cout<<"Ingrese nota 3: ";
                cin>>notaA3;
                notaAA3[i]=notaA3;
                arrA3 = std::stof(notaA3);

                cout<<"Ingrese nota 4: ";
                cin>>notaA4;
                notaAA4[i]=notaA4;
                arrA4 = std::stof(notaA4);

                ProE = ((arrA1 + arrA2 + arrA3 + arrA4)/4);
                ProTotal[i] = ProE;
                i++;
            }

            else if(CodigoA[i]==cod[3]){    //Ingreso N° Desarrollo
                cout<<"\n";
                cout<<"DESARROLLO WEB Y MOVIL"<<endl;
                cout<<"\n";
                cout<<"Ingrese nombre del alumno: ";
                cin>>nombreE;
                almNom[i]=nombreE;
                cout<<"___________________________"<<endl;

                cout<<"Ingrese nota 1: ";
                cin>>notaD1;
                notaDA1[i]=notaD1;
                arrD1 = std::stof(notaD1); // Arreglo Fload

                cout<<"Ingrese nota 2: ";
                cin>>notaD2;
                notaDA2[i]=notaD2;
                arrD2 = std::stof(notaD2); // Arreglo Fload

                cout<<"Ingrese nota 3: ";
                cin>>notaD3;
                notaDA3[i]=notaD3;
                arrD3 = std::stof(notaD3);

                cout<<"Ingrese nota 4: ";
                cin>>notaD4;
                notaDA4[i]=notaD4;
                arrD4 = std::stof(notaD4);

                ProE = ((arrD1 + arrD2 + arrD3 + arrD4)/4);
                ProTotal[i] = ProE;
                i++;
            }

            else if(CodigoA[i]==cod[4]){    //Ingreso N° Paradicmas
                cout<<"\n";
                cout<<"PARADICMAS DE PROGRAMACION"<<endl;
                cout<<"\n";
                cout<<"Ingrese nombre del alumno: ";
                cin>>nombreE;
                almNom[i]=nombreE;
                cout<<"___________________________"<<endl;

                cout<<"Ingrese nota 1: ";
                cin>>notaPar1;
                notaParA1[i]=notaPar1;
                arrPA1 = std::stof(notaPar1); // Arreglo Fload

                cout<<"Ingrese nota 2: ";
                cin>>notaPar2;
                notaParA2[i]=notaPar2;
                arrPA2 = std::stof(notaPar2); // Arreglo Fload

                cout<<"Ingrese nota 3: ";
                cin>>notaPar3;
                notaParA3[i]=notaPar3;
                arrPA3 = std::stof(notaPar3);

                cout<<"Ingrese nota 4: ";
                cin>>notaPar4;
                notaParA4[i]=notaPar4;
                arrPA4 = std::stof(notaPar4);

                ProE = ((arrPA1 + arrPA2 + arrPA3 + arrPA4)/4);
                ProTotal[i] = ProE;
                i++;
            }

            else{       // ERROR
                cout<<"_____________________";
                cout<<"\n";
                cout<<"INGRESE CODIGO CORRESPONDIENTE"<<endl;
                cout<<"\n";
            }

};

void Menus::menu_profesor_2(){ //MENU PROFE OPC 2
    cout<<"\n";
    cout<<"Ingrese Codigo Asigatura: ";
    cin>>LeerAsig;
    cout<<"\n";
 
    for(int j=0;j<i;j++){
        if(LeerAsig == cod[0]){
            cout<<"-> "<<nombrePA[j]<<" - "<<notaProA1[j]<<" - "<<notaProA2[j]<<" - "<<notaProA3[j]<<" - "<<notaProA4[j]<<endl; //" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;;
            cout<<"\n"<<endl;
        
        }
        else if(LeerAsig == cod[1]){
            cout<<"-> "<<nombreBA[j]<<" - "<<notaBA1[j]<<" - "<<notaBA2[j]<<" - "<<notaBA3[j]<<" - "<<notaBA4[j]<<endl; //" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;;
            cout<<"\n"<<endl;
        }
        else if(LeerAsig == cod[2]){
            cout<<"-> "<<nombreAA[j]<<" - "<<notaAA1[j]<<" - "<<notaAA2[j]<<" - "<<notaAA3[j]<<" - "<<notaAA4[j]<<endl; //" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;;
            cout<<"\n"<<endl;
        }
        else if(LeerAsig == cod[3]){
            cout<<"-> "<<nombreDA[j]<<" - "<<notaDA1[j]<<" - "<<notaDA2[j]<<" - "<<notaDA3[j]<<" - "<<notaDA4[j]<<endl; //" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;;
            cout<<"\n"<<endl;
        }
        else if(LeerAsig == cod[4]){
            cout<<"-> "<<nombreParA[j]<<" - "<<notaParA1[j]<<" - "<<notaParA2[j]<<" - "<<notaParA3[j]<<" - "<<notaParA4[j]<<endl; //" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;;
            cout<<"\n"<<endl;
        }else{
            cout<<"NO HAY NOTAS"<<endl;
            }
        }   
};

void Menus::menu_profesor_3(){ //MENU PROFE OPC 3
    string Notas = "Notas.txt";
    ifstream archivo(Notas.c_str());
    while (getline(archivo,linea)){
        cout<<linea<<endl;
        lon = linea.length();
        for (ini=0;ini<lon;ini++){
            l=linea[ini];
            b=' ';
            if (l!=b){
                if (jo==0){
                    nomb=nomb+linea[ini];
                }
                if (jo==1){
                    n1=n1+linea[ini];
                    arr1 = std::stof(n1);
                }
                if (jo==2){
                    n2=n2+linea[ini];
                    arr2 = std::stof(n2);
                }
                if (jo==3){
                    n3=n3+linea[ini];
                    arr3 = std::stof(n3);
                }
                if (jo==4){
                    n4=n4+linea[ini];
                    arr4 = std::stof(n4);
                }
            }
            else
                jo++;
        }

        suma = ((arr1+arr2+arr3+arr4)/4);
        cout<<"Promedio: "<<fixed<<setprecision(1)<<suma<<endl;
        cout<<"\n";

        jo=0;
        nomb=" ";
        n1=" ";
        n2=" ";
        n3=" ";
        n4=" ";
        }   
};


void Menus::menu_estudiante(){      ///MENU ALUMNO
    cout<<"\n";
    cout<<"(INGRESE UNA DE LAS OPCIONES)"<<endl;
    cout<<"1) Tus Asignaturas"<<endl;
    cout<<"2) Revisar Notas"<<endl;
    cout<<"3) Pedir TxT Final"<<endl;
    cout<<"4) Volver"<<endl;
    cout<<"Ingrese Opcion: ";
    cin>>opc;

};

void Menus::menu_estudiante_1(){ //MENU ALUMNO OPC 1
    cout<<"Tus asignaturas son: "<<endl;
    // Ocupamos Clase Asignatura //
};

void Menus::menu_estudiante_2(){ //MENU ALUMNO OPC 2
    cout<<"Ingrese Codigo Asignatura: ";
    cin>>Codigo;
    cout<<"Ingrese Su Nombre: ";
    cin>>Alumno;

    for(int j=0;j<i;j++){
        if(Codigo == cod[0] and Alumno == nombrePA[j]){
            cout<<"\n";
            cout<<Alumno<<" Sus notas de "<<asig[0]<<" son: "<<endl;
            cout<<"-> "<<notaProA1[j]<<" - "<<notaProA2[j]<<" - "<<notaProA3[j]<<" - "<<notaProA3[j]<<" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;

            if(ProTotal[j] >= 4.0){
                cout<<"ESTADO DEL ALUMNO: Don "<<Alumno<<" usted esta APROBADO"<<endl;
                cout<<"\n";
            }
            else if(ProTotal[j] <= 3.9){
                cout<<"ESTADO DEL ALUMNO: Don "<<Alumno<<" usted esta REPROBADO"<<endl;
                cout<<"\n";
            }


        }else if(Codigo == cod[1] and Alumno == nombreBA[j]){
            cout<<"\n";
            cout<<Alumno<<" Sus notas de "<<asig[1]<<" son: "<<endl;
            cout<<"-> "<<notaBA1[j]<<" - "<<notaBA2[j]<<" - "<<notaBA3[j]<<" - "<<notaBA4[j]<<" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;

            if(ProTotal[j] >= 4.0){
                cout<<"ESTADO DEL ALUMNO: Don "<<Alumno<<" usted esta APROBADO"<<endl;
                cout<<"\n";
            }
            else if(ProTotal[j] <= 3.9){
                cout<<"ESTADO DEL ALUMNO: Don "<<Alumno<<" usted esta REPROBADO"<<endl;
                cout<<"\n";
            }

        }else if(Codigo == cod[2] and Alumno == nombreAA[j]){
            cout<<"\n";
            cout<<Alumno<<" Sus notas de "<<asig[2]<<" son: "<<endl;
            cout<<"-> "<<notaAA1[j]<<" - "<<notaAA2[j]<<" - "<<notaAA3[j]<<" - "<<notaAA4[j]<<" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;

            if(ProTotal[j] >= 4.0){
                cout<<"ESTADO DEL ALUMNO: Don "<<Alumno<<" usted esta APROBADO"<<endl;
                cout<<"\n";
            }
            else if(ProTotal[j] <= 3.9){
                cout<<"ESTADO DEL ALUMNO: Don "<<Alumno<<" usted esta REPROBADO"<<endl;
                cout<<"\n";
            }

        }else if(Codigo == cod[3] and Alumno == nombreDA[j]){
            cout<<"\n";
            cout<<Alumno<<" Sus notas de "<<asig[3]<<" son: "<<endl;
            cout<<"-> "<<notaDA1[j]<<" - "<<notaDA2[j]<<" - "<<notaDA3[j]<<" - "<<notaDA4[j]<<" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;


            if(ProTotal[j] >= 4.0){
                cout<<"ESTADO DEL ALUMNO: Don "<<Alumno<<" usted esta APROBADO"<<endl;
                cout<<"\n";
            }
            else if(ProTotal[j] <= 3.9){
                cout<<"ESTADO DEL ALUMNO: Don "<<Alumno<<" usted esta REPROBADO"<<endl;
                cout<<"\n";
            }

        }else if(Codigo == cod[4] and Alumno == nombreParA[j]){
            cout<<"\n";
            cout<<Alumno<<" Sus notas de "<<asig[4]<<" son: "<<endl;
            cout<<notaParA1[j]<<" - "<<notaParA2[j]<<" - "<<notaParA3[j]<<" - "<<notaParA4[j]<<" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;

            if(ProTotal[j] >= 4.0){
                cout<<"ESTADO DEL ALUMNO: Don "<<Alumno<<" usted esta APROBADO"<<endl;
                cout<<"\n";
            }
            else if(ProTotal[j] <= 3.9){
                cout<<"ESTADO DEL ALUMNO: Don "<<Alumno<<" usted esta REPROBADO"<<endl;
                cout<<"\n";
            }

        }
        /*else{
            cout<<"\n";
            cout<<"NO HAY NOTAS INGRESADAS"<<endl;
            cout<<"\n"; 
        } */
    }
};

void Menus::menu_estudiante_3(){ //MENU ALUMNO OPC 3
    string NombreAlu;
    ofstream archivoN;
    archivoN.open("NOTAS_ALUMNO.txt");
    cout<<"Ingrese Su Nombre: ";
    cin>>NombreAlu;
    cout<<"\n";
    cout<<"Imprimiendo..."<<endl;
    cout<<"           ..."<<endl;
    cout<<"Listo sus notas se encuentran en :  NOTAS_ALUMNO.txt "<<endl;
    cout<<"\n";




    for(int j=0;j<i;j++){
        if(NombreAlu == nombrePA[j]){
            archivoN<<nombrePA[j]<<endl;
            archivoN<<"\n";
            archivoN<<"SUS NOTAS DE PROGRAMACION SON: "<<endl;
            archivoN<<notaProA1[j]<<" - "<<notaProA2[j]<<" - "<<notaProA3[j]<<" - "<<notaProA4[j]<<" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;
            archivoN<<"\n";
        }else if(NombreAlu == nombreBA[j]){
            archivoN<<"SUS NOTAS DE BASES DE DATOS SON: "<<endl;
            archivoN<<notaBA1[j]<<" - "<<notaBA2[j]<<" - "<<notaBA3[j]<<" - "<<notaBA4[j]<<" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;
            archivoN<<"\n";
        }else if(NombreAlu == nombreAA[j]){
            archivoN<<"SUS NOTAS DE ALGORTIMO Y ESTRUCTURA DE DATOS SON: "<<endl;
            archivoN<<notaAA1[j]<<" - "<<notaAA2[j]<<" - "<<notaAA3[j]<<" - "<<notaAA4[j]<<" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;
            archivoN<<"\n";
        }else if(NombreAlu == nombreDA[j]){
            archivoN<<"SUS NOTAS DE DESARROLLO WEB Y MOVIL SON: "<<endl;
            archivoN<<notaDA1[j]<<" - "<<notaDA2[j]<<" - "<<notaDA3[j]<<" - "<<notaDA4[j]<<" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;
            archivoN<<"\n";
        }else if(NombreAlu == nombreParA[j]){  
            archivoN<<"SUS NOTAS DE PARADICMAS DE PROGRAMACION SON: "<<endl;
            archivoN<<notaParA1[j]<<" - "<<notaParA2[j]<<" - "<<notaParA3[j]<<" - "<<notaParA4[j]<<" Promedio: "<<fixed<<setprecision(1)<<ProTotal[j]<<endl;
            archivoN<<"\n";
        }
        }
    archivoN.close();
};


int main(){ // MAIN 
    Persona p;
    Menus m;
    Asignatura a;
    int opcion=0;
    while(opcion !=3){
        cout<<"\n"<<endl;
        cout<<"INGRESE SU PERFIL"<<endl;
        cout<<"1) Profesor"<<endl;
        cout<<"2) Estudiante"<<endl;
        cout<<"3) Salir"<<endl;
        cout<<"Ingrese Opcion: ";
        cin>>opcion;
        cout<<"\n";
        

      
        switch(opcion){
            case 1:{
                while(m.opc != 5){
                    m.menu_profesor();
                switch(m.opc){
                    case 1:
                        m.menu_profesor_1();
                        break;
                    case 2:
                        m.menu_profesor_2();
                        break;

                    case 3:
                        cout<<"\n";
                        m.menu_profesor_3();
                        break;
                    }
                }
              
                break;
              }
            case 2:{
                while(m.opc != 4){
                    m.menu_estudiante();
                switch(m.opc){
                    case 1:
                        a.Mostrar_Asig();
                        break;
                    case 2:
                        m.menu_estudiante_2();
                        break;
                    case 3: 
                        m.menu_estudiante_3();
                }
                }
                break;
              }
        }   
        }
    }
