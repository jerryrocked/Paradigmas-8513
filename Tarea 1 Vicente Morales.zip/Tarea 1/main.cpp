#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>

using namespace std;

//Creacion de la clase profesor y su constructor
class profesor{
public:
struct{
  string nombre, rut;
}prof; //NOMBRE DEL STRUC
profesor(){ };
~profesor(){ };
void datosp();
void mostrard();
};

// Ingreso de datos de profesor
void profesor::datosp(){
  cout<<"Ingrese su nombre: "; cin>> prof.nombre;
  cout<<"Ingrese su Rut: "; cin>>prof.rut;
  cout<<endl;
};

//Muestra Datos de Profesor
void profesor::mostrard(){
  cout<<"Nombre: "<<prof.nombre<<endl;
  cout<<"Rut: "<<prof.rut<<endl;
};

//Se crea la asignatura
class asignatura: public profesor{
public:
asignatura(){};
~asignatura(){};
void ingresar_notas();
};

void asignatura::ingresar_notas(){
  int alumnos;
  float promedio;
  string nom_asignatura, nomb_alumno, nota1, nota2, nota3, nota4, apellido_alumno,txt= ".txt";
  string arreglo[25];
  cout<<"Ingrese la asignatura: "; cin>>nom_asignatura;
  
  //Se crea el archivo
  string nombreArchivo = nom_asignatura+txt;
  //Se escribe en el archivo
  ofstream archivo;
  //Se abre el archivo .txt
  archivo.open(nombreArchivo.c_str(), fstream::out);
  //Ciclo for para ingresar datos del alumno
    cout<<"Ingrese el nombre del alumno: "; cin>>nomb_alumno;
    cout<<"Ingrese el apellido del alumno: "; cin>>apellido_alumno;
    cout<<"Ingrese las notas del alumno "<<endl<<endl;
    cout<<"Ingrese nota 1: "; cin>>nota1;
    cout<<endl<<"Ingrese nota 2: "; cin>>nota2; 
    cout<<endl<<"Ingrese nota 3: "; cin>>nota3; 
    cout<<endl<<"Ingrese nota 4: "; cin>>nota4;
    float n1 = stof(nota1);
    float n2 = stof(nota2);
    float n3 = stof(nota3);
    float n4 = stof(nota4);
    /*promedio = (nota1+nota2+nota3+nota4)/4;
    cout<<"El alumno "<<n_alumno<<" tiene un promedio del ramo "<<asignatura<<": "<<promedio;
    cout<<endl;*/
    //se ingresan los promedios de los estudiantes
    //string p(to_string(promedio));
    
    //ingresar las notas a un txt
  arreglo[0] = nomb_alumno+" ";
  arreglo[1] = apellido_alumno+" ";
  arreglo[2] = n1;
  arreglo[3] = n2;
  arreglo[4] = n3;
  arreglo[5] = n4;

  
    cout<<"arreglo:";
  //Se abre el archivo txt
  
  for (int i=0;i<6;i++){
  //Se va agregando las notas a un txt 
    cout<<arreglo[i];
    archivo<<arreglo[i]+" ";
  }
  archivo<<"\n";
  //Se cierra el archivo
  cout<<endl;
  //Se cierra el txt 
  archivo.close();
}

class alumno{
public:
struct{
  string nombre_alumno, rut_alumno;
}alum;
alumno(){ };
~alumno(){ };
void datosa();
void mostrarda();
};

//SE INGRESAN LOS DATOS DEL ALUMNO
void alumno:: datosa(){
  cout<<"Ingrese el nombre del alumno: "; cin>> alum.nombre_alumno;
  cout<<"Ingrese el Rut del alumno: "; cin>>alum.rut_alumno;
  
  cout<<endl;
}

//Muestra datos de los alumnos
void alumno:: mostrarda(){
  cout<<"Nombre: "<<alum.nombre_alumno<<endl;
  cout<<"Rut: "<<alum.rut_alumno<<endl;
}

// Creacion del menu
void Menu()
{
  int opcion;
  cout<<"¿Usted es alumno o profesor?"<<endl;
  cout<<"1) Profesor\n";
  cout<<"2) Alumno\n";
  cout<<"3) Salir\n";
  cout<<"Ingrese la opcion: "; cin>>opcion;

  while (opcion!=1&&opcion!=2&&opcion!=3)
  {
    cout<<"Ingrese una opcion valida"<<endl;
    cin>>opcion;
  }
  
  {
    if(opcion==1){
      profesor profesor_case_1;
      asignatura asignatura_profesor_case_1;
      
      profesor_case_1.datosp();
      profesor_case_1.mostrard();
      asignatura_profesor_case_1.ingresar_notas();
      }
    
    else if (opcion==2){
      alumno alumno_case_2;
      alumno_case_2.datosa();
      alumno_case_2.mostrarda();
      }

    else if(opcion==3){
      cout<<"Saliendo de Intranet Unab"<<endl;
    }
  }
}

int main() {
  char res;
  res='s';
  while (res=='s'){
    Menu();
    cout<<"¿Desea hacer alguna otra operacion? (s=si) (cualquier otra tecla=no): "<<endl;
    cin>>res;
  }
}