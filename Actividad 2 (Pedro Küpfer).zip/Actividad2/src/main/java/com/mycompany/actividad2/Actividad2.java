// Nombre: Pedro Küpfer

/*

El código fue realizado en ambiente gráfico
para poner en práctica las interfaces, 
espero que no hayan problemas con eso.

*/

package com.mycompany.actividad2;

public class Actividad2 {

    public static void main(String[] args) {
        Ventana v1 = new Ventana();
        v1.setVisible(true);
    }
}
