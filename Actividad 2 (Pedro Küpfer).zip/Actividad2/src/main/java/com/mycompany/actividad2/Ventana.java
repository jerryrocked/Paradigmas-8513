package com.mycompany.actividad2;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Ventana extends JFrame{
    private JPanel panel;
    private JLabel texto1, texto2, texto3, texto4, texto5, texto6;
    private JButton opcion1, opcion2, opcion3, opcion4, opcion5;
    private JTextField cajaMonto;

    private float porcentaje = 0;
    private double monto, total, balanceFinal;
    private String periodo;
    private int n_periodo;
  
    Ventana(){
        this.setSize(500, 350);
        this.setTitle("Cuenta Banco XYZ");
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        insertarPanel();
        insertarTexto();
        insertarBotones();
        insertarCampo();
        opcionCalcular();
    }
    
    private void insertarPanel(){
        panel = new JPanel();
        panel.setBackground(Color.darkGray);
        panel.setLayout(null);
        this.getContentPane().add(panel);
    }
    
    private void insertarTexto(){
        texto1 = new JLabel();
        texto1.setText("Seleccione un tipo de cuenta:");
        texto1.setBounds(10, 10, 480, 30);
        texto1.setForeground(Color.white);
        texto1.setFont(new Font("Arial", Font.PLAIN,16));
        panel.add(texto1);

        texto3 = new JLabel();
        texto3.setText("Ingrese balance inicial:");
        texto3.setBounds(10, 170, 190, 30);
        texto3.setForeground(Color.white);
        texto3.setFont(new Font("Arial", Font.PLAIN,16));
        panel.add(texto3);

        texto5 = new JLabel();
        texto5.setBounds(200, 240, 300, 30);
        texto5.setForeground(Color.white);
        texto5.setFont(new Font("Arial", Font.PLAIN,14));
        panel.add(texto5);

        texto6 = new JLabel();
        texto6.setBounds(200, 270, 300, 30);
        texto6.setForeground(Color.green);
        texto6.setFont(new Font("Arial", Font.PLAIN,14));
        panel.add(texto6);
    }
    
    private void insertarBotones(){
        opcion1 = new JButton();
        opcion1.setText("Cuenta Ahorro");
        opcion1.setBounds(10, 40, 240, 40);
        opcion1.setEnabled(true);
        opcion1.setForeground(Color.black);
        opcion1.setFont(new Font("Arial", Font.PLAIN,12));
        panel.add(opcion1);

        opcion2 = new JButton();
        opcion2.setText("Cuenta Corriente");
        opcion2.setBounds(10, 80, 240, 40);
        opcion2.setEnabled(true);
        opcion2.setForeground(Color.black);
        opcion2.setFont(new Font("Arial", Font.PLAIN,12));
        panel.add(opcion2);

        opcion3 = new JButton();
        opcion3.setText("Cuenta de Plazo Fijo (3 meses)");
        opcion3.setBounds(250, 40, 240, 40);
        opcion3.setEnabled(true);
        opcion3.setForeground(Color.black);
        opcion3.setFont(new Font("Arial", Font.PLAIN,12));
        panel.add(opcion3);

        opcion4 = new JButton();
        opcion4.setText("Cuenta de Plazo Fijo (6 meses)");
        opcion4.setBounds(250, 80, 240, 40);
        opcion4.setEnabled(true);
        opcion4.setForeground(Color.black);
        opcion4.setFont(new Font("Arial", Font.PLAIN,12));
        panel.add(opcion4);

        texto2 = new JLabel();
        texto2.setBounds(10, 130, 480, 30);
        texto2.setFont(new Font("Arial", Font.PLAIN,14));
        panel.add(texto2);

        ActionListener mostrarCuenta = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                String textoOpcion = e.getActionCommand();
                texto2.setForeground(Color.green);
                texto2.setText("Tipo de cuenta seleccionada: "+textoOpcion);
                if (textoOpcion == "Cuenta Ahorro"){
                    porcentaje = 0.01f;
                    periodo = "Anual";
                    n_periodo = 1;
                }else if (textoOpcion == "Cuenta Corriente"){
                    porcentaje = 0.005f;
                    periodo = "Anual";
                    n_periodo = 1;
                }else if (textoOpcion == "Cuenta de Plazo Fijo (3 meses)"){
                    porcentaje = 0.012f;
                    periodo = "Mensual";
                    n_periodo = 3;
                }else if (textoOpcion == "Cuenta de Plazo Fijo (6 meses)"){
                    porcentaje = 0.012f;
                    periodo = "Mensual";
                    n_periodo = 6;
                }
            }
        };
        opcion1.addActionListener(mostrarCuenta);
        opcion2.addActionListener(mostrarCuenta);
        opcion3.addActionListener(mostrarCuenta);
        opcion4.addActionListener(mostrarCuenta);
    }
    
    private void insertarCampo(){
        cajaMonto = new JTextField();
        cajaMonto.setBounds(200, 170, 200, 30);
        panel.add(cajaMonto);
    }
    
    private void opcionCalcular(){
        opcion5 = new JButton();
        opcion5.setText("Calcular ");
        opcion5.setBounds(10, 260, 150, 40);
        opcion5.setEnabled(true);
        opcion5.setForeground(Color.black);
        opcion5.setFont(new Font("Arial", Font.PLAIN,20));
        opcion5.setBackground(Color.green);
        panel.add(opcion5);

        texto4 = new JLabel();
        texto4.setText("");
        texto4.setBounds(10, 240, 200, 30);
        texto4.setForeground(Color.red);
        texto4.setFont(new Font("Arial", Font.PLAIN,14));
        panel.add(texto4);

        ActionListener mostrarResultado = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                texto4.setText("");
                try{
                    Double.parseDouble(cajaMonto.getText());
                }catch(NumberFormatException test){
                    texto4.setText("Ingrese un monto válido.");
                }
                if (porcentaje == 0){
                    texto2.setForeground(Color.red);
                    texto2.setText("Debe seleccionar un tipo de cuenta.");
                }else if (texto4.getText() == ""){
                    insertarResultados();
                }
            }
        };
        opcion5.addActionListener(mostrarResultado);
    }
    
    private void insertarResultados(){
        monto = Double.parseDouble(cajaMonto.getText());
        if (monto <= 0){
            texto4.setText("Ingrese un monto válido.");
        }else{
            total = 0;
            for (int i=0; i<n_periodo; i++){
                total += (monto+total)*porcentaje;
            }
            total = Math.round(total*100.0)/100.0;
            balanceFinal = monto+total;

            String resultado1;
            String resultado2;
            if (periodo == "Anual"){
                resultado1 = "Monto acumulado en 1 año: $"+total;
                resultado2 = "Balance final (en 1 año): $"+balanceFinal;
            }else{
                resultado1 = "Monto acumulado en "+n_periodo+" meses: $"+total;
                resultado2 = "Balance final (en "+n_periodo+" meses): $"+balanceFinal;
            };

            texto5.setText(resultado1);
            texto6.setText(resultado2);
        }
    }
}

