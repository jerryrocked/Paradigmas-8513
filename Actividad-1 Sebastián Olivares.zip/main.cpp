#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;

class LibroNotas
{
public:
 vector<string> nombres;
  vector<float> notasFin;
  void notaAlta()
  {
    float maxElementIndex = max_element(notasFin.begin(), notasFin.end()) - notasFin.begin();
    float maxElement = *max_element(notasFin.begin(), notasFin.end());
    cout << "La mejor nota fue un " << maxElement << " obtenida por el alumno " << nombres[maxElementIndex] << "." << endl;
  }
};

class Alumno
{
private:
  string nomb;
  float n1, n2, n3;
  float notaFin;

public:
  Alumno(string n, float x, float y, float z)
  {
    this->nomb = n;
    n1 = x;
    n2 = y;
    n3 = z;
  };
  void calcNota(LibroNotas &L)
  {
    float nd = (n1 + n2 + n3) / 3;
    notaFin = nd;
    L.notasFin.push_back(nd);
    L.nombres.push_back(nomb);
  }
void rango()
  {
    if (notaFin)
    {
      if (notaFin >= 6.0)
      {
        cout << "El alumno " << nomb << " está aprobado de forma excelente." << endl;
      }
      if (5.0 <= notaFin && notaFin <= 5.9)
      {
        cout << "El alumno" << nomb << " está aprobado de forma buena." << endl;
      }
      if (4.5 <= notaFin && notaFin <= 4.9)
      {
        cout << "El alumno " << nomb << " está aprobado de forma regular." << endl;
      }
      if (notaFin < 4.5)
      {
        cout << "El alumno " << nomb << " está aprobado de forma deficiente." << endl;
      }
    }
    else
    {
      cout << "El alumno " << nomb << " aun no cuenta con nota definitva." << endl;
    }
  }
};


int main() {
  LibroNotas L;
  ifstream archivo;
  archivo.open("Notas_alumnado.txt");
  string linea;
  while (getline(archivo, linea))
  {
    string nomb = linea.substr(0, linea.find(" "));
    linea.erase(0, linea.find(" ") + 1);
    float n1 = stof(linea.substr(0, linea.find(" ")));
    linea.erase(0, linea.find(" ") + 1);
    float n2 = stof(linea.substr(0, linea.find(" ")));
    linea.erase(0, linea.find(" ") + 1);
    float n3 = stof(linea.substr(0, linea.find(" ")));
    Alumno a(nomb, n1, n2, n3);
    a.calcNota(L);
    a.rango();
  }
  L.notaAlta();
  return 0;
  
}