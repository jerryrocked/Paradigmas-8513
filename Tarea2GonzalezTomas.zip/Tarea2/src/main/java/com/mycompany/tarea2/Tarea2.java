package com.mycompany.tarea2;

/**
 *
 * @author tomas
 */
public class Tarea2 {
    public static void main(String[] args) {
        // Mostrar primera ventana
        Ventana v = new Ventana();
        v.setVisible(true);
    }
}
