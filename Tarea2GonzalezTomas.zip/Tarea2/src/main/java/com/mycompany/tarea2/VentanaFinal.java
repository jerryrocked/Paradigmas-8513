/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tarea2;

/**
 *
 * @author tomas
 */
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class VentanaFinal extends JFrame{
    private JPanel panel;
    private JLabel texto1, texto2;
    private JButton boton1;
    
    // Muestra el nombre del vendedor y su comisión total
    VentanaFinal(String nombre, float comision){
        this.setSize(350, 155);
        this.setTitle("Resultado");
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        panel = new JPanel();
        panel.setBackground(Color.cyan);
        panel.setLayout(null);
        this.getContentPane().add(panel);
        
        texto1 = new JLabel();
        texto1.setText("Vendedor destacado: "+nombre);
        texto1.setBounds(10, 10, 330, 30);
        texto1.setForeground(Color.black);
        texto1.setFont(new Font("Trebuchet MS", Font.BOLD,16));
        texto1.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(texto1);
        
        texto2 = new JLabel();
        texto2.setText("COMISIÓN GANADA: $"+comision);
        texto2.setBounds(10, 40, 330, 30);
        texto2.setForeground(Color.red);
        texto2.setFont(new Font("Trebuchet MS", Font.BOLD,16));
        texto2.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(texto2);
        
        boton1 = new JButton();
        boton1.setText("Finalizar");
        boton1.setBounds(125, 80, 100, 30);
        boton1.setEnabled(true);
        boton1.setForeground(Color.black);
        boton1.setFont(new Font("Trebuchet MS", Font.PLAIN,16));
        panel.add(boton1);
        
        // Botón que cierra el programa
        ActionListener finalizar = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        };
        boton1.addActionListener(finalizar);
    }
}

