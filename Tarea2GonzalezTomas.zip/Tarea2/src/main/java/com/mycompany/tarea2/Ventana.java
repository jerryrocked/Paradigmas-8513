/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tarea2;

/**
 *
 * @author tomas
 */
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class Ventana extends JFrame{
    // VARIABLES DEL DISEÑO
    private JPanel panel;
    private JLabel texto1, texto2, texto3, texto4, texto5, texto6, texto7, texto8, texto9, texto10, texto11, texto12, texto13, texto14, texto15, texto16, texto17, texto18;
    private JLabel error1, error2;
    private JTextField campo1, campo2, campo3, campo4;
    private JButton boton1, boton2;
    private ImageIcon imagen1, imagen2, imagen3;
    
    // VARIABLES GENERALES
    private int[] valor = {34500, 8800, 58200};
    private float[] com = {0.06f, 0.04f, 0.09f};
    private String[] empleado = new String[100];
    private int[][] total_empleado = new int[100][3];
    private float[][] com_empleado = new float[100][3];
    
    // Diseño de la ventana (JFrame)
    Ventana(){
        this.setSize(520, 575);
        this.setTitle("Ventas");
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        // Inicializa todas las funciones del diseño
        crearPanel();
        etiqueta();
        campoTexto();
        botones();
        insertarFotos();
    }
    
    // PANEL
    private void crearPanel(){
        panel = new JPanel();
        panel.setBackground(Color.cyan);
        panel.setLayout(null);
        this.getContentPane().add(panel);
    }
    
    // TODOS LOS TEXTOS
    private void etiqueta(){
        texto1 = new JLabel();
        texto1.setText("Nombre del empleado: ");
        texto1.setBounds(10, 10, 240, 30);
        texto1.setForeground(Color.black);
        texto1.setFont(new Font("Trebuchet MS", Font.PLAIN,16));
        panel.add(texto1);
        
        texto2 = new JLabel();
        texto2.setText("Cantidad de ventas: ");
        texto2.setBounds(25, 300, 170, 30);
        texto2.setForeground(Color.black);
        texto2.setFont(new Font("Trebuchet MS", Font.PLAIN,16));
        panel.add(texto2);
        
        texto3 = new JLabel();
        texto3.setText("CALL OF DUTY");
        texto3.setBounds(180, 300, 120, 30);
        texto3.setForeground(Color.black);
        texto3.setFont(new Font("Trebuchet MS", Font.BOLD,16));
        panel.add(texto3);
        
        texto4 = new JLabel();
        texto4.setText("MINECRAFT");
        texto4.setBounds(180, 330, 120, 30);
        texto4.setForeground(Color.black);
        texto4.setFont(new Font("Trebuchet MS", Font.BOLD,16));
        panel.add(texto4);
        
        texto5 = new JLabel();
        texto5.setText("FORTNITE");
        texto5.setBounds(180, 360, 120, 30);
        texto5.setForeground(Color.black);
        texto5.setFont(new Font("Trebuchet MS", Font.BOLD,16));
        panel.add(texto5);
        
        texto6 = new JLabel();
        texto6.setText("Comisión= 6%");
        texto6.setBounds(370, 300, 120, 30);
        texto6.setForeground(Color.black);
        texto6.setFont(new Font("Trebuchet MS", Font.PLAIN,12));
        panel.add(texto6);
        
        texto7 = new JLabel();
        texto7.setText("Comisión= 4%");
        texto7.setBounds(370, 330, 120, 30);
        texto7.setForeground(Color.black);
        texto7.setFont(new Font("Trebuchet MS", Font.PLAIN,12));
        panel.add(texto7);
        
        texto8 = new JLabel();
        texto8.setText("Comisión= 9%");
        texto8.setBounds(370, 360, 120, 30);
        texto8.setForeground(Color.black);
        texto8.setFont(new Font("Trebuchet MS", Font.PLAIN,12));
        panel.add(texto8);
        
        texto9 = new JLabel();
        texto9.setBounds(10, 35, 510, 30);
        texto9.setForeground(Color.blue);
        texto9.setFont(new Font("Trebuchet MS", Font.BOLD,16));
        panel.add(texto9);
        
        texto10 = new JLabel();
        texto10.setText("valor de venta: $34.500");
        texto10.setBounds(10, 260, 155, 15);
        texto10.setForeground(Color.black);
        texto10.setFont(new Font("Trebuchet MS", Font.PLAIN,10));
        panel.add(texto10);
        
        texto11 = new JLabel();
        texto11.setBounds(10, 270, 155, 15);
        texto11.setForeground(Color.black);
        texto11.setFont(new Font("Trebuchet MS", Font.PLAIN,10));
        panel.add(texto11);
        
        texto12 = new JLabel();
        texto12.setBounds(10, 280, 155, 15);
        texto12.setForeground(Color.black);
        texto12.setFont(new Font("Trebuchet MS", Font.BOLD,10));
        panel.add(texto12);
        
        texto13 = new JLabel();
        texto13.setText("valor de venta: $8.800");
        texto13.setBounds(175, 260, 155, 15);
        texto13.setForeground(Color.black);
        texto13.setFont(new Font("Trebuchet MS", Font.PLAIN,10));
        panel.add(texto13);
        
        texto14 = new JLabel();
        texto14.setBounds(175, 270, 155, 15);
        texto14.setForeground(Color.black);
        texto14.setFont(new Font("Trebuchet MS", Font.PLAIN,10));
        panel.add(texto14);
        
        texto15 = new JLabel();
        texto15.setBounds(175, 280, 155, 15);
        texto15.setForeground(Color.black);
        texto15.setFont(new Font("Trebuchet MS", Font.BOLD,10));
        panel.add(texto15);
        
        texto16 = new JLabel();
        texto16.setText("valor de venta: $58.200");
        texto16.setBounds(340, 260, 155, 15);
        texto16.setForeground(Color.black);
        texto16.setFont(new Font("Trebuchet MS", Font.PLAIN,10));
        panel.add(texto16);
        
        texto17 = new JLabel();
        texto17.setBounds(340, 270, 155, 15);
        texto17.setForeground(Color.black);
        texto17.setFont(new Font("Trebuchet MS", Font.PLAIN,10));
        panel.add(texto17);
        
        texto18 = new JLabel();

        texto18.setBounds(340, 280, 155, 15);
        texto18.setForeground(Color.black);
        texto18.setFont(new Font("Trebuchet MS", Font.BOLD,10));
        panel.add(texto18);
        
        error1 = new JLabel();
        error1.setBounds(10, 190, 280, 30);
        error1.setForeground(Color.red);
        error1.setFont(new Font("Trebuchet MS", Font.PLAIN,12));
        panel.add(error1);
        
        error2 = new JLabel();
        error2.setBounds(10, 560, 280, 40);
        error2.setForeground(Color.red);
        error2.setFont(new Font("Trebuchet MS", Font.PLAIN,12));
        panel.add(error2);
    }
    
    // TODOS LOS CAMPOS
    private void campoTexto(){
        campo1 = new JTextField();
        campo1.setBounds(180, 10, 320, 30);
        panel.add(campo1);
        
        campo2 = new JTextField();
        campo2.setBounds(310, 300, 50, 30);
        campo2.setText("0");
        panel.add(campo2);
        
        campo3 = new JTextField();
        campo3.setBounds(310, 330, 50, 30);
        campo3.setText("0");
        panel.add(campo3);
        
        campo4 = new JTextField();
        campo4.setBounds(310, 360, 50, 30);
        campo4.setText("0");
        panel.add(campo4);
    }
    
    // TODOS LOS BOTONES
     private void botones(){
        boton1 = new JButton();
        boton1.setText("Añadir al registro");
        boton1.setBounds(15, 335, 155, 50);
        boton1.setEnabled(true);
        boton1.setForeground(Color.black);
        boton1.setFont(new Font("Trebuchet MS", Font.PLAIN,16));
        panel.add(boton1);
        
        boton2 = new JButton();
        boton2.setText("Finalizar registro");
        boton2.setBounds(145, 450, 210, 50);
        boton2.setEnabled(true);
        boton2.setForeground(Color.black);
        boton2.setFont(new Font("Trebuchet MS", Font.BOLD,16));
        panel.add(boton2);
        
        // EVENTOS DE LOS BOTONES
        // Inicializa el registro del empleado
        ActionListener registrar = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarVendedor();
            }
        };
        boton1.addActionListener(registrar);
        
        // Finaliza los registros
        ActionListener finalizar = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                mejorVendedor();
            }
        };
        boton2.addActionListener(finalizar);
     }
     
     // TODAS LAS IMÁGENES
     private void insertarFotos(){
         imagen1 = new ImageIcon("imagenes\\codmw3.jpeg");
         imagen1 = new ImageIcon(imagen1.getImage().getScaledInstance(155, 200, Image.SCALE_DEFAULT));
         JLabel i1 = new JLabel("<html>Imagen1<html>", imagen1, SwingConstants.LEFT);
         i1.setBounds(10, 60, 175, 200);
         panel.add(i1);
         
         imagen2 = new ImageIcon("imagenes\\minecraft.jpeg");
         imagen2 = new ImageIcon(imagen2.getImage().getScaledInstance(155, 200, Image.SCALE_DEFAULT));
         JLabel i2 = new JLabel("<html>Imagen2<html>", imagen2, SwingConstants.LEFT);
         i2.setBounds(175, 60, 175, 200);
         panel.add(i2);
         
         imagen3 = new ImageIcon("imagenes\\fortnite.png");
         imagen3 = new ImageIcon(imagen3.getImage().getScaledInstance(155, 200, Image.SCALE_DEFAULT));
         JLabel i3 = new JLabel("<html>Imagen3<html>", imagen3, SwingConstants.LEFT);
         i3.setBounds(340, 60, 175, 200);
         panel.add(i3);
     }
     
     // Registra los datos del empleado que aparece en los campos dentro de unos arreglos
     private void guardarVendedor(){
         String nombre = campo1.getText();
         int cantidad[] = new int[3];
         
         // Vaciar los errores
         error1.setText("");
         error2.setText("");
         
         // Comprobar si el nombre del empleado no esté vacío
         if ("".equals(nombre)){
            error1.setText("Error 1: Ingrese nombre del empleado.");
            quitarInterfaz();
            return;
         }
         
         // Comprobar si el nombre del empleado no tiene caracteres especiales
         Pattern p = Pattern.compile("[^a-zá-úÁ-Úä-ü ]", Pattern.CASE_INSENSITIVE);
         Matcher m = p.matcher(nombre);
         boolean b = m.find();
         if (b){
            error1.setText("Error 2: El nombre del empleado es inválido.");
            quitarInterfaz();
            return;
         }
         
         // Comprobar si las cantidades son solo números positivos
         String c[] = {campo2.getText(), campo3.getText(), campo4.getText()};
         for (int i=0; i<3; i++){
             try{
                 @SuppressWarnings("unused")
                 int x = Integer.parseInt(c[i]);
                 cantidad[i] = x;
                 if (x < 0){
                    error1.setText("Error 3: Una de las cantidades es inválida.");
                    quitarInterfaz();
                    return; 
                 }
             }catch (NumberFormatException e){
                 error1.setText("Error 3: Una de las cantidades es inválida.");
                 quitarInterfaz();
                 return;
             }
         }
         
         // Buscar si existe registro del empleado o asignarle uno nuevo
         int pos = asignarVendedor(nombre);
         // Registrar sus datos en los arreglos
         empleado[pos] = nombre;
         for (int i=0; i<3; i++){
             total_empleado[pos][i] += valor[i]*cantidad[i];
             com_empleado[pos][i] += valor[i]*com[i]*cantidad[i];
         }
         
         // Mostrar los datos en la interfaz
         mostrarData(pos);
     }

     // Busca un espacio para el empleado en el arreglo
     private int asignarVendedor(String nombre){
         int i = 0;
         while(i<empleado.length && empleado[i] != null && !empleado[i].equals(nombre)){
             i++;
         }
         return i;
     }
     
     // Muestra los datos del empleado en los textos
     private void mostrarData(int pos){
         String nombre = empleado[pos];
         JLabel[] texto_total = {texto11, texto14, texto17};
         JLabel[] texto_com = {texto12, texto15, texto18};
         
         // Título de las ventas del empleado
         texto9.setText("VENTAS DE "+nombre.toUpperCase());
         // Datos del empleado
         for (int i=0; i<3; i++){
             int total = total_empleado[pos][i];
             float com = com_empleado[pos][i];
             texto_total[i].setText("Cantidad vendida: $"+total);
             texto_com[i].setText("Comisión ganada: $"+com);
         }
     }
     
     // Deja en blanco los datos del empleado
     private void quitarInterfaz(){
         texto9.setText("");
         texto11.setText("");
         texto12.setText("");
         texto14.setText("");
         texto15.setText("");
         texto17.setText("");
         texto18.setText("");
     }
     
     // Busca el empleado que generó más ventas
     private void mejorVendedor(){
         int i = 0;
         int pos_ganador = 0;
         int total_ganador = 0;
         
         // Vacía los errores
         error1.setText("");
         error2.setText("");
         // Comprueba si hay empleadoes registrados
         if (empleado[0] == null){
             error2.setText("Error 4: No hay registro de empleadoes.");
             return;
         }
         
         // Busca al empleado con más ventas
         while(i<empleado.length && empleado[i] != null){
             int total = totalVentas(i);
             if (total > total_ganador){
                 pos_ganador = i;
                 total_ganador = total;
             }
             i++;
         }
         
         // Comprueba si existen empleadoes que hayan generado ventas
         if (total_ganador == 0){
             error2.setText("Error 5: No hay registro de ventas.");
             return;
         }
         
         String nombre_ganador = empleado[pos_ganador];
         float com_ganador = totalComision(pos_ganador);
         
         // Muestra el empleado con más ventas
         mejorVendedor(nombre_ganador, com_ganador);
     }
     
     // Suma las ventas de un empleado
     private int totalVentas(int pos){
         int total = 0;
         for (int i=0; i<3; i++){
             total += total_empleado[pos][i];
         }
         return total;
     }
     
     // Suma las comisiones de un empleado
     private int totalComision(int pos){
         int com = 0;
         for (int i=0; i<3; i++){
             com += com_empleado[pos][i];
         }
         return com;
     }
     
     // Inicia una ventana que muestra el empleado que generó más ventas
     private void mejorVendedor(String nombre, float com){
         VentanaFinal v = new VentanaFinal(nombre, com);
         v.setVisible(true);
     }
}

