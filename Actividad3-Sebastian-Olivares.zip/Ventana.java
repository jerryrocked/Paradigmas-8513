public class Ventana {
   
    float dinero;
    String rut;
    int tiempo;
   
    public Ventana(){
   
    }
    public Ventana(float p, String r, int t){
        this.dinero=p;
        this.rut=r;
        this.tiempo=t;
    }
    public void ctaAhorro(){
        float cont;
        for (int i=0; i<tiempo; i++){
            cont=dinero/100;
            dinero=dinero+cont;
        }
        System.out.println("Con esta cuenta generará "+dinero+" en "+tiempo+" años.");
    }
    public void ctaCorriente(){
        float cont;
        for (int i=0; i<tiempo; i++){
            cont=dinero/200;
            dinero=dinero+cont;
        }
        System.out.println("Con esta cuenta generará "+dinero+" en "+tiempo+" años.");
    }
    public void plazoFijo(){
        if(tiempo==3){
            float cont;
            for (int i=0; i<tiempo; i++){
                cont=(dinero/100);
                cont=(float) (cont*1.2);
                dinero=dinero+cont;
        }
            System.out.println("Con esta cuenta generará "+dinero+" en "+tiempo+" meses.");
        }
        else if(tiempo==6){
            for (int i=0; i<tiempo; i++){
                dinero=(float) (dinero*1.2);
        }
            System.out.println("Con esta cuenta generará "+dinero+" en "+tiempo+" meses.");
        }
        else{
            System.out.println("El plazo de tiempo ingresado es invalido.");
        }
    }
}