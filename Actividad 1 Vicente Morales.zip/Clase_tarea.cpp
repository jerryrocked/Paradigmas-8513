#include <iostream>
#include <string.h>
#include <fstream>
#include <stdlib.h>
#include <cstdlib>
using namespace std;

int main(){
	string archivo1="Notas.txt";
	ifstream archivo(archivo1.c_str());
	string linea,nomb,n1,n2,n3,n4;
	int nota1[4], nota2[4], nota3[4], nota4[4];
	int res,lon,i, cont, cont2;
	string arreglo[100];
	int a;
	char b,l;
	cont=0;
	cont2=0;
	
	while (getline(archivo,linea)){
		lon = linea.length();
		for(i=0; i<lon+1; i++){
			l=linea[i];
			b=' ';
			if (linea[i-1]==b){
				if (cont2==0){
					if (cont<4){
						nota1[cont]=stoi(&linea[i]);
						cont=cont+1;
					}
					else{
						for (int q=0; q<4; q++){
							cont=0;
							cout<<nota1[q]<<" ";
						}
						cont2=cont2+1;
						cout<<endl;
					}
				}
				if (cont2==1){
					if (cont<4){
						nota2[cont]=stoi(&linea[i]);
						cont=cont+1;
					}
					else{
						for (int q=0; q<4; q++){
							cont=0;
							cout<<nota2[q]<<" ";
						}
						cont2=cont2+1;
						cout<<endl;
					}
				}
				else{
					if (cont<4){
						nota3[cont]=stoi(&linea[i]);
						cont=cont+1;
					}
					else{
						for (int q=0; q<4; q++){
							cont=0;
							cout<<nota3[q]<<" ";
						}
						cont2=cont2+1;
						cout<<endl;
					}
				}
			}
			else{
				cont=cont+0;
			}
		}
	}
}
