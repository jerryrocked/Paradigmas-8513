import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    double monto_a_ingresar; //monto que se ingresa
    int mes; //mese que se ingresan
    int cuenta; //cuenta es el tipo de cuenta 
    String nombre; //Nombre el usuario
    double a1,a2,a3;
    double total_en_cuenta1,total_en_cuenta2,total_en_cuenta3;
    char res='S';
    //menu de cuentas
    System.out.print("TIPOS DE CUENTAS \n");
    System.out.print("Cuenta Ahorro (1) \n");
    System.out.print("Cuenta Corriente (2) \n");
    System.out.print("Cuenata a Plazo fijo (3) \n");
    while(res=='S'){
      Scanner entrada = new Scanner(System.in);
      System.out.print("Escribe el Nombre: ");
      nombre = entrada.nextLine();
      System.out.print("Ingrese el tipo de cuenta: ");
      cuenta = entrada.nextInt();
      if (cuenta == 1){ //Cuenta Ahorro
        System.out.print("Ingrese Monto: ");
        monto_a_ingresar = entrada.nextDouble();
        double por1  = 0.01;//porcentaje de la cuenta
        a1 = monto_a_ingresar * por1;
        total_en_cuenta1 = monto_a_ingresar + a1;
        System.out.println("Su Monto Total es: "+total_en_cuenta1);
      }
      if (cuenta == 2){ //Cuenta Corriente
        System.out.print("Ingrese Monto: ");
        monto_a_ingresar = entrada.nextDouble();
        double por2  = 0.005;//porcentaje de la cuenta
        a2 = monto_a_ingresar * por2;
        total_en_cuenta2 = monto_a_ingresar + a2;
        System.out.println("Su Monto Total es: "+total_en_cuenta2);
      }
      if (cuenta == 3){ //Cuenta a Plazo fijo
        System.out.print("Ingrese Monto: ");
        monto_a_ingresar = entrada.nextDouble();
        System.out.println("Ingrese los Meses que Dejara su Dinero: (3 ó 6):");
        mes = entrada.nextInt();
        double por3  = 0.012;//porcentaje de la cuenta
        a3 = monto_a_ingresar * mes * por3;
        total_en_cuenta3 = monto_a_ingresar + a3;
        System.out.println("Su Monto Total es: "+total_en_cuenta3);
      }
      System.out.println("Desea continuar escriba (S) o (No): ");
      res=entrada.next().charAt(0);
    }
  }
}