#include <iostream>
#include <string.h>
#include <fstream>
#include <cmath>
using namespace std;

class Persona{
  public:
    string nombre;
};

class Alumno: public Persona{
  public:
    float promedio;
};

int main() {
  // VARIABLES
  string archivo1="Notas.txt";
  ifstream archivo(archivo1.c_str());
  string linea;

  // LEER ARCHIVO POR LINEA
  while (getline(archivo,linea)) {
    Alumno estu;
    string n1,n2,n3,n4;
    int lon,i,j=0;
    char b,l;

    // SEPARAR PALABRAS
    lon = linea.length();
    for (i=0;i<lon;i++){
      l=linea[i];
      b=' ';
      if (l!=b){
        if (j==0)
          estu.nombre=estu.nombre+linea[i];
        if (j==1)
          n1=n1+linea[i];
        if (j==2)
          n2=n2+linea[i];
        if (j==3)
          n3=n3+linea[i];
        if (j==4)
          n4=n4+linea[i];    
      }
      else
        j++;
    }

    // CALCULAR PROMEDIO
    float nota1 = stof(n1);
    float nota2 = stof(n2);
    float nota3 = stof(n3);
    float nota4 = stof(n4);
    estu.promedio = ceil(((nota1+nota2+nota3+nota4)/4)*10)/10;

    // APROBADOS Y REPROBADOS
    string pasan;
    if (estu.promedio >= 4){
      pasan = "Aprobó";
    }else{
      pasan = "Reprobó";
    }

    cout << estu.nombre << " " << estu.promedio << " " << pasan << endl;
  }
}