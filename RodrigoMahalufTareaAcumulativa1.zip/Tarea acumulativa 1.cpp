//Rodrigo Jos� Mahaluf Astudillo
//20.904.990-2

#include<iostream>
#include<string.h>
#include<fstream>
#include<stdlib.h>
//#include <cstream>
using namespace std;
//Tarea , convertir notas a flotantes y
//Introducirlas en un arreglo.
int main() {
    int k = 0,c=0,p=0,t=0;
    float arregloNotas[40];  //Esto convierte las notas a float.
    string arregloNombres[40];
    string archivo1="archivo1.txt";
    ifstream archivo(archivo1.c_str());
    string linea,nomb,n1,n2,n3,n4;
    int res,lon,i,j=0;
    string arreglo[100];
    char b,l;
    float nota1,nota2,nota3,nota4;
    while (getline(archivo,linea)) {
      cout<<linea<<endl;
      lon = linea.length();
      for (i=0;i<lon;i++){
          l=linea[i];
          b=' ';
          if (l!=b){
              if (j==0)
                  nomb=nomb+linea[i];
              if (j==1)
                  n1=n1+linea[i];
              if (j==2)
                  n2=n2+linea[i];
              if (j==3)
                  n3=n3+linea[i];
              if (j==4)
                  n4=n4+linea[i];    
          }
          else
              j++;
        }
      cout<<nomb<<endl;
      cout<<n1<<endl;
      cout<<n2<<endl;
      cout<<n3<<endl;
      cout<<n4<<endl;
      j=0;
      arregloNombres[c]=nomb; 
      nota1 = stof(n1); //Convierto cada una de las notas en float.
      nota2 = stof(n2);
      nota3 = stof(n3);
      nota4 = stof(n4);
      arregloNotas[k]= nota1; //Las asigno a un arreglo de notas.
      k++;
      arregloNotas[k]= nota2;
      k++;
      arregloNotas[k]= nota3;
      k++;
      arregloNotas[k]= nota4;
      k++;
     
      nomb=" ";
      n1=" ";
      n2=" ";
      n3=" ";
      n4=" ";

      c++;
    }
    for(p=0; p<40;p++){
      cout<<arregloNombres[p]<<endl;
    }
    for(t=0; t<k;t++){
      cout<<arregloNotas[t]<<endl;
    }
  }
	


