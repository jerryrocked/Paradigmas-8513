// reading a text file
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
using namespace std;

vector<float> readGrades(string line)
{
    string temp = line;
    int index;
    float grade;
    vector<float> grades;
    while(true){
        index = temp.find(" ");
        if(index!=string::npos){
            grade = stof(temp.substr(0,index+1));
            grades.push_back(grade);
        }
        else {
            grade = stof(temp);
            grades.push_back(grade);
            break;
        }
        temp = temp.substr(temp.find(" ")+1,temp.length()-1);
    }
    return grades;
}

int main()
{
    map<string, vector<float>> student_grades;
    string line;
    ifstream myfile("input_example.txt");
    if (myfile.is_open())
    {
        while (myfile.peek() != EOF)
        {
            getline(myfile, line);
            string name = "";
            name = line.substr(0, line.find(" "));
            student_grades[name] = readGrades(line.substr(line.find(" ")+1, line.length()-1));
            // cout << line << '\n';
        }
        myfile.close();
    }
    else
        cout << "Unable to open file";
    for (auto i: student_grades["Maria"]){
        cout << i << ' ';
    }
    return 0;
}