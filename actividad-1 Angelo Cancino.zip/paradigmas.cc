#include <iostream>
#include <string.h>
#include <fstream>
#include <string>
#include <list>
#include <vector>
#include <sstream>
#include <stdlib.h>
using namespace std;


class Persona{
    private:
    string arreglo[100];

    public:
    void Nombres_vector()
};

class Persona_notas{
    private:
    string archiv1;
    string line1;
    char l1 , s;

    public:
    void Notas_persona()

}

void Nombres_vector(string archivo){
    vector<string> nombres;
    string name;
    string archiv = archivo;
    int lon,i,j;
    ifstream archivo(archiv.c_str());
    char b, l;
    string line;
    while (getline(archivo,line)){
        lon = line.length();
        for(i = 0; i< lon; i++){
            l=line[i];
            b=' ';
            if(l != b){
                if (j == 0)
                    name = name + line[i];
                    nombres.push_back(name); 
            }else{
                j++
            }
        }
    }
    return nombres;
}

void Notas_persona(string archivo){
    char l1 , s;
    vector<float> P1,P2,P3,P4;
    string n1,n2,n3,n4;
    float N1, N2, N3, N4;
    string archiv1 = archivo;
    int lon,i,j;
    ifstream archivo(archiv1.c_str());

    while (getline(archivo,line1)){
        lon = line.length();
        for(i = 0; i< lon; i++){
            l1 = line1[i];
            s =' ';
            if (l1 != s)
            {
                if(i == 0){
                    if(j == 1)
                        n1 = n1 + line[i];
                        N1 = stod(n1);
                        P1.push_back(N1);

                    if (j == 2)
                        n2 = n2 + line[i];
                        N2 = stod(n2);
                        P1.push_back(N2);
                
                    if (j == 3)
                        n3 = n3 + line[i]; 
                        N3 = stod(n3);
                        P1.push_back(N3);
                
                    if (j == 4)
                        n4 = n4 + line[i];
                        N4 = stod(n4);
                        P1.push_back(N4);      
                }
              
                if(i == 1){
                    if(j == 1)
                        n1 = n1 + line[i];
                        N1 = stod(n1);
                        P2.push_back(N1);

                    if (j == 2)
                        n2 = n2 + line[i];
                        N2 = stod(n2);
                        P2.push_back(N2);
                
                    if (j == 3)
                        n3 = n3 + line[i]; 
                        N3 = stod(n3);
                        P2.push_back(N3);
                
                    if (j == 4)
                        n4 = n4 + line[i];
                        N4 = stod(n4);
                        P2.push_back(N4); 
                }
                
                if(i == 2){
                    if(j == 1)
                        n1 = n1 + line[i];
                        N1 = stod(n1);
                        P3.push_back(N1);

                    if (j == 2)
                        n2 = n2 + line[i];
                        N2 = stod(n2);
                        P3.push_back(N2);
                
                    if (j == 3)
                        n3 = n3 + line[i]; 
                        N3 = stod(n3);
                        P3.push_back(N3);
                
                    if (j == 4)
                        n4 = n4 + line[i];
                        N4 = stod(n4);
                        P3.push_back(N4); 
                }

                if(i == 3){
                    if(j == 1)
                        n1 = n1 + line[i];
                        N1 = stod(n1);
                        P4.push_back(N1);

                    if (j == 2)
                        n2 = n2 + line[i];
                        N2 = stod(n2);
                        P4.push_back(N2);
                
                    if (j == 3)
                        n3 = n3 + line[i]; 
                        N3 = stod(n3);
                        P4.push_back(N3);
                
                    if (j == 4)
                        n4 = n4 + line[i];
                        N4 = stod(n4);
                        P4.push_back(N4);
                }
        
            else{
                j++
                }      
            }
        return P1, P2, P3, P4;
        }   
    }
}

int main(){

    Nombres_vector(nombre del archivo);
    Notas_persona(nombre del archivo);

    return 0;

}


//Actividad Evaluada//
//-	Convertir las notas a un valor del tipo real//
//-	Los registros de los estudiantes almacenarlos en Arreglos//