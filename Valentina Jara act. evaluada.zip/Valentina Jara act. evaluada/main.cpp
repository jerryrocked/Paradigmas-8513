#include <fstream>
#include <iostream>
#include <string>
#include <iomanip>
#include <vector>
using namespace std;

int main() {
  string archivo1 = "archivo1.txt";
  ifstream archivo(archivo1.c_str());
  string linea, nomb, n1, n2, n3, n4;
  int res, lon, i, j = 0;
  //string arreglo[100];
  char b, l;
  float f1,f2,f3,f4;
  float notas[4];

  while (getline(archivo, linea)) {
    lon = linea.length();
    
    for (i = 0; i < lon; i++) {
      l = linea[i];
      b = ' ';
      if (l != b) {
        if (j == 0)
          nomb = nomb + linea[i];
        if (j == 1)
          n1 = n1 + linea[i];
        if (j == 2)
          n2 = n2 + linea[i];
        if (j == 3)
          n3 = n3 + linea[i];
        if (j == 4)
          n4 = n4 + linea[i];
      } else
        j++;
    }
    
    f1 = std::stof(n1);
    notas[0]=f1;
    f2 = std::stof(n2);
    notas[1]=f2;
    f3 = std::stof(n3);
    notas[2]=f3;
    f4 = std::stof(n4);
    notas[3]=f4;

    cout<<"Las notas de "<<nomb<<" son: "<<fixed<<setprecision(1)<<notas[0]<<" "<<notas[1]<<" "<<notas[2]<<" "<<notas[3]<<endl;;
    
    j = 0;
    nomb = " ";
    n1 = " ";
    n2 = " ";
    n3 = " ";
    n4 = " ";
  }

}