#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <fstream>
#include <map>

using namespace std;

class Estudiante
{
public:
    string nombre;
    map<string, float[3]> notas;

    Estudiante(string nombre)
    {
        this->nombre = nombre;
    }
    void setNotas(string nombre, float nota1, float nota2, float nota3)
    {
        notas[nombre][0] = nota1;
        notas[nombre][1] = nota2;
        notas[nombre][2] = nota3;
    }
    void getNotas(string nombre)
    {
        for (int i = 0; i < 3; i++)
        {
            cout << notas[nombre][i] << endl;
        }
    }
    float getPromedio()
    {
        float promedio = 0;
        for (auto it = notas.begin(); it != notas.end(); ++it)
        {
            promedio += it->second[0] + it->second[1] + it->second[2];
        }
        float res = (promedio / 3);
        return res;
    }
};

class Asignatura
{
private:
    string nombre;
    string teacher;

public:
    vector<Estudiante> Lista;
    Asignatura(string pnombre)
    {
        nombre = pnombre;
    }
    string getNombre()
    {
        return this->nombre;
    }
    void addAlumno(Estudiante estudiante)
    {
        Lista.push_back(estudiante);
    }
    void calificarAlumno(Estudiante& E, float n1, float n2, float n3)
    {
        E.setNotas(this->nombre, n1, n2, n3);
    }
};

class Profesor
{
public:
    string nombre;
    vector<Asignatura> asigImpartidas;
    Profesor(string pnombre)
    {
        nombre = pnombre;
    }
    void addAsignatura(Asignatura asignatura)
    {
        asigImpartidas.push_back(asignatura);
    }
};

int main()
{
    fstream archivo;
    string linea;
    string nombre;
    string nombreAsignatura;
    string nombreEstudiante;
    string nombreProfesor;
    string nombreArchivo;
    int opcion;
    int opcion2;
    vector<Profesor> profesores;
    Asignatura paradigmas("Paradigmas de Programacion");
    Asignatura arquitectura("Arquitectura de Computadoras");
    Asignatura sistemas("Sistemas Operativos");
    Profesor jerry("Jerry");
    Profesor alice("Alice");
    Profesor bob("Bob");
    Profesor profesor("");
    profesores.push_back(jerry);
    profesores.push_back(alice);
    profesores.push_back(bob);
    jerry.addAsignatura(paradigmas);
    alice.addAsignatura(arquitectura);
    bob.addAsignatura(sistemas); 
main:
    cout << "Bienvenido al sistema de calificaciones" << endl;
    cout << "1. Soy Profesor" << endl;
    cout << "2. Soy Estudiante" << endl;
    cin >> opcion;
    if (opcion == 1)
    {
        cout << "Ingrese su nombre" << endl;
        cin >> nombreProfesor;
        bool existe = false;
        for (int i = 0; i < profesores.size(); i++)
        {
            if (profesores[i].nombre == nombreProfesor)
            {
                existe = true;
                cout << "Este profesor tiene las siguientes asignaturas" << endl;
                for (int i = 0; i < profesores[i].asigImpartidas.size(); i++)
                {
                    cout << profesores[i].asigImpartidas[i].getNombre() << endl;
                }
                cout << "Ingrese el nombre de la asignatura que desea calificar" << endl;
                cin >> nombreAsignatura;
                for (int i = 0; i < profesores[i].asigImpartidas.size(); i++)
                {
                    if (nombreAsignatura == profesores[i].asigImpartidas[i].getNombre())
                    {
                        cout << "Ingrese el nombre del archivo con los estudiantes y sus notas" << endl;
                        cin >> nombreArchivo;
                        archivo.open(nombreArchivo);
                        if (archivo.is_open())
                        {
                            while (getline(archivo, linea))
                            {
                                string nombreEstudiante = linea.substr(0, linea.find(","));
                                string nota1 = linea.substr(linea.find(",") + 1, linea.find(","));
                                string nota2 = linea.substr(linea.find(",") + 1, linea.find(","));
                                string nota3 = linea.substr(linea.find(",") + 1, linea.find(","));
                                Estudiante estudiante(nombreEstudiante);
                                profesores[i].asigImpartidas[i].addAlumno(estudiante);
                                profesores[i].asigImpartidas[i].calificarAlumno(estudiante, stof(nota1), stof(nota2), stof(nota3));
                            }
                            archivo.close();
                            cout << "Proceso exitoso" << endl;
                            cin.get();
                            goto main;
                        }
                        else
                        {
                            cout << "" << endl;
                        }
                    }
                }
            }
        }
    }
    if (opcion == 2)
    {
        cout << "Ingrese su nombre" << endl;
        cin >> nombreEstudiante;
        for (int i = 0; i < profesores.size(); i++)
        {
            for (int j = 0; j < profesores[i].asigImpartidas.size(); j++)
            {
                for (int k = 0; k < profesores[i].asigImpartidas[j].Lista.size(); k++)
                {
                    if (nombreEstudiante == profesores[i].asigImpartidas[j].Lista[k].nombre)
                    {
                        profesores[i].asigImpartidas[j].Lista[k].getNotas(nombreEstudiante);
                    }
                    else
                    {
                        cout << "Estudiante no encontrado" << endl;
                        cin.get();
                        goto main;
                    }
                }
            }
        }
    }
}