#include <iostream>
#include <string.h>
#include <fstream>
#include <iomanip>

using namespace std;

int main() {
  string archivo1="archivo1.txt";
  ifstream archivo(archivo1.c_str());
  string linea,nomb,n1,n2,n3,n4;
  int res,lon,i,j=0;
  float nota1, nota2, nota3, nota4;
  //string arreglo[100];
  char b,l;
  
  //NOTAS
  float arreglo_notas[4];

  while (getline(archivo,linea)) {
    //cout<<linea<<endl;
    lon = linea.length();
    for (i=0;i<lon;i++){
      l=linea[i];
      b=' ';
      if (l!=b){
        if (j==0)
          nomb=nomb+linea[i];
        if (j==1)
          n1=n1+linea[i];
        if (j==2)
          n2=n2+linea[i];
        if (j==3)
          n3=n3+linea[i];
        if (j==4)
          n4=n4+linea[i];    
      }
      else
        j++;
    }
    //cout<<nomb<<endl;
    //cout<<n1<<endl;
    //cout<<n2<<endl;
    //cout<<n3<<endl;
    //cout<<n4<<endl;
    
    //NOTAS SON PASADAS DE STRING A FLOAT
    nota1 = stof(n1); //SE CAMBIA LA NOTA 1 DE STRING A FLOAT
    nota2 = stof(n2); //SE CAMBIA LA NOTA 2 DE STRING A FLOAT
    nota3 = stof(n3); //SE CAMBIA LA NOTA 3 DE STRING A FLOAT
    nota4 = stof(n4); //SE CAMBIA LA NOTA 4 DE STRING A FLOAT
    

    //SE AGREGAN LAS NOTAS FLOAT AL ARREGLO arreglo_notas[]
    arreglo_notas[0]=nota1; //SE AGREGA AL ESPACIO 0 DEL ARREGLO
    arreglo_notas[1]=nota2; //SE AGREGA AL ESPACIO 1 DEL ARREGLO
    arreglo_notas[2]=nota3; //SE AGREGA AL ESPACIO 2 DEL ARREGLO
    arreglo_notas[3]=nota4; //SE AGREGA AL ESPACIO 3 DEL ARREGLO
    
    //cout<<"Las notas de "<<nomb<<" son: "<<fixed<<setprecision(2)<<nota1<<" "<<nota2<<" "<<nota3<<" "<<nota4<<endl;
    cout<<"Las notas de "<<nomb<<" son: "<<fixed<<setprecision(2)<<arreglo_notas[0]<<", "<<arreglo_notas[1]<<", "<<arreglo_notas[2]<<", "<<arreglo_notas[3]<<endl;
    //cout<<arreglo_notas[0];
    //cout<<arreglo_notas;
    //cout<<notas[vale1,vale2,vale3,vale4];
    j=0;
    nomb=" ";
    n1=" ";
    n2=" ";
    n3=" ";
    n4=" ";
  }
}

/*AGREGAR LOS VALORES AL ARREGLO Y PRINTEAR LA CASILLA ESTABLECIDAD DEL ARREGLO*/