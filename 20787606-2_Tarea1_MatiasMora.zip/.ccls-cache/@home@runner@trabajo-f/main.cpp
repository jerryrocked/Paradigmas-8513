#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <stdlib.h>
using namespace std;
//Matias Mora 20.787.606-2
//Profesor Jerry Peña
//NRC 8513
class Profesor
{
	public:
  int opc = 0,APR = 0,REP = 0;//datos de para menu. Cantidad de aprobados y reprobados
  int z = 0;//contador 
  int NOTA1,NOTA2,NOTA3,NOTA4;//almacena notas ingresadas a mano por el profesor
  string Profe_nombre[100],Profe_apellido[100];
  string nombre,apellido,n1,n2,n3,n4;//variables de nombres, apellidos y notas
  string NOMBRE,APELLIDO,linea;//variables ingresadas a mano
  string N[100]; //almacena nombres
  string A[100]; //almacena apellidos
  float nota1[200],nota2[200],nota3[200],nota4[200];//almacena las notas en arreglos
  float FINALPROMEDIO[200];//almacena promedio final en arreglo
  float a1,a2,a3,a4;//almacenan notas
  string SALIDA_mano[100],SALIDA_mano_n[100],SALIDA_subida[100],SALIDA_subida_n[100];//almacena strings de los archivos de texto
  int res,lon,i=0,k,j=0,R = 0;//variables utilizadas para lectura de texto
  char b,l;//variables utilizadas para lectura de texto
  string CONDICION_M,CONDICION_T;//variables utilizadas para lectura de texto
  float promedio,total_promedio,total_promedio2;//almacenan el promedio de notas
  struct{
    string nombre;
    string apellido;
    string rut;
    string asignatura;
    string datos;
  }profeso;
	Profesor(){	};
	~Profesor(){ };
  void DATOSPROF();
  void Menu_Profesor();
  void Menu_Profesor_1();//menu de profesor para caso de que se ingrese 1
  void Menu_Profesor_2();//menu de profesor para caso de que se ingrese 2
  void Menu_Profesor_3();//menu de profesor para caso de que se ingrese 3
  void Menu_Asignaturas();
};


class Alumno: public Profesor
{
 public:
 int ca = 0;
 string NOMBRE,APELLIDO,TODO[100];
 struct{
    string NOMBRE;
    string APELLIDO;
 }alumni;
	Alumno(){	};
	~Alumno(){ };
  void DATOSALUMNO();//Ingresar datos de alumno
  void Menu_Alumno();//Menu de alumno 
  void DATOSPROF();//Datos de profesor
  void Revisar_Notas();//Permite revisar notas de alumno
  void Revisar_Notas_1();//Permite revisar notas de alumno
};

//Menu de alumno en el cual se ingresa nombre y apellido
void Alumno::DATOSALUMNO(){
  cout << "-----------------------------"<<endl;
  cout << "Ingrese su nombre: ";
  cin>>NOMBRE;//nombre de alumno
  cout << "Ingrese su apellido: ";
  cin>>APELLIDO;//apellido de alumno
};

//Menu de alumno
void Alumno::Menu_Alumno(){
  cout<<"-----------------------------"<<endl;
  cout<<"1 - Revisar Notas"<<endl;
  cout<<"2 - Salir"<<endl;
  cout<<"-----------------------------"<<endl;
  cin>>ca;
};

//Menu de profesor, donde ingresa nombre y apellido
void Profesor::DATOSPROF(){
  cout << "-----------------------------"<<endl;
  cout << "Ingrese su nombre: ";
  cin>>profeso.nombre;//se ingresa nombre de profesor
  cout << "Ingrese su apellido: ";
  cin>>profeso.apellido;//se ingresa apellido de profesor
};
//menu que se muetra siempre en la parte de profesor
void Profesor::Menu_Profesor(){
  cout<<"-----------------------------"<<endl;
  cout<<"1 - Ingresar manualmente notas"<<endl;
  cout<<"2 - Subir archivo de notas"<<endl;
  cout<<"3 - Salir"<<endl;
  cout<<"-----------------------------"<<endl;
  cin>>opc;//variable que permite mover en menu
};
void Profesor::Menu_Profesor_1(){
  int alumno = 0;
  
  cout << "-----------------------------"<<endl; 
  string archivo1 = "notas.txt";//almacena nombre de archivo
   cout<<"Ingrese nombre de alumno: ";
   cin>>NOMBRE;
   N[R] = NOMBRE;//se almacena el nombre en string
   cout<<"Ingrese apellido: ";
   cin>>APELLIDO;//se almacena el apellido en string
   A[R] = APELLIDO;//se apellido el nombre en string
  
   cout<<"Ingrese primera nota: ";
   cin>>NOTA1;//Se ingresa la primera nota
   nota1[R] = NOTA1; //Nota se almacena en arreglo
   a1 = nota1[R]; //variable auxiliar para calcular promedio

   cout<<"Ingrese segunda nota: ";
   cin>>NOTA2;//Se ingresa segunda nota
   nota2[R] = NOTA2;//Nota se almacena en arreglo
   a2 = nota2[R];//variable auxiliar para calcular promedio
   
   cout<<"Ingrese tercera nota: ";
   cin>>NOTA3;//Se ingresa tercera nota
   nota3[R] = NOTA3;//Nota se almacena en arreglo
   a3= nota3[R]; //variable auxiliar para calcular promedio  
   
   cout<<"Ingrese cuarta nota: ";
   cin>>NOTA4;//Se ingresa cuarta nota
   nota4[R] = NOTA4;//Nota se almacena en arreglo
   a4 = nota4[R];//variable auxiliar para calcular promedio    
   
   promedio = (a1+a2+a3+a4)/4;//calula el promedio de notas
   total_promedio2 = roundf(promedio * 10.0f)/10.0f;//almacena nota redondeando
   FINALPROMEDIO[R] = total_promedio2;//almacena nota en arreglo
   if (FINALPROMEDIO[R] >= 3.95){//En caso de ser mayor aprueba, menor reprueba
     CONDICION_M = "Aprobado";
   }else{
     CONDICION_M = "Reprobado";
   }
   cout << "-----------------------------"<<endl;
   cout<<"Condicion de estudiante -> "<<CONDICION_M<<endl;//imprime en pantalla
   SALIDA_mano[R] = NOMBRE + " " + APELLIDO + " " + std::to_string(FINALPROMEDIO[R]);//almacena string de cada variable
   SALIDA_mano_n[R] = NOMBRE + " " + APELLIDO;//almacena string de cada variable
   
   R++;//contador.
	 ofstream Archivo("Salida_Mano.txt");//se crea archivo, se recorre y se ingresa SALIDA_mano[R].
	 for (i=0;i<R;i++)
	 {
	 	Archivo << SALIDA_mano[i] << endl;
	 }
	 Archivo.close();  
   alumno++;
};



  
void Profesor::Menu_Profesor_2(){
  cout << "-----------------------------"<<endl;
  int TOTAL;
  string archivo1 = "FILE.txt";//almacena nombre de archivo
  ifstream archivo(archivo1.c_str()); //Se lee archivo de texto ya creado, en el cual se extrae nombre, apellido y notas.
            while (getline(archivo,linea)){
              lon = linea.length();//calcula el tamaño de linea 
              for(i = 0; i<lon;i++){
                l = linea[i];
                b = ' ';
                if(l != b){
                  if(j==0){
                    nombre = nombre+linea[i];//almacena nombre
                  }
                  if(j==1){
                    apellido = apellido+linea[i];//almacena apellido
                  }
                  
                  if(j==2){
                    n1 = n1+linea[i];
                    a1 = (std::stof(n1));//convierte nota 1 en numero  
          
                  }
                  if (j==3){
                    n2 = n2+linea[i];
                    a2 = (std::stof(n2));//convierte nota 2 en numero  
          
                  }
                  if (j==4){
                    n3 = n3+linea[i]; 
                    a3 = (std::stof(n3));//convierte nota 3 en numero      
                  }
                  if (j==5){
                    n4 = n4+linea[i];
                    a4 = (std::stof(n4));//convierte nota 4 en numero   
                  }
                }
                else
                  j++;    
              }
             promedio = ((a1 + a2 + a3 + a4)/4); //se calcula promedio de notas
             total_promedio = roundf(promedio * 10.0)/10.0;//se redondea el promedio

             if (total_promedio <= 3.94){//en caso de nota ser menor a 3.94 reprueba
               CONDICION_T = "Reprobado";
               REP = REP + 1;//contador de reprobados
             }
             if (total_promedio >= 3.95){//en caso de nota ser mayor a 3.95 aprueba
               CONDICION_T = "Aprobado";
               APR = APR + 1;//contador de aprobados
             } 
             SALIDA_subida_n[z] = nombre + " " + apellido;
             SALIDA_subida[z] =std::string(nombre) + " " + std::string(apellido) + " " + std::to_string(total_promedio);
             nombre = " ";//borra los datos de nombre
             apellido = " ";//borra los datos de apellido
             n1 =  " ";//borra los datos de n1
             n2 = " ";//borra los datos de n2
             n3 = " ";//borra los datos de n3
             n4 = " ";//borra los datos de n4
             j=0;     
             z = z + 1;//contador para array de SALIDA_subida_n y SALIDA_subida
            }     
             
            cout<<"Aprobados "<<APR<<endl;//imprime la cantidad de aprobados
            cout<<"Reprobados "<<REP<<endl; //imprime la cantidad de reprobados
            TOTAL = APR + REP;
		        ofstream Salida_txt("Salida_de_Subida.txt");//se crea archivo de texto
		        for (i=0;i<TOTAL;i++)//se escribe en archivo de texto en base a la cantidad total de aprobados y reprobados
		        {
		        	Salida_txt << SALIDA_subida[i] << endl;//se escribe en archivo de texto
		        }
		        Salida_txt.close();   //se cierra el archivo de texto            
};
  
void Profesor::Menu_Profesor_3(){
  cout << "-----------------------------"<<endl;
  cout<<"Hasta la próxima Profesor "<<profeso.nombre<<" "<<profeso.apellido<<endl;//menu de salida de profesor
};

class asignatura: public Profesor, public Alumno
{
	public:
  string RAMO;//variable que almacena el codigo del ramo
  int verificador = 0;
	string asig[5]={"PROGRAMACION","BASE DE DATOS","ALGORITMO Y ESTRUCTURA DE DATOS","DESARROLLO WEB Y MOBIL","PARADIGMAS DE PROGRAMACION"};
	string cod[5]={"PR001","BD002","AE003","DM004","PP005"};

  void Menu_Asignaturas();
};

void asignatura::Menu_Asignaturas(){
  //menu que almacena las asignaturas
  cout<<"--------------------------------"<<endl;
  cout<<"Seleccione asignatura a la cual subira notas:"<<endl;
  cout<<"1 -> PROGRAMACION"<<endl;
  cout<<"2 -> BASE DE DATOS"<<endl;
  cout<<"3 -> ALGORITMO Y ESTRUCTURA DE DATOS"<<endl;
  cout<<"4 -> DESARROLLO WEB Y MOBIL"<<endl;
  cout<<"5 -> PARADIGMAS DE PROGRAMACION"<<endl;
  cout<<"--------------------------------"<<endl;
  cin>>verificador;
  if (verificador == 1){
    RAMO = "PR001";//En caso de ingresar 1 se almacena en RAMO
    cout<<"Código de Ramo: "<<RAMO<<endl;
  }
  if (verificador == 2){
    RAMO = "BD002";//En caso de ingresar 2 se almacena en RAMO
    cout<<"Código de Ramo: "<<RAMO<<endl;
  }
  if (verificador == 3){
    RAMO = "AE003";//En caso de ingresar 3 se almacena en RAMO
    cout<<"Código de Ramo: "<<RAMO<<endl;
  }
  if (verificador == 4){
    RAMO = "DM004";//En caso de ingresar 4 se almacena en RAMO
    cout<<"Código de Ramo: "<<RAMO<<endl;
  }
  if (verificador == 5){
    RAMO = "PP005";//En caso de ingresar 5 se almacena en RAMO
    cout<<"Código de Ramo: "<<RAMO<<endl;//imprime codigo 
  }
}; 

void Alumno::Revisar_Notas(){
  string DATOS,nom,ap;//almacena string de nombres y apellidos 
  string GUARDAR;//almacena union de DATOS con nota
  int aux = 0,contador = 0;
  DATOS = NOMBRE+" "+APELLIDO;//almacena nombre y apellido de alumno para despues comparar
  string archivo1 = "Salida_Mano.txt";//almacena nombre de archivo
  ifstream archivo(archivo1.c_str()); //se abre archivo de texto
            while (getline(archivo,linea)){
              lon = linea.length();
              for(i = 0; i<lon;i++){
                l = linea[i];
                b = ' ';
                if(l != b){
                  if(j==0){
                    nombre = nombre+linea[i]; //nombre de alumno en txt
                  }
                  if(j==1){
                    apellido = apellido+linea[i]; //apellido de alumno en txt
                  }
                  
                  if(j==2){
                    n1 = n1+linea[i];  //promedio de nota en txt   
                    if (DATOS == (nombre+" "+apellido)){//comparar si esta en txt
                      GUARDAR = std::string(DATOS) + std::string(" ") + std::string(n1);
                      contador = contador + 1;
                    }
                  }
                }
                else
                  j++;    
              }
             nombre = " ";
             apellido = " ";
             n1 =  " ";
             j=0;     
            }
  if (contador == 0){
    cout<<"El profesor no ha subido sus notas "<<endl; 
  }
  else{
    cout<<GUARDAR<<endl;//imprime string con notas de alumno
  }
};

void Alumno::Revisar_Notas_1(){
  string DATOS,nom,ap;//almacena string de nombres y apellidos 
  string GUARDAR_1;//almacena union de DATOS con nota
  string LINEA;
  int aux = 0,contador = 0;
  DATOS = NOMBRE+" "+APELLIDO;
  string archivo1 = "Salida_de_Subida.txt";//almacena nombre de archivo
  ifstream archivo(archivo1.c_str()); 
            while (getline(archivo,LINEA)){
              lon = LINEA.length();
              for(i = 0; i<lon;i++){
                l = LINEA[i];
                b = ' ';
                if(l != b){
                  if(j==0){
                    nombre = nombre+LINEA[i]; 
                  }
                  if(j==1){
                    apellido = apellido+LINEA[i]; 
                  }
                  
                  if(j==2){
                    n1 = n1+LINEA[i];     
                    if (DATOS == (nombre+" "+apellido)){
                      GUARDAR_1 = std::string(DATOS) + std::string(" ") + std::string(n1);
                      contador = contador + 1;
                    }
                  }
                }
                else
                  j++;    
              }
             nombre = " ";
             apellido = " ";
             n1 =  " ";
             j=0;     
            }
  if (contador == 0){
    cout<<"El profesor no ha subido sus notas "<<endl;
  }
  else{
    cout<<GUARDAR_1<<endl;//imprime el nombre del alumno
  }
};


int main()
{
  Alumno a;//permite interactuar con alumno
  Profesor p;//permite interactuar con profesor
  asignatura r;//permite interactuar con asignatura
  int Ingreso = 0; //permtie interactuar con menu e ingresar en datos
    do{//menu el cual se ingresa con dato Ingreso
    cout << "-----------------------------"<<endl;
    cout << "Seleccione una opción"<<endl;
    cout << "1 - Ingreso de profesor"<<endl;
    cout << "2 - Ingreso de alumno"<<endl;
    cout << "3 - Salir"<<endl;
    cout << "-----------------------------"<<endl;
    cin >> Ingreso;//dato de ingreso
         switch(Ingreso) {
           case 1:
               p.DATOSPROF();
               r.Menu_Asignaturas();
               while (p.opc != 3){          
                 p.Menu_Profesor();//Muestra el menu del profesor
               switch(p.opc){                 
                 case 1:                  
                   p.Menu_Profesor_1();//se ingresa a menu 1 de profesor               
                   break;
                 case 2:
                   p.Menu_Profesor_2();//se ingresa a menu 2 de profesor                
                   break;
                 case 3:
                   p.Menu_Profesor_3();//se ingresa a menu 3 de profesor
                   break;                 
               }              
             }
                        
             break;
           case 2:
             a.DATOSALUMNO();
             while(a.ca != 2){
               a.Menu_Alumno();//Muestra el menu de alumno
              switch(a.ca){
                case 1:
                   a.Revisar_Notas();//permite revisar notas de alumno
                   a.Revisar_Notas_1();//permite revisar notas de alumno
                  break;

                case 2:            
                  cout << "-----------------------------"<<endl;
                  cout << "🔥Hasta la próxima crack🔥👌";
                  cout<<"\n";
                  break;
              }
             }
             break;

           
           case 3:
             //se termina el programa y envia mensaje de despedida.
             cout << "-----------------------------"<<endl;
             cout <<"Hasta la próxima";
             cout<<"\n";
             break;
           default:
             cout << "Seleccione una opción"<<endl;
             cout << "1 - Ingreso Profesor"<<endl;
             cout << "2 - Ingreso de alumno"<<endl;
             cout << "3 - Salir"<<endl;
             cout<<"\n"<<endl;
             cin >> Ingreso;    
         }
      } while(Ingreso !=3);                            
    return EXIT_SUCCESS;
}
